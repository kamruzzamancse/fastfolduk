<?php
/**
 * Template part for Add Ons Selection Step in Door Builder
 * Step 13: Add Ons Selection (Left, Top, Right dropdowns)
 * 
 * @package Astra Child
 */

$images_dir = get_stylesheet_directory_uri() . '/assets/images/';
?>

<div class="wizard-step" data-step="13">
    <div class="step-container addons-container">

        <div class="step-title addons-title">
            <h2>Do you require any add ons?</h2>
            <p class="addons-description">
                An add-on is an additional length of profile used to allow for extra clearance around the door, if necessary.
                If unsure, please select 'Not Required' and speak to one of the team.
            </p>
        </div>

        <div class="addons-layout">

            <!-- LEFT IMAGE -->
            <div class="addons-image">
                <img src="<?php echo $images_dir; ?>Rectangle_210_880x.webp" alt="Door Addons Preview">
            </div>

            <!-- RIGHT CONTROLS -->
            <div class="addons-controls">

                <div class="addon-dropdown-option">
                    <label for="addon_left">Left (mm)</label>
                    <select id="addon_left" name="addon_left" class="addon-select price-option" data-price-group="addons">
                        <option value="0" data-price="0" selected>0mm</option>
                        <option value="20" data-price="20">20mm</option>
                        <option value="38" data-price="22">38mm</option>
                    </select>
                </div>

                <div class="addon-dropdown-option">
                    <label for="addon_top">Top (mm)</label>
                    <select id="addon_top" name="addon_top" class="addon-select price-option" data-price-group="addons">
                        <option value="0" data-price="0" selected>0mm</option>
                        <option value="20" data-price="20">20mm</option>
                        <option value="38" data-price="22">38mm</option>
                    </select>
                </div>

                <div class="addon-dropdown-option">
                    <label for="addon_right">Right (mm)</label>
                    <select id="addon_right" name="addon_right" class="addon-select price-option" data-price-group="addons">
                        <option value="0" data-price="0" selected>0mm</option>
                        <option value="20" data-price="20">20mm</option>
                        <option value="38" data-price="22">38mm</option>
                    </select>
                </div>

                <div class="addon-not-required-option">
                    <input type="checkbox" id="addons_not_required" name="addons_not_required" value="yes">
                    <label for="addons_not_required">Not Required</label>
                </div>

            </div>
        </div>

    </div>
</div>

<style>

/* ===== MAIN WRAPPER ===== */
.addons-container{
    max-width:1400px;
    margin:0 auto;
    padding:30px 20px;
}

/* ===== TITLE ===== */
.addons-title h2{
    font-size:28px;
    margin-bottom:10px;
}

.addons-description{
    max-width:850px;
    color:#555;
    line-height:1.6;
}

/* ===== MAIN LAYOUT ===== */
.addons-layout{
    display:flex;
    gap:50px;
    align-items:stretch;
    border:1px solid #cfc8bb;
    padding:35px;
}

/* ===== LEFT IMAGE BOX ===== */
.addons-image{
    flex:2;
    border:2px solid #bdb6a8;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:30px;
}

.addons-image img{
    max-width:432px;
    height:auto;
}

/* ===== RIGHT SIDE ===== */
.addons-controls{
    flex:1;
    max-width:420px;
}

/* ===== DROPDOWN BLOCK ===== */
.addon-dropdown-option{
    margin-bottom:28px;
}

.addon-dropdown-option label{
    display:block;
    font-size:16px;
    margin-bottom:8px;
    color:#222;
}

/* ===== SELECT STYLE ===== */
.addon-select{
    width:100%;
    height:58px;
    padding:12px 14px;
    font-size:16px;
    border:1px solid #9f988c;
    background:#f7f5ef;
    appearance:none;
}

/* ===== CHECKBOX ===== */
.addon-not-required-option{
    margin-top:15px;
    display:flex;
    align-items:center;
    gap:10px;
}

.addon-not-required-option input{
    width:18px;
    height:18px;
}

/* ===== RESPONSIVE ===== */
@media(max-width:900px){

    .addons-layout{
        flex-direction:column;
    }

    .addons-controls{
        max-width:100%;
    }
}

</style>

<script>
jQuery(document).ready(function($) {
    // Handle Not Required checkbox functionality
    $('#addons_not_required').on('change', function() {
        const isChecked = $(this).prop('checked');
        
        if (isChecked) {
            // Disable all dropdowns and set them to 0mm
            $('.addon-select').each(function() {
                $(this).prop('disabled', true);
                $(this).val('0'); // Set to 0mm option
            });
        } else {
            // Enable all dropdowns
            $('.addon-select').prop('disabled', false);
        }
        
        // Trigger price update
        if (typeof updatePrice === 'function') {
            updatePrice();
        }
    });
    
    // When any dropdown changes, uncheck the "Not Required" checkbox
    $('.addon-select').on('change', function() {
        const $notRequiredCheckbox = $('#addons_not_required');
        
        // If any dropdown is not 0, uncheck Not Required
        let anyNonZero = false;
        $('.addon-select').each(function() {
            if ($(this).val() !== '0') {
                anyNonZero = true;
            }
        });
        
        if (anyNonZero && $notRequiredCheckbox.prop('checked')) {
            $notRequiredCheckbox.prop('checked', false);
        }
        
        // If all dropdowns are 0, optionally check Not Required?
        // Based on your requirement, you may or may not want this
        let allZero = true;
        $('.addon-select').each(function() {
            if ($(this).val() !== '0') {
                allZero = false;
            }
        });
        
        // You can decide if you want to auto-check Not Required when all are 0
        // if (allZero && !$notRequiredCheckbox.prop('checked')) {
        //     $notRequiredCheckbox.prop('checked', true);
        // }
        
        // Trigger price update
        if (typeof updatePrice === 'function') {
            updatePrice();
        }
    });
    
    // Calculate total addons price for summary and price update
    function calculateAddonsPrice() {
        let totalAddonsPrice = 0;
        
        $('.addon-select').each(function() {
            if (!$(this).prop('disabled')) {
                const selectedOption = $(this).find('option:selected');
                const price = parseFloat(selectedOption.data('price')) || 0;
                totalAddonsPrice += price;
            }
        });
        
        return totalAddonsPrice;
    }
    
    // Extend the existing updatePrice function to include addons
    // This will be called by the main updatePrice function through price-option class
});
</script>