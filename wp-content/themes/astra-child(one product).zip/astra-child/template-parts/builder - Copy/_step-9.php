<?php
/**
 * Template part for Astragal Bars Orientation Step in Door Builder
 * Step 9: Vertical or Horizontal Astragal Bars Selection
 * 
 * @package Astra Child
 */

// Get images directory
$images_dir = get_stylesheet_directory_uri() . '/assets/images/';
?>

<!-- Step 9: Astragal Bars Orientation -->
<div class="wizard-step" data-step="9">
    <div class="step-container">

        <div class="step-title">
            <h2>Would you like vertical or horizontal Astragal bars?</h2>
        </div>
        
        <div class="options-container">
            <div class="option-group">
                
                <div class="astragal-orientation-options">
                    
                    <!-- Horizontal Option -->
                    <div class="astragal-orientation-card">
                        <input type="radio" name="astragal_orientation" id="orientation_horizontal" value="horizontal" checked>
                        <label for="orientation_horizontal">
                            <div class="astragal-orientation-image">
                                <img src="<?php echo esc_url($images_dir . 'Horizontal_Astragal_Bars.png'); ?>" 
                                     alt="Horizontal Astragal Bars" 
                                     loading="lazy"
                                     onerror="this.src='<?php echo esc_url($images_dir . 'Horizontal_Astragal_Bars.png'); ?>'">
                            </div>
                            <div class="astragal-orientation-details">
                                <div class="astragal-orientation-text-content">
                                    <div class="astragal-orientation-name-line">
                                        <span class="astragal-orientation-radio-indicator"></span>
                                        <span class="option-name">Horizontal</span>
                                    </div>
                                </div>
                            </div>
                        </label>
                    </div>
                    
                    <!-- Vertical Option -->
                    <div class="astragal-orientation-card">
                        <input type="radio" name="astragal_orientation" id="orientation_vertical" value="vertical">
                        <label for="orientation_vertical">
                            <div class="astragal-orientation-image">
                                <img src="<?php echo esc_url($images_dir . 'Vertical_Astragal_Bars.png'); ?>" 
                                     alt="Vertical Astragal Bars" 
                                     loading="lazy"
                                     onerror="this.src='<?php echo esc_url($images_dir . 'placeholder.webp'); ?>'">
                            </div>
                            <div class="astragal-orientation-details">
                                <div class="astragal-orientation-text-content">
                                    <div class="astragal-orientation-name-line">
                                        <span class="astragal-orientation-radio-indicator"></span>
                                        <span class="option-name">Vertical</span>
                                    </div>
                                </div>
                            </div>
                        </label>
                    </div>
                    
                </div>
                
            </div>
        </div>

    </div>
</div>

<style>
/* ================================
   Astragal Bars Orientation Styles
   Matching Step 8 design exactly
   ================================ */

.astragal-orientation-options {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 30px;
    margin-top: 30px;
    max-width: 1200px;
    margin-left: auto;
    margin-right: auto;
}

.astragal-orientation-card {
    border: 1px solid #e0e0e0;
    overflow: hidden;
    transition: all 0.25s ease;
    cursor: pointer;
    height: 100%;
    background: #fff;
}

.astragal-orientation-card:hover {
    border-color: #9c7b4b;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

/* Hide radio input */
.astragal-orientation-card input[type="radio"] {
    position: absolute;
    opacity: 0;
    width: 0;
    height: 0;
}

.astragal-orientation-card label {
    display: flex;
    flex-direction: column;
    height: 100%;
    cursor: pointer;
    background: transparent;
}

.astragal-orientation-card input:checked + label {
    border: 2px solid #9c7b4b;
    margin: -1px;
}

.astragal-orientation-image {
    min-height: 320px;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f5f5f5;
    padding: 25px;
}

.astragal-orientation-image img {
    max-width: 100%;
    max-height: 100%;
    width: auto;
    height: auto;
    object-fit: contain;
}

/* Details container */
.astragal-orientation-details {
    padding: 15px;
    border-top: 1px solid #f0f0f0;
    background: #fafafa;
    min-height: 60px;
}

/* Text content container */
.astragal-orientation-text-content {
    display: flex;
    flex-direction: column;
    width: 100%;
}

/* Name line with radio indicator */
.astragal-orientation-name-line {
    display: flex;
    align-items: flex-start;
    margin-bottom: 5px;
    width: 100%;
    gap: 8px;
}

/* Radio indicator */
.astragal-orientation-radio-indicator {
    display: inline-block;
    width: 14px;
    height: 14px;
    border: 1.5px solid #222;
    border-radius: 50%;
    margin-right: 10px;
    transition: all 0.2s ease;
    box-sizing: border-box;
    flex-shrink: 0;
    margin-top: 1px;
}

/* Selected state for radio indicator */
.astragal-orientation-card input:checked + label .astragal-orientation-radio-indicator {
    background: #222;
    box-shadow: inset 0 0 0 3px #fafafa;
    border-color: #222;
}

/* Hover effect for radio indicator */
.astragal-orientation-card:hover .astragal-orientation-radio-indicator {
    border-color: #9c7b4b;
}

/* Selected card hover state */
.astragal-orientation-card input:checked + label:hover .astragal-orientation-radio-indicator {
    border-color: #222;
    background: #222;
    box-shadow: inset 0 0 0 3px #fafafa;
}

/* Option name styling - using existing .option-name class */
.option-name {
    font-weight: 500;
    color: #333;
    display: inline-block;
    text-align: left;
    line-height: 1.3;
    font-size: 13px !important;
}

/* Step title styling */
.step-title h2 {
    font-size: 28px;
    margin-bottom: 10px;
    color: #222;
}

.step-title p {
    font-size: 16px;
    color: #666;
    margin-bottom: 10px;
    line-height: 1.5;
}

/* ================================
   Responsive Design
   ================================ */

@media (max-width: 768px) {
    .astragal-orientation-options {
        grid-template-columns: repeat(2, 1fr);
        gap: 15px;
        padding: 0 15px;
    }
    
    .astragal-orientation-image {
        height: 120px !important;
        padding: 10px;
    }
    
    .astragal-orientation-details {
        padding: 12px 10px;
        min-height: 55px;
    }
    
    .astragal-orientation-radio-indicator {
        width: 12px;
        height: 12px;
        margin-right: 8px;
        border-width: 1.2px;
    }
    
    .astragal-orientation-card input:checked + label .astragal-orientation-radio-indicator {
        box-shadow: inset 0 0 0 2px #fafafa;
    }
    
    .step-title p {
        padding: 0 15px;
    }
}

@media (min-width: 769px) and (max-width: 1024px) {
    .astragal-orientation-options {
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
        padding: 0 20px;
    }
    
    .astragal-orientation-image {
        height: 130px !important;
    }
    
    .astragal-orientation-radio-indicator {
        width: 13px;
        height: 13px;
    }
}

@media (min-width: 1025px) and (max-width: 1399px) {
    .astragal-orientation-options {
        grid-template-columns: repeat(2, 1fr);
        gap: 25px;
    }
    
    .astragal-orientation-image {
        height: 140px !important;
    }
    
    .astragal-orientation-radio-indicator {
        width: 14px;
        height: 14px;
    }
}

@media (min-width: 1400px) {
    .astragal-orientation-options {
        grid-template-columns: repeat(2, 1fr);
        gap: 30px;
        max-width: 1400px;
    }
    
    .astragal-orientation-image {
        height: 150px !important;
    }
    
    .astragal-orientation-radio-indicator {
        width: 15px;
        height: 15px;
        border-width: 2px;
    }
    
    .astragal-orientation-card input:checked + label .astragal-orientation-radio-indicator {
        box-shadow: inset 0 0 0 3.5px #fafafa;
    }
}

/* Container alignment */
.step-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 20px;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Add selected state styling when radio is checked
    $('.astragal-orientation-card input[type="radio"]').on('change', function() {
        // Remove selected styling from all cards
        $('.astragal-orientation-card').removeClass('selected').css({
            'border-color': '#e0e0e0',
            'background': '#fff'
        });
        
        // Add selected styling to the checked card
        $(this).closest('.astragal-orientation-card').addClass('selected').css({
            'border-color': '#9c7b4b',
            'background': '#fff'
        });
    });
    
    // Set initial selected state
    $('.astragal-orientation-card input[type="radio"]:checked').each(function() {
        $(this).closest('.astragal-orientation-card').addClass('selected').css({
            'border-color': '#9c7b4b',
            'background': '#fff'
        });
    });
    
    // Handle card click for better UX
    $('.astragal-orientation-card').on('click', function(e) {
        // Don't trigger if clicking on radio directly
        if ($(e.target).is('input[type="radio"]')) {
            return;
        }
        
        // Find the radio inside this card and check it
        const $radio = $(this).find('input[type="radio"]');
        $radio.prop('checked', true).trigger('change');
    });
});
</script>