<?php
/**
 * Template part for Additions Step in Door Builder
 * Step 8: Astragal Bars Selection
 * 
 * @package Astra Child
 */

// Get images directory
$images_dir = get_stylesheet_directory_uri() . '/assets/images/';
?>

<!-- Step 8: Additions - Astragal Bars -->
<div class="wizard-step" data-step="8">
    <div class="step-container">

        <div class="step-title">
            <h2>Would you like to add Astragal Bars to your door?</h2>
            <p>These are good options to make your doors more traditional in style.</p>
        </div>
        
        <div class="options-container">
            <div class="option-group">
                
                <div class="astragal-options">
                    
                    <!-- Yes, Add Astragal Bars Option -->
                    <div class="astragal-option-card">
                        <input type="radio" name="astragal_bars" id="astragal_yes" value="yes_astragal">
                        <label for="astragal_yes">
                            <div class="astragal-image">
                                <img src="<?php echo esc_url($images_dir . 'Horizontal_Astragal_Bars.png'); ?>" alt="Door with Astragal Bars" loading="lazy" onerror="this.src='<?php echo esc_url($images_dir . 'placeholder.webp'); ?>'">
                            </div>
                            <div class="astragal-details">
                                <div class="astragal-text-content">
                                    <div class="astragal-name-line">
                                        <span class="astragal-radio-indicator"></span>
                                        <span class="option-name">Yes, Add Astragal Bars</span>
                                        <!-- Question Mark Icon with Tooltip -->
                                        <span class="tooltip-container">
                                            <span class="question-mark">?</span>
                                            <span class="tooltip-text">Astragal Bars are a modern replica of glazing bars fitted to the inside and outside of double glazing units. Instead of holding individual pieces of glass in the frame, they are used to divide a single pane of glass into sections.</span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </label>
                    </div>
                    
                    <!-- No, Continue Without Option -->
                    <div class="astragal-option-card">
                        <input type="radio" name="astragal_bars" id="astragal_no" value="no_astragal" checked>
                        <label for="astragal_no">
                            <div class="astragal-image">
                                <img src="<?php echo esc_url($images_dir . 'Rectangle.webp'); ?>" alt="Door without Astragal Bars" loading="lazy" onerror="this.src='<?php echo esc_url($images_dir . 'placeholder.webp'); ?>'">
                            </div>
                            <div class="astragal-details">
                                <div class="astragal-text-content">
                                    <div class="astragal-name-line">
                                        <span class="astragal-radio-indicator"></span>
                                        <span class="option-name">No, Continue Without</span>
                                    </div>
                                </div>
                            </div>
                        </label>
                    </div>
                    
                </div>
                
            </div>
        </div>

    </div>
</div>

<style>
/* ================================
   Astragal Bars Selection Styles
   Matching Glass Selection exactly
   ================================ */

.section-title {
    margin-bottom: 25px;
    padding-bottom: 10px;
    border-bottom: 1px solid #e0e0e0;
}

.section-title h3 {
    font-size: 20px;
    font-weight: 600;
    color: #222;
    margin: 0;
}

.astragal-options {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 30px;
    margin-top: 30px;
    max-width: 1200px;
    margin-left: auto;
    margin-right: auto;
}

.astragal-option-card {
    border: 1px solid #e0e0e0;
    overflow: hidden;
    transition: all 0.25s ease;
    cursor: pointer;
    height: 100%;
    background: #fff;
}

.astragal-option-card:hover {
    border-color: #9c7b4b;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

/* Hide radio input */
.astragal-option-card input[type="radio"] {
    position: absolute;
    opacity: 0;
    width: 0;
    height: 0;
}

.astragal-option-card label {
    display: flex;
    flex-direction: column;
    height: 100%;
    cursor: pointer;
    background: transparent;
}

.astragal-option-card input:checked + label {
    border: 2px solid #9c7b4b;
    margin: -1px;
}

.astragal-image {
    height: 320px!important;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f5f5f5;
    padding: 25px;
}

.astragal-image img {
    max-width: 100%;
    max-height: 100%;
    width: auto;
    height: auto;
    object-fit: contain;
}

/* Details container */
.astragal-details {
    padding: 15px;
    border-top: 1px solid #f0f0f0;
    background: #fafafa;
    min-height: 60px;
}

/* Text content container */
.astragal-text-content {
    display: flex;
    flex-direction: column;
    width: 100%;
}

/* Name line with radio indicator */
.astragal-name-line {
    display: flex;
    align-items: flex-start;
    margin-bottom: 5px;
    width: 100%;
    gap: 8px;
}

/* Radio indicator */
.astragal-radio-indicator {
    display: inline-block;
    width: 14px;
    height: 14px;
    border: 1.5px solid #222;
    border-radius: 50%;
    margin-right: 10px;
    transition: all 0.2s ease;
    box-sizing: border-box;
    flex-shrink: 0;
    margin-top: 1px;
}

/* Selected state for radio indicator */
.astragal-option-card input:checked + label .astragal-radio-indicator {
    background: #222;
    box-shadow: inset 0 0 0 3px #fafafa;
    border-color: #222;
}

/* Hover effect for radio indicator */
.astragal-option-card:hover .astragal-radio-indicator {
    border-color: #9c7b4b;
}

/* Selected card hover state */
.astragal-option-card input:checked + label:hover .astragal-radio-indicator {
    border-color: #222;
    background: #222;
    box-shadow: inset 0 0 0 3px #fafafa;
}

/* Option name styling */
.option-name {
    font-weight: 500;
    color: #333;
    display: inline-block;
    text-align: left;
    line-height: 1.3;
    font-size: 13px !important;
}

/* Tooltip Styles */
.tooltip-container {
    position: relative;
    display: inline-block;
    cursor: pointer;
    margin-left: auto;
}

.question-mark {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 16px;
    height: 16px;
    background-color: #6c757d;
    color: white;
    border-radius: 50%;
    font-size: 11px;
    font-weight: bold;
    transition: all 0.2s ease;
}

.tooltip-container:hover .question-mark {
    background-color: #9c7b4b;
}

.tooltip-text {
    visibility: hidden;
    position: absolute;
    z-index: 1000;
    bottom: 150%;
    right: 0;
    width: 280px;
    background-color: #333;
    color: #fff;
    text-align: left;
    padding: 12px;
    border-radius: 6px;
    font-size: 12px;
    line-height: 1.5;
    font-weight: normal;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    opacity: 0;
    transition: opacity 0.2s ease, visibility 0.2s ease;
    pointer-events: none;
}

/* Tooltip arrow */
.tooltip-text::after {
    content: '';
    position: absolute;
    bottom: -5px;
    right: 5px;
    width: 0;
    height: 0;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 5px solid #333;
}

.tooltip-container:hover .tooltip-text {
    visibility: visible;
    opacity: 1;
}

/* Step title styling */
.step-title h2 {
    font-size: 28px;
    margin-bottom: 10px;
    color: #222;
}

.step-title p {
    font-size: 16px;
    color: #666;
    margin-bottom: 10px;
    line-height: 1.5;
}

/* ================================
   Responsive Design
   ================================ */

@media (max-width: 768px) {
    .astragal-options {
        grid-template-columns: repeat(2, 1fr);
        gap: 15px;
        padding: 0 15px;
    }
    
    .astragal-image {
        min-height: 120px;
        padding: 10px;
    }
    
    .astragal-details {
        padding: 12px 10px;
        min-height: 55px;
    }
    
    .astragal-radio-indicator {
        width: 12px;
        height: 12px;
        margin-right: 8px;
        border-width: 1.2px;
    }
    
    .astragal-option-card input:checked + label .astragal-radio-indicator {
        box-shadow: inset 0 0 0 2px #fafafa;
    }
    
    .section-title {
        margin-bottom: 20px;
        padding: 0 15px 10px 15px;
    }
    
    .section-title h3 {
        font-size: 18px;
    }
    
    .step-title p {
        padding: 0 15px;
    }
    
    /* Responsive Tooltip */
    .tooltip-text {
        width: 200px;
        right: -50px;
        font-size: 11px;
        padding: 8px;
    }
    
    .tooltip-text::after {
        right: 55px;
    }
}

@media (min-width: 769px) and (max-width: 1024px) {
    .astragal-options {
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
        padding: 0 20px;
    }
    
    .astragal-image {
        min-height: 130px;
    }
    
    .astragal-radio-indicator {
        width: 13px;
        height: 13px;
    }
}

@media (min-width: 1025px) and (max-width: 1399px) {
    .astragal-options {
        grid-template-columns: repeat(2, 1fr);
        gap: 25px;
    }
    
    .astragal-image {
        min-height: 140px;
    }
    
    .astragal-radio-indicator {
        width: 14px;
        height: 14px;
    }
}

@media (min-width: 1400px) {
    .astragal-options {
        grid-template-columns: repeat(2, 1fr);
        gap: 30px;
        max-width: 1400px;
    }
    
    .astragal-image {
        min-height: 150px;
    }
    
    .astragal-radio-indicator {
        width: 15px;
        height: 15px;
        border-width: 2px;
    }
    
    .astragal-option-card input:checked + label .astragal-radio-indicator {
        box-shadow: inset 0 0 0 3.5px #fafafa;
    }
}

/* Container alignment */
.step-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 20px;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Add selected state styling when radio is checked
    $('.astragal-option-card input[type="radio"]').on('change', function() {
        // Remove selected styling from all cards
        $('.astragal-option-card').removeClass('selected').css({
            'border-color': '#e0e0e0',
            'background': '#fff'
        });
        
        // Add selected styling to the checked card
        $(this).closest('.astragal-option-card').addClass('selected').css({
            'border-color': '#9c7b4b',
            'background': '#fff'
        });
    });
    
    // Set initial selected state
    $('.astragal-option-card input[type="radio"]:checked').each(function() {
        $(this).closest('.astragal-option-card').addClass('selected').css({
            'border-color': '#9c7b4b',
            'background': '#fff'
        });
    });
    
    // Handle card click for better UX
    $('.astragal-option-card').on('click', function(e) {
        // Don't trigger if clicking on radio or tooltip directly
        if ($(e.target).is('input[type="radio"]') || $(e.target).closest('.tooltip-container').length) {
            return;
        }
        
        // Find the radio inside this card and check it
        const $radio = $(this).find('input[type="radio"]');
        $radio.prop('checked', true).trigger('change');
    });
    
    // Prevent tooltip click from triggering card selection
    $('.tooltip-container').on('click', function(e) {
        e.stopPropagation();
    });
});
</script>