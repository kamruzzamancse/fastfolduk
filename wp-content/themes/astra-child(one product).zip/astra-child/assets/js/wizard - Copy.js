jQuery(function($){

    // Keep track of the current step index
    let currentStep = 0;
    const steps = $('.wizard-step');
    const totalSteps = steps.length;
    //const stepIndicators = $('.step-indicator');
    const prevBtn = $('.prev-step');
    const nextBtn = $('.next-step');
    const submitContainer = $('.submit-container');
    const nextFooterBtn = $('.next-footer-btn');
    const submitBtn = $('#submit-btn');

    // Edit mode variables
    let editMode = false;
    let editCartKey = '';

    /**
     * Prefill form data in edit mode
     * Maps stored display text back to form values
     */
    function prefillFormData(data) {
        if (!data || Object.keys(data).length === 0) {
            if (isDev()) console.log('No data to prefill');
            return;
        }
        
        if (isDev()) console.log('Prefilling form data:', data);

        // === STEP 1: Size ===
        if (data.width) $('#width').val(data.width);
        if (data.height) $('#height').val(data.height);
        
        // === STEP 2: Panels - FIXED MAPPING ===
        if (data.panels) {
            if (isDev()) console.log('Panel data to restore:', data.panels);
            
            // Map panel text back to value (from display text to form value)
            const panelMap = {
                '2 Panels Left': '2_left',
                '2 Panels Right': '2_right',
                '1 + 2 Panels': '1_2',
                '2 + 1 Panels': '2_1',
                '3 Panels Left': '3_left',
                '3 Panels Right': '3_right',
                '1 + 3 Panels': '1_3',
                '3 + 1 Panels': '3_1',
                '2 + 2 Panels': '2_2',
                '4 Panels Left': '4_left',
                '4 Panels Right': '4_right',
                '1 + 4 Panels': '1_4',
                '4 + 1 Panels': '4_1',
                '2 + 3 Panels': '2_3',
                '3 + 2 Panels': '3_2',
                '5 Panels Left': '5_left',
                '5 Panels Right': '5_right',
                '1 + 5 Panels': '1_5',
                '2 + 4 Panels': '2_4',
                '3 + 3 Panels': '3_3',
                '4 + 2 Panels': '4_2',
                '5 + 1 Panels': '5_1',
                '6 Panels Left': '6_left',
                '6 Panels Right': '6_right',
                'French Doors': 'french'
            };
            
            let panelValue = panelMap[data.panels];
            
            // If not found in map, try direct value
            if (!panelValue) {
                const possibleValues = [
                    '2_left', '2_right', '1_2', '2_1', '3_left', '3_right', '1_3', '3_1', '2_2',
                    '4_left', '4_right', '1_4', '4_1', '2_3', '3_2', '5_left', '5_right',
                    '1_5', '2_4', '3_3', '4_2', '5_1', '6_left', '6_right', 'french'
                ];
                
                if (possibleValues.includes(data.panels)) {
                    panelValue = data.panels;
                }
            }
            
            if (panelValue) {
                if (isDev()) console.log('Setting panel to:', panelValue);
                
                // First trigger panel visibility update
                if (typeof updatePanelOptions === 'function') {
                    updatePanelOptions();
                }
                
                // Small delay to ensure panels are visible
                setTimeout(function() {
                    $(`input[name="panel_layout"][value="${panelValue}"]`).prop('checked', true).trigger('change');
                    
                    // Trigger pane count update
                    if (typeof window.getPaneCount === 'function') {
                        window.getPaneCount();
                    }
                    
                    // Update Step 7 prices
                    if (typeof window.updatePerPanePrices === 'function') {
                        window.updatePerPanePrices();
                    }
                }, 200);
            }
        }
        
        // === STEP 3: Opening Direction ===
        if (data.opening) {
            const openingValue = data.opening === 'Inwards' ? 'inwards' : 'outwards';
            $(`input[name="open_direction"][value="${openingValue}"]`).prop('checked', true);
        }
        
        // === STEP 4: Outside Colour ===
        if (data.outside_colour) {
            // Check if it's a RAL code
            if (data.outside_colour.startsWith('RAL ')) {
                $('#colour_custom').prop('checked', true).trigger('change');
                $('#custom_colour_select').val(data.outside_colour).trigger('change');
                
                // After setting outside colour, update inside options
                setTimeout(function() {
                    updateInsideColourOptions('custom_ral');
                }, 200);
            } else {
                const colourMap = {
                    'Anthracite Grey': 'anthracite_grey',
                    'Black': 'black',
                    'White': 'white'
                };
                let colourValue = colourMap[data.outside_colour] || 'custom_ral';
                $(`input[name="door_colour"][value="${colourValue}"]`).prop('checked', true).trigger('change');
                
                // After setting outside colour, update inside options
                setTimeout(function() {
                    updateInsideColourOptions(colourValue);
                }, 200);
            }
        }

        // === STEP 5: Inside Colour ===
        if (data.inside_colour) {
            // Small delay to ensure outside colour updates first
            setTimeout(function() {
                // Check if it's a RAL code
                if (data.inside_colour.startsWith('RAL ')) {
                    $('#inside_colour_custom').prop('checked', true).trigger('change');
                    $('#custom_inside_colour_select').val(data.inside_colour).trigger('change');
                } else {
                    const colourMap = {
                        'Anthracite Grey': 'anthracite_grey',
                        'Black': 'black',
                        'White': 'white'
                    };
                    let colourValue = colourMap[data.inside_colour] || 'custom_ral';
                    
                    // Check if this option is visible before selecting
                    const $option = $(`input[name="inside_colour"][value="${colourValue}"]`);
                    if ($option.length && $option.closest('.inside-colour-option').is(':visible')) {
                        $option.prop('checked', true).trigger('change');
                    } else {
                        // If not visible, let validateInsideColourSelection handle it
                        if (isDev()) console.log('Selected inside colour not visible - will be handled by validator');
                    }
                }
            }, 300);
        }
        
        // === STEP 6: Handle Colour ===
        if (data.handle) {
            const handleMap = {
                'White': 'white',
                'Chrome': 'chrome',
                'Black': 'black',
                'Black and White': 'black_white'
            };
            
            let handleValue = handleMap[data.handle] || 'white';
            
            if (isDev()) {
                console.log('Handle mapping - Display:', data.handle, '→ Value:', handleValue);
            }
            
            $(`input[name="handle_colour"][value="${handleValue}"]`).prop('checked', true);
        }
        
        // === STEP 7: Glass ===
        if (data.glass) {
            const glassMap = {
                'Self-cleaning glass': 'self_cleaning',
                'Integral blinds': 'integral_blinds',
                'Obscure glass': 'obscure_glass',
                'Saint-Gobain Planitherm 1.2': 'saint_gobain_12'
            };
            
            let glassValue = glassMap[data.glass];
            
            if (!glassValue) {
                const possibleValues = ['self_cleaning', 'integral_blinds', 'obscure_glass', 'saint_gobain_12'];
                if (possibleValues.includes(data.glass)) {
                    glassValue = data.glass;
                }
            }
            
            if (glassValue) {
                if (isDev()) console.log('Setting glass to:', glassValue);
                setTimeout(function() {
                    $(`input[name="glass_upgrade"][value="${glassValue}"]`).prop('checked', true).trigger('change');
                }, 300);
            }
        }
        
        // === STEP 8: Trickle Vents ===
        if (data.vents) {
            const trickleValue = data.vents.includes('With') ? 'yes_trickle' : 'no_trickle';
            $(`input[name="trickle_vents"][value="${trickleValue}"]`).prop('checked', true).trigger('change');
        }
        
        // === STEP 9: Cill ===
        if (data.cill) {
            if (data.cill === 'No Cill') {
                $('input[name="cill"][value="none"]').prop('checked', true);
            } else if (data.cill === '150mm Aluminium Cill') {
                $('input[name="cill"][value="150mm-aluminium-cill"]').prop('checked', true);
            } else if (data.cill === '150mm uPVC Cill') {
                $('input[name="cill"][value="150mm-upvc-cill"]').prop('checked', true);
            } else {
                const validValues = ['150mm-aluminium-cill', '150mm-upvc-cill', 'none'];
                if (validValues.includes(data.cill)) {
                    $(`input[name="cill"][value="${data.cill}"]`).prop('checked', true);
                }
            }
        }
        
        // === STEP 10: Postcode ===
        if (data.postcode) {
            $('#postcode').val(data.postcode);
            // Trigger delivery check
            setTimeout(function() {
                $('#postcode').trigger('input');
            }, 500);
        }
        
        // === STEP 11: Access Issues ===
        if (data.access) {
            if (data.access === 'No' || data.access === 'No Access Issues') {
                $('input[name="access_issues"][value="no_access"]').prop('checked', true);
            } else {
                $('input[name="access_issues"][value="yes_access"]').prop('checked', true);
                if (data.access !== 'Yes') {
                    const desc = data.access.replace('Yes, ', '').replace('Yes', '');
                    if (desc) {
                        $('#access_description').val(desc);
                    }
                }
            }
        }
        
        // === STEP 12: Customer Information ===
        if (data.first_name) $('#first_name').val(data.first_name);
        if (data.last_name) $('#last_name').val(data.last_name);
        if (data.email) $('#email_address').val(data.email);
        if (data.phone) $('#mobile_number').val(data.phone);
        
        // Final update after all data is restored
        setTimeout(function() {
            // Update price
            if (typeof updatePrice === 'function') {
                updatePrice();
            }
            
            // Update drawer
            if (typeof updateDrawer === 'function') {
                updateDrawer();
            }
            
            // Trigger step change event to update UI
            $(document).trigger('stepChanged', [currentStep]);
            
            if (isDev()) console.log('Prefill complete - all data restored');
        }, 500);
    }

    // Store the selected outside colour
    let selectedOutsideColour = 'anthracite_grey'; // Default

    // Helper function to check if we're in development
    function isDev() {
        return window.location.hostname === 'localhost' || 
               window.location.hostname === '127.0.0.1';
    }

    /**
     * Initialize wizard on page load
     */
    function initWizard() {
        if (steps.length) {
            
            // Check for edit mode from global variables
            if (typeof window.editMode !== 'undefined' && window.editMode) {
                editMode = true;
                editCartKey = window.editCartKey || '';
                
                // ===== FIXED: Set hidden field value =====
                if (editCartKey) {
                    $('#cart_item_key_field').val(editCartKey);
                }
                
                if (isDev()) {
                    console.log('Edit Mode Active - Cart Key:', editCartKey);
                    console.log('Edit Data:', window.editData);
                    console.log('Cart key field set to:', $('#cart_item_key_field').val());
                }
                
                // First, run panel options update
                updatePanelOptions();
                
                // Prefill form data with existing cart data
                if (window.editData) {
                    prefillFormData(window.editData);
                }
                
                // Force drawer update after prefill
                setTimeout(function() {
                    if (typeof updateDrawer === 'function') {
                        updateDrawer();
                    }
                }, 600);
            } 
            // Also check URL parameters as fallback
            else {
                const urlParams = new URLSearchParams(window.location.search);
                if (urlParams.has('edit_cart_item')) {
                    editMode = true;
                    editCartKey = urlParams.get('edit_cart_item');
                    
                    // ===== FIXED: Set hidden field value =====
                    $('#cart_item_key_field').val(editCartKey);
                    window.editCartKey = editCartKey;
                    
                    if (isDev()) {
                        console.log('Edit Mode from URL - Cart Key:', editCartKey);
                    }
                }
            }
            
            window.editMode = editMode;
            
            showStep(currentStep);
            updateNavigation();
            updatePrice();
            updateSummary();
            validateCurrentStep();
            
            initCustomColourDropdowns();
            initOutsideColourTracking();
            updateInsideColourOptions();
            
            // Initialize delivery data if postcode exists
            const savedPostcode = $('#postcode').val();
            if (savedPostcode && savedPostcode.length > 0) {
                setTimeout(function() {
                    $('#postcode').trigger('input');
                }, 1000);
            }
        }
    }

    // Initialize access issues textarea toggle
    function initAccessIssuesToggle() {
        $(document).on('change', 'input[name="access_issues"]', function() {
            if ($(this).val() === 'yes_access') {
                $('.access-textarea-wrapper').slideDown();
            } else {
                $('.access-textarea-wrapper').slideUp();
                $('#access_description').val(''); // Clear textarea when switching to No
            }
            validateCurrentStep();
        });
    }

    // Track outside colour selection
    function initOutsideColourTracking() {
        // Get initial selected outside colour
        const initialSelected = $('input[name="door_colour"]:checked');
        if (initialSelected.length) {
            selectedOutsideColour = getOutsideColourCategory(initialSelected.val());
        }
        
        // Update when outside colour changes
        $(document).on('change', 'input[name="door_colour"]', function() {
            const colourValue = $(this).val();
            selectedOutsideColour = getOutsideColourCategory(colourValue);
            updateInsideColourOptions(colourValue); // Pass the selected value
            
            // Validate inside colour selection
            validateInsideColourSelection();
            
            // Update price with new colour logic
            updatePrice();
        });
        
        // Also update when custom RAL dropdown changes
        $(document).on('change', '#custom_colour_select', function() {
            if ($('#colour_custom').is(':checked')) {
                updateInsideColourOptions('custom_ral'); // Pass custom_ral
                updatePrice();
            }
        });
    }

    // Helper function to categorize outside colour
    function getOutsideColourCategory(colourValue) {
        // Check if it's a custom RAL colour (starts with "RAL")
        if (colourValue && colourValue.startsWith('RAL ')) {
            return 'custom_ral';
        }
        
        // Check for standard colours
        if (colourValue === 'anthracite_grey' || colourValue === 'black' || colourValue === 'white') {
            return colourValue;
        }
        
        // Default to custom_ral for any other values
        return 'custom_ral';
    }

    // Update inside colour options based on outside colour
    function updateInsideColourOptions(selectedOutsideValue) {
        // If no value provided, get current selection
        if (!selectedOutsideValue) {
            selectedOutsideValue = $('input[name="door_colour"]:checked').val();
        }
        
        if (isDev()) {
            console.log('Updating inside colour options based on outside:', selectedOutsideValue);
        }
        
        // Get all inside colour option cards
        const $anthracite = $('#inside_colour_anthracite').closest('.inside-colour-option');
        const $black = $('#inside_colour_black').closest('.inside-colour-option');
        const $white = $('#inside_colour_white').closest('.inside-colour-option');
        const $custom = $('#inside_colour_custom').closest('.inside-colour-option');
        
        // First, hide all cards
        $anthracite.hide();
        $black.hide();
        $white.hide();
        $custom.hide();
        
        // Determine which cards to show based on outside selection
        switch(selectedOutsideValue) {
            case 'anthracite_grey':
                // Show Anthracite, White, and Custom RAL
                $anthracite.show();
                $white.show();
                $custom.show();
                if (isDev()) console.log('Outside Anthracite: Showing Anthracite, White, Custom');
                break;
                
            case 'black':
                // Show Black and Custom RAL only
                $black.show();
                $custom.show();
                if (isDev()) console.log('Outside Black: Showing Black, Custom');
                break;
                
            case 'white':
                // Show White and Custom RAL only
                $white.show();
                $custom.show();
                if (isDev()) console.log('Outside White: Showing White, Custom');
                break;
                
            case 'custom_ral':
                // Custom RAL outside: Show White and Custom RAL only
                $white.show();
                $custom.show();
                if (isDev()) console.log('Outside Custom RAL: Showing White, Custom');
                break;
                
            default:
                // If outside is a direct RAL value, treat as custom
                $white.show();
                $custom.show();
                if (isDev()) console.log('Outside direct RAL: Showing White, Custom');
                break;
        }
        
        // Validate and adjust selection
        validateInsideColourSelection();
        
        // Update grid layout based on visible options
        updateInsideColourGridLayout();
        
        if (isDev()) {
            const visibleCount = $('.inside-colour-option:visible').length;
            console.log('Visible inside options count:', visibleCount);
        }
    }

    // Update grid layout based on number of visible inside colour options
    function updateInsideColourGridLayout() {
        const visibleOptions = $('.inside-colour-option:visible').length;
        const $grid = $('.colour-inside-options-grid');
        
        // Update grid template columns based on number of visible options
        if (visibleOptions === 1) {
            $grid.css('grid-template-columns', '1fr');
        } else if (visibleOptions === 2) {
            $grid.css('grid-template-columns', 'repeat(2, 1fr)');
        } else if (visibleOptions === 3) {
            $grid.css('grid-template-columns', 'repeat(3, 1fr)');
        } else {
            $grid.css('grid-template-columns', 'repeat(4, 1fr)');
        }
        
        // Also handle responsive layouts
        updateInsideColourResponsiveLayout(visibleOptions);
    }

    // Handle responsive layout for inside colour options
    function updateInsideColourResponsiveLayout(visibleOptions) {
        if ($(window).width() <= 1024) {
            $('.colour-inside-options-grid').css('grid-template-columns', 'repeat(2, 1fr)');
        }
        
        if ($(window).width() <= 768) {
            $('.colour-inside-options-grid').css('grid-template-columns', '1fr');
        }
    }

    // Validate and reset inside colour selection if needed
    function validateInsideColourSelection() {
        const $selectedInsideColour = $('input[name="inside_colour"]:checked');
        
        if ($selectedInsideColour.length) {
            const selectedValue = $selectedInsideColour.val();
            const $selectedCard = $selectedInsideColour.closest('.inside-colour-option');
            
            // If selected card is hidden, we need to select a new one
            if (!$selectedCard.is(':visible')) {
                if (isDev()) console.log('Selected inside colour is hidden - selecting new default');
                
                // Determine which colour to select based on available options
                const outsideValue = $('input[name="door_colour"]:checked').val();
                
                if (outsideValue === 'anthracite_grey') {
                    // Try White first, then Anthracite, then Custom
                    if ($('#inside_colour_white').closest('.inside-colour-option').is(':visible')) {
                        $('#inside_colour_white').prop('checked', true).trigger('change');
                        if (isDev()) console.log('Selected White as default');
                    } else if ($('#inside_colour_anthracite').closest('.inside-colour-option').is(':visible')) {
                        $('#inside_colour_anthracite').prop('checked', true).trigger('change');
                        if (isDev()) console.log('Selected Anthracite as default');
                    } else if ($('#inside_colour_custom').closest('.inside-colour-option').is(':visible')) {
                        $('#inside_colour_custom').prop('checked', true).trigger('change');
                        if (isDev()) console.log('Selected Custom as default');
                    }
                } 
                else if (outsideValue === 'black' || outsideValue === 'white' || outsideValue === 'custom_ral') {
                    // For Black, White, or Custom outside, select White if available
                    if ($('#inside_colour_white').closest('.inside-colour-option').is(':visible')) {
                        $('#inside_colour_white').prop('checked', true).trigger('change');
                        if (isDev()) console.log('Selected White as default');
                    } else if ($('#inside_colour_custom').closest('.inside-colour-option').is(':visible')) {
                        $('#inside_colour_custom').prop('checked', true).trigger('change');
                        if (isDev()) console.log('Selected Custom as default');
                    }
                }
            }
        } else {
            // No selection, choose based on outside colour
            const outsideValue = $('input[name="door_colour"]:checked').val();
            
            if (outsideValue === 'anthracite_grey') {
                if ($('#inside_colour_white').closest('.inside-colour-option').is(':visible')) {
                    $('#inside_colour_white').prop('checked', true).trigger('change');
                    if (isDev()) console.log('No selection - defaulting to White');
                }
            } else {
                if ($('#inside_colour_white').closest('.inside-colour-option').is(':visible')) {
                    $('#inside_colour_white').prop('checked', true).trigger('change');
                    if (isDev()) console.log('No selection - defaulting to White');
                }
            }
        }
        
        // Trigger change to update price and validation
        $('input[name="inside_colour"]:checked').trigger('change');
    }

    // Initialize custom colour dropdowns (jQuery version)
    function initCustomColourDropdowns() {
        // Outside colour dropdown (Step 4)
        const customColourSelect = $('#custom_colour_select');
        const customColourRadio = $('#colour_custom');
        const selectedRalCode = $('.custom-colour-card .selected-ral-code');
        const customColourCard = $('.custom-colour-card');
        const customColourDropdown = $('.custom-colour-dropdown');
        
        // Inside colour dropdown (Step 5)
        const customInsideColourSelect = $('#custom_inside_colour_select');
        const customInsideColourRadio = $('#inside_colour_custom');
        const selectedInsideRalCode = $('.custom-inside-colour-card .selected-inside-ral-code');
        const customInsideColourCard = $('.custom-inside-colour-card');
        const customInsideColourDropdown = $('.custom-inside-colour-dropdown');
        
        // Handle outside colour dropdown
        if (customColourCard.length) {
            customColourCard.on('click', function(e) {
                if (!$(e.target).closest('.custom-colour-dropdown').length) {
                    customColourRadio.prop('checked', true);
                    customColourDropdown.show();
                    customColourRadio.trigger('change');
                }
            });
            
            customColourSelect.on('change', function() {
                if ($(this).val()) {
                    selectedRalCode.text($(this).val());
                    customColourRadio.val($(this).val());
                    const selectedOption = $(this).find('option:selected');
                    const price = selectedOption.data('price') || 195;
                    customColourRadio.data('price', price);
                    customColourRadio.trigger('change');
                    
                    // ===== ADDED: Validate current step =====
                    if (currentStep === 3) { // Step 4
                        validateCurrentStep();
                    }
                }
            });
            
            $('input[name="door_colour"]').on('change', function() {
                if ($(this).attr('id') !== 'colour_custom' && $(this).is(':checked')) {
                    customColourSelect.val('');
                    selectedRalCode.text('From £195 per panel');
                    customColourRadio.val('custom_ral');
                    customColourDropdown.hide();
                    
                    // ===== ADDED: Validate current step =====
                    if (currentStep === 3) { // Step 4
                        validateCurrentStep();
                    }
                }
            });
        }
        
        // Handle inside colour dropdown
        if (customInsideColourCard.length) {
            customInsideColourCard.on('click', function(e) {
                if (!$(e.target).closest('.custom-inside-colour-dropdown').length) {
                    customInsideColourRadio.prop('checked', true);
                    customInsideColourDropdown.show();
                    customInsideColourRadio.trigger('change');
                }
            });
            
            customInsideColourSelect.on('change', function() {
                if ($(this).val()) {
                    selectedInsideRalCode.text($(this).val());
                    customInsideColourRadio.val($(this).val());
                    const selectedOption = $(this).find('option:selected');
                    const price = selectedOption.data('price') || 195;
                    customInsideColourRadio.data('price', price);
                    customInsideColourRadio.trigger('change');
                    
                    // ===== ADDED: Validate current step =====
                    if (currentStep === 4) { // Step 5
                        validateCurrentStep();
                    }
                }
            });
            
            $('input[name="inside_colour"]').on('change', function() {
                if ($(this).attr('id') !== 'inside_colour_custom' && $(this).is(':checked')) {
                    customInsideColourSelect.val('');
                    selectedInsideRalCode.text('From £195 per panel');
                    customInsideColourRadio.val('custom_ral');
                    customInsideColourDropdown.hide();
                    
                    // ===== ADDED: Validate current step =====
                    if (currentStep === 4) { // Step 5
                        validateCurrentStep();
                    }
                }
            });
        }
        
        // Close dropdowns when clicking outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.custom-colour-card').length && 
                !$(e.target).closest('.custom-colour-dropdown').length) {
                customColourDropdown.hide();
            }
            
            if (!$(e.target).closest('.custom-inside-colour-card').length && 
                !$(e.target).closest('.custom-inside-colour-dropdown').length) {
                customInsideColourDropdown.hide();
            }
        });
        
        // Handle window resize for responsive layout
        $(window).on('resize', function() {
            updateInsideColourGridLayout();
        });
    }

    // Show a specific step by index
    function showStep(index) {
        if (index < 0 || index >= totalSteps) return;
        
        // Hide all steps
        steps.removeClass('active');
        
        // Show selected step
        steps.eq(index).addClass('active');
        
        currentStep = index;

        // ===== MAKE CURRENT STEP GLOBALLY ACCESSIBLE =====
        window.currentStep = currentStep;
        // =================================================
        
        updateNavigation();
        
        // Show submit container only on Step 13 (index 12)
        if (index === 12) { // Step 13
            submitContainer.show();
            updateSummary();
            
            // Force update Step 13 data
            if (typeof window.populateStep13 === 'function') {
                setTimeout(function() {
                    window.populateStep13();
                }, 100);
            }
        } else {
            submitContainer.hide();
        }
        
        // ===== FIXED: Previous button enabled for all steps except first =====
        if (index === 0) {
            prevBtn.prop('disabled', true);
        } else {
            prevBtn.prop('disabled', false);
        }
        
        // ===== ADDED: Immediate validation for Step 4 and Step 5 =====
        if (index === 3) { // Step 4
            setTimeout(function() {
                validateCurrentStep();
            }, 100);
        }

        if (index === 4) { // Step 5
            setTimeout(function() {
                // Force validation of inside colour options
                const selectedOutside = $('input[name="door_colour"]:checked').val();
                if (selectedOutside) {
                    updateInsideColourOptions(selectedOutside);
                }
                
                // Ensure a valid selection exists
                validateInsideColourSelection();
                
                // Validate the step
                validateCurrentStep();
            }, 200);
        }
        // ===========================================================
        
        validateCurrentStep();
        
        // Hide colour dropdowns when changing steps
        $('.custom-colour-dropdown, .custom-inside-colour-dropdown').hide();
        
        // Refresh inside colour visibility on step 5 (HTML step 5)
        if (index === 4) {
            updateInsideColourOptions();
            validateInsideColourSelection();
        }
        
        // Special case for Step 10 (Postcode) - index 9
        if (index === 9) { // Step 10
            const postcode = $('#postcode').val().trim();
            if (!postcode) {
                nextBtn.addClass('inactive').prop('disabled', true);
                if (nextFooterBtn.length) {
                    nextFooterBtn.addClass('inactive').prop('disabled', true);
                }
            } else {
                // Trigger delivery check if postcode exists
                setTimeout(function() {
                    $('#postcode').trigger('input');
                }, 100);
            }
        }
        
        // Special case for Step 12 (Customer Information) - index 11
        if (index === 11) {
            const isValid = validateCustomerForm();
            if (!isValid) {
                nextBtn.addClass('inactive').prop('disabled', true);
                if (nextFooterBtn.length) {
                    nextFooterBtn.addClass('inactive').prop('disabled', true);
                }
            }
        }
        
        // Special case for Step 13 (Summary) - index 12
        if (index === 12) {
            // Update summary data immediately
            if (typeof window.populateStep13 === 'function') {
                window.populateStep13();
            }
            
            // Also trigger the custom event
            $(document).trigger('updateSummary');
            
            // Update price display
            updatePrice();
            
            // ===== FIXED: Ensure previous button is enabled on Step 13 =====
            if (index > 0) {
                prevBtn.prop('disabled', false);
            }
        }
        
        // Scroll to top on mobile devices
        if ($(window).width() <= 768) {
            $('html, body').animate({
                scrollTop: $('.door-builder-form').offset().top - 20
            }, 300);
        }
        
        if (isDev()) {
            console.log('Step changed to:', index);
        }
    }

    /**
     * Update navigation buttons based on current step and mode
     * Shows UPDATE CART on last step when in edit mode
     */
    function updateNavigation() {
        // ===== FIXED: Previous button - enabled for all steps except first =====
        if (currentStep === 0) {
            prevBtn.prop('disabled', true);
        } else {
            prevBtn.prop('disabled', false);
        }
        
        // Next button text based on step and mode
        // Step 13 is index 12 (0-based)
        if (currentStep === 12) { // Step 13
            if (editMode) {
                nextBtn.text('UPDATE CART');
                if(nextFooterBtn.length) nextFooterBtn.text('UPDATE CART →');
                if (isDev()) console.log('Button set to: UPDATE CART');
            } else {
                nextBtn.text('ADD TO CART');
                if(nextFooterBtn.length) nextFooterBtn.text('ADD TO CART →');
                if (isDev()) console.log('Button set to: ADD TO CART');
            }
        } else {
            nextBtn.text('NEXT');
            if(nextFooterBtn.length) nextFooterBtn.text('NEXT →');
        }
        
        // ===== ADDED: Extra check for Step 13 to ensure previous button is enabled =====
        if (currentStep === 12) {
            prevBtn.prop('disabled', false);
        }
    }

    function checkAllStepsFilled() {
        // Step 1: Size validation
        const width = $('#width').val();
        const height = $('#height').val();
        if (!width || !height) return false;
        
        const widthNum = parseInt(width);
        const heightNum = parseInt(height);
        if (isNaN(widthNum) || isNaN(heightNum)) return false;
        if (widthNum < 1600 || widthNum > 5800) return false;
        if (heightNum < 1950 || heightNum > 2450) return false;

        // Step 2: Panel Configuration
        if (!$('input[name="panel_layout"]:checked').length) return false;

        // Step 3: Opening Direction
        if (!$('input[name="open_direction"]:checked').length) return false;

        // Step 4: Outside Colour
        if (!$('input[name="door_colour"]:checked').length) return false;

        // Step 5: Inside Colour
        if (!$('input[name="inside_colour"]:checked').length) return false;

        // Step 6: Handle Colour - ADD THIS
        if (!$('input[name="handle_colour"]:checked').length) return false;

        // Step 7: Glass
        if (!$('input[name="glass_upgrade"]:checked').length) return false;

        // Step 8: Trickle Vents
        if (!$('input[name="trickle_vents"]:checked').length) return false;

        // Step 9: Cill - ADD THIS
        if (!$('input[name="cill"]:checked').length) return false;

        return true;
    }

    // Validate current step
    function validateCurrentStep() {

        /**
         * ===== FIXED: Postcode validation for Step 10 =====
         */
        if (currentStep === 9) { // Step 10 (Postcode)
            const postcode = $('#postcode').val().replace(/\s+/g, '').trim();
            if (postcode.length === 0) {
                $('.next-step, .next-footer-btn')
                    .addClass('inactive')
                    .prop('disabled', true);
                return false;
            }
            
            // If we have delivery data, check if bespoke
            if (window.deliveryData && window.deliveryData.bespoke) {
                $('.next-step, .next-footer-btn')
                    .addClass('inactive')
                    .prop('disabled', true);
                return false;
            }
        }

        const isValid = validateStep(currentStep);

        // Special handling for Step 9 (Add Ons) - Always enable Next button
        if (currentStep === 8) { // Step 9 is index 8 (Add-ons)
            nextBtn.removeClass('inactive').prop('disabled', false);
            if(nextFooterBtn.length) {
                nextFooterBtn.removeClass('inactive').prop('disabled', false);
            }
            return true;
        }

        if (currentStep < totalSteps - 1) {
            if (isValid) {
                // Enable Next button if step is valid
                nextBtn.removeClass('inactive').prop('disabled', false);
                if(nextFooterBtn.length) nextFooterBtn.removeClass('inactive').prop('disabled', false);
                
                if (isDev()) console.log('Step', currentStep, 'valid - Next button enabled');
            } else {
                // Disable Next button if step is invalid
                nextBtn.addClass('inactive').prop('disabled', true);
                if(nextFooterBtn.length) nextFooterBtn.addClass('inactive').prop('disabled', true);
                
                if (isDev()) console.log('Step', currentStep, 'invalid - Next button disabled');
            }
        }

        return isValid;
    }

    // Add/remove error class on input wrapper
    function updateInputErrorState(inputId, hasError) {
        const $input = $('#' + inputId);
        const $wrapper = $input.closest('.input-wrapper');
        
        if (hasError) {
            $wrapper.addClass('error');
        } else {
            $wrapper.removeClass('error');
        }
    }

    /**
     * Validate a specific step based on its index
     */
    function validateStep(stepIndex) {
        // Step 1: Size (HTML step 1) - index 0
        if (stepIndex === 0) {
            const width = $('#width').val();
            const height = $('#height').val();
            const widthError = $('#width-error');
            const heightError = $('#height-error');
            
            widthError.hide();
            heightError.hide();
            updateInputErrorState('width', false);
            updateInputErrorState('height', false);

            let isValid = true;

            if (!width) {
                widthError.text('Width is required.').show();
                updateInputErrorState('width', true);
                isValid = false;
            } else {
                const widthNum = parseInt(width);
                if (isNaN(widthNum)) {
                    widthError.text('Width must be a valid number.').show();
                    isValid = false;
                } else if (widthNum < 1600 || widthNum > 5800) {
                    widthError.text('Width must be between 1600 and 5800 mm.').show();
                    isValid = false;
                }
            }

            if (!height) {
                heightError.text('Height is required.').show();
                updateInputErrorState('height', true);
                isValid = false;
            } else {
                const heightNum = parseInt(height);
                if (isNaN(heightNum)) {
                    heightError.text('Height must be a valid number.').show();
                    isValid = false;
                } else if (heightNum < 1950 || heightNum > 2450) {
                    heightError.text('Height must be between 1950 and 2450 mm.').show();
                    isValid = false;
                }
            }

            return isValid;
        }

        // Step 2: Panel Configuration (HTML step 2) - index 1
        if (stepIndex === 1) {
            return $('input[name="panel_layout"]:checked').length > 0;
        }

        // Step 3: Opening Direction (HTML step 3) - index 2
        if (stepIndex === 2) {
            return $('input[name="open_direction"]:checked').length > 0;
        }

        // Step 4: Outside Colour (HTML step 4) - index 3
        if (stepIndex === 3) {
            const selectedColour = $('input[name="door_colour"]:checked').val();
            
            // If custom RAL is selected, check if a RAL code is selected from dropdown
            if (selectedColour === 'custom_ral') {
                const customRalValue = $('#custom_colour_select').val();
                return customRalValue && customRalValue !== '';
            }
            
            // For standard colours, just check if any radio is checked
            return $('input[name="door_colour"]:checked').length > 0;
        }

        // Step 5: Inside Colour (HTML step 5) - index 4
        if (stepIndex === 4) {
            // First check if any radio is selected
            const hasSelection = $('input[name="inside_colour"]:checked').length > 0;
            
            if (!hasSelection) {
                if (isDev()) console.log('Step 5 validation failed: No selection');
                return false;
            }
            
            const selectedValue = $('input[name="inside_colour"]:checked').val();
            
            if (isDev()) console.log('Step 5 validation - Selected value:', selectedValue);
            
            // If custom RAL is selected, check if a RAL code is selected from dropdown
            if (selectedValue === 'custom_ral') {
                const customRalValue = $('#custom_inside_colour_select').val();
                const isValid = customRalValue && customRalValue !== '';
                if (isDev()) console.log('Custom RAL validation:', isValid ? 'PASSED' : 'FAILED', 'Value:', customRalValue);
                return isValid;
            }
            
            // For standard colours, just check if the selected option is visible
            const $selectedCard = $(`input[name="inside_colour"][value="${selectedValue}"]`).closest('.inside-colour-option');
            const isVisible = $selectedCard.is(':visible');
            
            if (isDev()) console.log('Standard colour validation - Visible:', isVisible);
            
            return isVisible;
        }

        // Step 6: Handle Colour (HTML step 6) - index 5
        if (stepIndex === 5) {
            return $('input[name="handle_colour"]:checked').length > 0;
        }

        // Step 7: Glass (HTML step 7) - index 6
        if (stepIndex === 6) {
            return $('input[name="glass_upgrade"]:checked').length > 0;
        }

        // Step 8: Trickle Vents (HTML step 8) - index 7
        if (stepIndex === 7) {
            return $('input[name="trickle_vents"]:checked').length > 0;
        }

        // Step 9: Cill (HTML step 9) - index 8
        if (stepIndex === 8) {
            return $('input[name="cill"]:checked').length > 0;
        }

        // ===== FIXED: Step 10: Postcode (HTML step 10) - index 9 =====
        if (stepIndex === 9) {
            const postcode = $('#postcode').val().replace(/\s+/g, '').trim();
            
            // Postcode must be non-empty
            if (postcode.length === 0) {
                if (isDev()) console.log('Step 10 validation failed: Empty postcode');
                return false;
            }
            
            // Check if delivery is bespoke (if we have delivery data)
            if (window.deliveryData && window.deliveryData.bespoke) {
                if (isDev()) console.log('Step 10 validation failed: Bespoke delivery');
                return false; // Bespoke delivery - cannot proceed
            }
            
            // If we have delivery data, any non-bespoke is valid
            if (window.deliveryData && !window.deliveryData.bespoke) {
                if (isDev()) console.log('Step 10 validation passed: Delivery calculated');
                return true;
            }
            
            // If no delivery data yet, we need to wait for AJAX
            // The button will be enabled/disabled by the AJAX response
            if (isDev()) console.log('Step 10 validation: Waiting for delivery data');
            return false;
        }

        // Step 11: Access Issues (HTML step 11) - index 10
        if (stepIndex === 10) {
            const accessSelected = $('input[name="access_issues"]:checked').length > 0;
            
            if ($('#access_yes').is(':checked')) {
                const description = $('#access_description').val();
                return accessSelected && description && description.trim() !== '';
            }
            
            return accessSelected;
        }

        // Step 12: Customer Information (HTML step 12) - index 11
        if (stepIndex === 11) {
            return validateCustomerForm();
        }

        // Step 13: Summary (HTML step 13) - index 12
        if (stepIndex === 12) {
            // Check if delivery is allowed
            const isBespoke = (window.deliveryData && window.deliveryData.bespoke) || $('#delivery_bespoke').val() === '1';
            
            if (isBespoke) {
                return false; // Cannot proceed with bespoke delivery
            }
            
            // All fields should be valid - return true to enable next button
            // Next button is actually ADD TO CART on this step
            return true;
        }

        return false;
    }

    /**
     * Validate customer information form (Step 12)
     * Checks if all 4 fields are filled and valid
     * @returns {boolean} - True if all fields are valid
     */
    function validateCustomerForm() {
        const firstName = $('#first_name').val().trim();
        const lastName = $('#last_name').val().trim();
        const mobile = $('#mobile_number').val().trim();
        const email = $('#email_address').val().trim();
        
        // Basic email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const isValidEmail = emailRegex.test(email);
        
        // Basic mobile validation (UK format - 10-11 digits)
        const mobileRegex = /^[0-9]{10,11}$/;
        const isValidMobile = mobileRegex.test(mobile.replace(/\s/g, ''));
        
        // All fields must be filled and valid
        const isValid = firstName && lastName && mobile && email && isValidEmail && isValidMobile;
        
        if (isDev()) {
            console.log('Customer form validation:', isValid ? 'PASSED' : 'FAILED');
            console.log('Name:', firstName, lastName, 'Mobile:', mobile, 'Email:', email);
        }
        
        return isValid;
    }

    /**
     * Recalculate total price - WITH DUAL COLOUR LOGIC
     * Only charge for custom RAL and non-standard dual combinations
     */
    function updatePrice() {
        let base = parseFloat($('#base_price_value').val());
        if (isNaN(base)) {
            base = 0;
        }

        let extra = 0;
        
        // Get pane count from selected panel
        let paneCount = 1;
        const selectedPanel = $('input[name="panel_layout"]:checked').val();
        if (selectedPanel) {
            if (selectedPanel === 'french') {
                paneCount = 2;
            } else if (selectedPanel.includes('_')) {
                const parts = selectedPanel.split('_');
                if (parts.length === 2 && !isNaN(parseInt(parts[0])) && !isNaN(parseInt(parts[1]))) {
                    paneCount = parseInt(parts[0]) + parseInt(parts[1]);
                } else {
                    const match = selectedPanel.match(/^(\d+)/);
                    if (match) paneCount = parseInt(match[1]);
                }
            } else {
                const match = selectedPanel.match(/^(\d+)/);
                if (match) paneCount = parseInt(match[1]);
            }
        }

        // ===== COLOUR PRICING LOGIC =====
        // Standard colours (no charge): anthracite_grey, black, white
        // Free dual colour: anthracite_grey outside + white inside
        // All other dual combinations are chargeable (£195 per pane per colour)
        
        // Get selected colours
        const outsideColour = $('input[name="door_colour"]:checked').val();
        const insideColour = $('input[name="inside_colour"]:checked').val();
        
        // Get custom RAL values if selected
        const customRalValue = $('#custom_colour_select').val();
        const customInsideRalValue = $('#custom_inside_colour_select').val();
        
        // Define standard colours
        const standardColours = ['anthracite_grey', 'black', 'white'];
        
        // Check if outside colour is standard or custom
        let isOutsideStandard = false;
        let isOutsideCustom = false;
        
        if (outsideColour === 'custom_ral' && customRalValue && customRalValue !== '') {
            isOutsideCustom = true;
            if (isDev()) console.log('Outside colour - custom RAL:', customRalValue);
        } else if (outsideColour && !standardColours.includes(outsideColour) && outsideColour !== 'custom_ral') {
            // Direct RAL value (from edit mode)
            isOutsideCustom = true;
            if (isDev()) console.log('Outside colour - direct RAL:', outsideColour);
        } else if (outsideColour && standardColours.includes(outsideColour)) {
            isOutsideStandard = true;
            if (isDev()) console.log('Outside colour - standard:', outsideColour);
        }
        
        // Check if inside colour is standard or custom
        let isInsideStandard = false;
        let isInsideCustom = false;
        
        if (insideColour === 'custom_ral' && customInsideRalValue && customInsideRalValue !== '') {
            isInsideCustom = true;
            if (isDev()) console.log('Inside colour - custom RAL:', customInsideRalValue);
        } else if (insideColour && !standardColours.includes(insideColour) && insideColour !== 'custom_ral') {
            // Direct RAL value (from edit mode)
            isInsideCustom = true;
            if (isDev()) console.log('Inside colour - direct RAL:', insideColour);
        } else if (insideColour && standardColours.includes(insideColour)) {
            isInsideStandard = true;
            if (isDev()) console.log('Inside colour - standard:', insideColour);
        }
        
        // ===== DUAL COLOUR LOGIC =====
        // Check if this is the specific free dual combination: Anthracite Grey outside / White inside
        const isFreeDualColour = (
            outsideColour === 'anthracite_grey' && 
            insideColour === 'white' &&
            !isOutsideCustom && 
            !isInsideCustom
        );
        
        // Check if this is a same-colour both sides (also free - stock)
        const isSameStandardColour = (
            outsideColour === insideColour && 
            standardColours.includes(outsideColour) &&
            !isOutsideCustom && 
            !isInsideCustom
        );
        
        // Check if this is a standard dual colour (both standard but different)
        // These are CHARGEABLE according to client requirements
        const isStandardDualColour = (
            isOutsideStandard && 
            isInsideStandard && 
            outsideColour !== insideColour &&
            !isFreeDualColour // Exclude the one free dual
        );
        
        // ===== PRICE CALCULATION =====
        let outsideColourPrice = 0;
        let insideColourPrice = 0;
        
        if (isFreeDualColour || isSameStandardColour) {
            // Free combinations
            if (isDev()) {
                if (isFreeDualColour) console.log('Free dual colour: Anthracite Grey outside / White inside');
                if (isSameStandardColour) console.log('Free same colour both sides:', outsideColour);
            }
            outsideColourPrice = 0;
            insideColourPrice = 0;
        } 
        else if (isStandardDualColour) {
            // Standard dual colours (different standard colours) ARE CHARGEABLE
            // According to client: any combination other than Anthracite/White is chargeable
            outsideColourPrice = 195 * paneCount;
            insideColourPrice = 195 * paneCount;
            if (isDev()) console.log('Standard dual colour - CHARGEABLE:', outsideColour, '+', insideColour);
        }
        else {
            // Any combination involving custom colours
            if (isOutsideCustom) {
                outsideColourPrice = 195 * paneCount;
                if (isDev()) console.log('Outside custom charge: £' + (195 * paneCount));
            }
            
            if (isInsideCustom) {
                insideColourPrice = 195 * paneCount;
                if (isDev()) console.log('Inside custom charge: £' + (195 * paneCount));
            }
        }
        
        // Add colour prices to extra
        extra += outsideColourPrice;
        extra += insideColourPrice;

        // Add other selected options prices (glass, trickle vents, etc.)
        $('.price-option:checked').each(function(){
            // Skip custom RAL radios (already handled above)
            const id = $(this).attr('id');
            if (id === 'colour_custom' || id === 'inside_colour_custom') {
                return true; // continue
            }
            
            let price = parseFloat($(this).data('price'));
            if (!isNaN(price)) {
                if ($(this).data('per-pane') === true) {
                    extra += price * paneCount;
                } else if ($(this).data('per-order') === true) {
                    extra += price;
                } else {
                    extra += price;
                }
            }
        });

        let total = base + extra;

        // Update displays
        $('#final-price-confirm').text('£' + total.toFixed(2));
        $('#submit-price').text('£' + total.toFixed(2));
        $('#final_price_input').val(total.toFixed(2));
        
        window.lastCalculatedPrice = total.toFixed(2);
        
        if (isDev()) {
            console.log('Price calculation - Base:', base, 
                        'Outside:', outsideColourPrice, 
                        'Inside:', insideColourPrice, 
                        'Other:', (extra - outsideColourPrice - insideColourPrice), 
                        'Total:', total,
                        'Free Dual:', isFreeDualColour,
                        'Same Standard:', isSameStandardColour,
                        'Standard Dual:', isStandardDualColour);
        }
        
        return total;
    }

    /**
     * Update order summary on last step
     */
    function updateSummary() {
        if (currentStep === totalSteps - 1) {
            if (isDev()) {
                console.log('Updating summary from wizard.js - Step 14');
            }
            
            // === STEP 1: Manufacturing Size ===
            const width = $('#width').val() || '';
            const height = $('#height').val() || '';
            if (width && height) {
                $('#summary-size').text(width + ' x ' + height);
                if (isDev()) {
                    console.log('Size set:', width + ' x ' + height);
                }
            } else {
                $('#summary-size').text('—');
            }
            
            // === STEP 2: Panels ===
            const panelValue = $('input[name="panel_layout"]:checked').val();
            if (isDev()) {
                console.log('Panel value:', panelValue);
            }

            if (panelValue) {
                // Try multiple ways to get the panel text
                let panelText = '';
                
                // Method 1: Get text from label's option-name
                panelText = $('input[name="panel_layout"]:checked').closest('label').find('.option-name').text().trim();
                if (isDev()) {
                    console.log('Panel text method 1:', panelText);
                }
                
                // Method 2: If Method 1 fails, try getting from parent card
                if (!panelText) {
                    panelText = $('input[name="panel_layout"]:checked').closest('.panel-option-card').find('.option-name').text().trim();
                    if (isDev()) {
                        console.log('Panel text method 2:', panelText);
                    }
                }
                
                // Method 3: Manual mapping based on value (if still empty)
                if (!panelText) {
                    const panelMap = {
                        '2_left': '2 Panels Left',
                        '2_right': '2 Panels Right',
                        '1_2': '1 + 2 Panels',
                        '2_1': '2 + 1 Panels',
                        '3_left': '3 Panels Left',
                        '3_right': '3 Panels Right',
                        '1_3': '1 + 3 Panels',
                        '3_1': '3 + 1 Panels',
                        '2_2': '2 + 2 Panels',
                        '4_left': '4 Panels Left',
                        '4_right': '4 Panels Right',
                        '1_4': '1 + 4 Panels',
                        '4_1': '4 + 1 Panels',
                        '2_3': '2 + 3 Panels',
                        '3_2': '3 + 2 Panels',
                        '5_left': '5 Panels Left',
                        '5_right': '5 Panels Right',
                        '1_5': '1 + 5 Panels',
                        '2_4': '2 + 4 Panels',
                        '3_3': '3 + 3 Panels',
                        '4_2': '4 + 2 Panels',
                        '5_1': '5 + 1 Panels',
                        '6_left': '6 Panels Left',
                        '6_right': '6 Panels Right',
                        'french': 'French Doors'
                    };
                    panelText = panelMap[panelValue] || panelValue;
                    if (isDev()) {
                        console.log('Panel text method 3 (mapping):', panelText);
                    }
                }
                
                // Set the panel text
                $('#summary-panels').text(panelText || '—');
                
                // Stacking Direction
                if (panelValue.includes('left')) {
                    $('#summary-stacking').text('Left');
                } else if (panelValue.includes('right')) {
                    $('#summary-stacking').text('Right');
                } else {
                    $('#summary-stacking').text('—');
                }
            } else {
                $('#summary-panels').text('—');
                $('#summary-stacking').text('—');
            }
            
            // === STEP 3: Opening Direction ===
            const openingValue = $('input[name="open_direction"]:checked').val();
            if (openingValue) {
                const openingText = openingValue === 'inwards' ? 'Inwards' : 'Outwards';
                $('#summary-opening').text(openingText);
            } else {
                $('#summary-opening').text('—');
            }
            
            // === STEP 4: Outside Colour - With RAL code ===
            const outsideColour = $('input[name="door_colour"]:checked').val();
            const customRalValue = $('#custom_colour_select').val();
            let outsideText = '—';

            if (outsideColour === 'custom_ral' && customRalValue && customRalValue !== '') {
                outsideText = customRalValue;
            } else {
                const colourMap = {
                    'anthracite_grey': 'Anthracite Grey',
                    'black': 'Black',
                    'white': 'White'
                };
                outsideText = colourMap[outsideColour] || outsideColour || '—';
                
                const ralMap = {
                    'anthracite_grey': '7016',
                    'black': '9005',
                    'white': '9016'
                };
                if (ralMap[outsideColour]) {
                    outsideText += ' (RAL ' + ralMap[outsideColour] + ')';
                }
            }
            $('#summary-outside-colour').text(outsideText);

            // === STEP 5: Inside Colour - With RAL code ===
            const insideColour = $('input[name="inside_colour"]:checked').val();
            const customInsideRalValue = $('#custom_inside_colour_select').val();
            let insideText = '—';

            if (insideColour === 'custom_ral' && customInsideRalValue && customInsideRalValue !== '') {
                insideText = customInsideRalValue;
            } else {
                const colourMap = {
                    'anthracite_grey': 'Anthracite Grey',
                    'black': 'Black',
                    'white': 'White'
                };
                insideText = colourMap[insideColour] || insideColour || '—';
                
                const ralMap = {
                    'anthracite_grey': '7016',
                    'black': '9005',
                    'white': '9016'
                };
                if (ralMap[insideColour]) {
                    insideText += ' (RAL ' + ralMap[insideColour] + ')';
                }
            }
            $('#summary-inside-colour').text(insideText);
            
            // === STEP 6: Handle Colour - UPDATED MAPPING ===
            const handleColour = $('input[name="handle_colour"]:checked').val();
            if (handleColour) {
                // Map form values back to display text
                const handleDisplayMap = {
                    'white': 'White',
                    'chrome': 'Chrome',
                    'black': 'Black',
                    'black_white': 'Black and White'
                };
                
                const displayText = handleDisplayMap[handleColour] || handleColour;
                $('#summary-handle-colour').text(displayText);
                
                if (isDev()) {
                    console.log('Handle display - Value:', handleColour, '→ Display:', displayText);
                }
            } else {
                $('#summary-handle-colour').text('—');
            }

            // === STEP 7: Glass ===
            const glassValue = $('input[name="glass_upgrade"]:checked').val();
            if (isDev()) {
                console.log('Glass value:', glassValue);
            }

            if (glassValue) {
                // Get the full glass text from the label
                const glassText = $('input[name="glass_upgrade"]:checked').closest('.glass-option-card').find('.option-name').text().trim();
                
                if (glassText) {
                    $('#summary-glass').text(glassText);
                } else {
                    // Fallback mapping
                    const glassMap = {
                        'self_cleaning': 'Self-cleaning glass',
                        'integral_blinds': 'Integral blinds',
                        'obscure_glass': 'Obscure glass',
                        'saint_gobain_12': 'Saint-Gobain Planitherm 1.2'
                    };
                    $('#summary-glass').text(glassMap[glassValue] || glassValue);
                }
            } else {
                $('#summary-glass').text('—');
            }
            
            // === STEP 8: Trickle Vents ===
            const trickleVents = $('input[name="trickle_vents"]:checked').val();
            let trickleText = '';
            let tricklePrice = '';

            if (trickleVents === 'yes_trickle') {
                trickleText = 'Yes, Add Trickle Vent';
                tricklePrice = ' (+£85)';
            } else {
                trickleText = 'No';
                tricklePrice = '';
            }

            $('#summary-trickle-vents').text(trickleText + tricklePrice);
            $('#summary_trickle_vents_field').val(trickleText);
            
            // === STEP 9: Cill - DISPLAY ONLY ===
            const cillValue = $('input[name="cill"]:checked').val();
            let cillDisplayText = '—';

            if (cillValue) {
                if (cillValue === 'none') {
                    cillDisplayText = 'No Cill';
                } else if (cillValue === '150mm-aluminium-cill') {
                    cillDisplayText = '150mm Aluminium Cill';
                } else if (cillValue === '150mm-upvc-cill') {
                    cillDisplayText = '150mm uPVC Cill';
                } else {
                    cillDisplayText = cillValue;
                }
            }

            $('#summary-cill').text(cillDisplayText);
            $('#summary_cill_field').val(cillDisplayText);

            if (isDev()) {
                console.log('Cill display:', cillDisplayText);
            }
            
            // === STEP 10: Postcode ===
            const postcode = $('#postcode').val() || '';
            if (postcode) {
                $('#summary-postcode').text(postcode);
                if (isDev()) {
                    console.log('Postcode found:', postcode);
                }
            } else {
                $('#summary-postcode').text('—');
            }
            
            // ===== NEW: Delivery Summary (based on postcode) =====
            updateDeliverySummaryInSummary();
            // =====================================================
            
            // === STEP 11: Access Issues ===
            const accessIssues = $('input[name="access_issues"]:checked').val();
            if (accessIssues === 'yes_access') {
                const accessDesc = $('#access_description').val() || 'Nothing Special';
                $('#summary-access').text('Yes, ' + accessDesc);
            } else {
                $('#summary-access').text('No');
            }
            
            // === Hinge Colour (if exists) ===
            const hingeColour = $('input[name="hinge_colour"]:checked').val();
            if (hingeColour) {
                const hingeMap = {
                    'black': 'Black',
                    'white': 'White',
                    'silver': 'Silver'
                };
                $('#summary-hinge-colour').text(hingeMap[hingeColour] || hingeColour);
            } else {
                $('#summary-hinge-colour').text('—');
            }
            
            // === Astragal Bars ===
            const astragal = $('input[name="astragal"]:checked').val();
            $('#summary-astragal').text(astragal ? 'Yes' : 'No');
            
            // === Blinds ===
            const blinds = $('input[name="blinds"]:checked').val();
            $('#summary-blinds').text(blinds ? 'Yes' : 'No');
            
            // === Top/Left/Right Addons ===
            const topAddon = $('input[name="addition"]:checked[value*="top"]').val();
            $('#summary-top-addon').text(topAddon ? 'Yes' : '0mm');
            
            const leftAddon = $('input[name="addition"]:checked[value*="left"]').val();
            $('#summary-left-addon').text(leftAddon ? 'Yes' : '0mm');
            
            const rightAddon = $('input[name="addition"]:checked[value*="right"]').val();
            $('#summary-right-addon').text(rightAddon ? 'Yes' : '0mm');
            
            // === Update Price (includes delivery now) ===
            updatePrice();
            const totalPrice = $('#final-price-confirm').text().replace('£', '') || '0.00';
            $('#summary-total-price').text(totalPrice);
            $('#submit-price').text('£' + totalPrice);
            
            // === Update Submit Button based on delivery status ===
            updateSubmitButtonWithDelivery(totalPrice);
            
            // === Trigger custom event for Step 14 ===
            $(document).trigger('updateSummary');
            
            if (isDev()) {
                console.log('Summary update complete');
                console.log('- Panels:', $('#summary-panels').text());
                console.log('- Glass:', $('#summary-glass').text());
                console.log('- Postcode:', $('#summary-postcode').text());
                console.log('- Delivery:', $('#summary-delivery').text());
            }
        }
    }

    /**
     * NEW: Update delivery summary with proper formatting
     */
    function updateDeliverySummaryInSummary() {
        // Check if we have delivery data
        let deliveryPrice = 0;
        let deliveryZone = '';
        let deliveryDistance = '';
        let isBespoke = false;
        let deliveryDisplay = '—';
        
        // Get delivery data from various sources
        if (window.deliveryData) {
            deliveryPrice = parseFloat(window.deliveryData.price) || 0;
            deliveryZone = window.deliveryData.zone || '';
            deliveryDistance = window.deliveryData.distance ? parseFloat(window.deliveryData.distance).toFixed(1) + ' miles' : '';
            isBespoke = window.deliveryData.bespoke || false;
        } else {
            // Fallback to hidden fields
            deliveryPrice = parseFloat($('#delivery_price').val()) || 0;
            deliveryZone = $('#delivery_zone').val() || '';
            deliveryDistance = $('#delivery_distance').val() ? parseFloat($('#delivery_distance').val()).toFixed(1) + ' miles' : '';
            isBespoke = $('#delivery_bespoke').val() === '1';
        }
        
        // Format delivery display text
        if (isBespoke) {
            deliveryDisplay = 'Bespoke (call for quote)';
        } else {
            const priceText = deliveryPrice === 0 ? 'FREE' : '£' + deliveryPrice.toFixed(2);
            if (deliveryZone && deliveryDistance) {
                deliveryDisplay = priceText + ' (' + deliveryZone + ', ' + deliveryDistance + ')';
            } else if (deliveryZone) {
                deliveryDisplay = priceText + ' (' + deliveryZone + ')';
            } else {
                deliveryDisplay = priceText;
            }
        }
        
        // Check if delivery row exists in summary
        if ($('#summary-delivery').length) {
            // Update existing delivery row
            $('#summary-delivery').text(deliveryDisplay);
            
            // Add class for bespoke styling
            if (isBespoke) {
                $('#summary-delivery').addClass('bespoke-delivery-value');
            } else {
                $('#summary-delivery').removeClass('bespoke-delivery-value');
            }
        } else {
            // Add delivery row to summary if it doesn't exist
            addDeliveryRowToSummary(deliveryDisplay, isBespoke);
        }
        
        // Store delivery display in hidden field for form submission
        $('#summary_delivery_field').val(deliveryDisplay);
    }

    /**
     * NEW: Add delivery row to summary grid
     */
    function addDeliveryRowToSummary(deliveryDisplay, isBespoke) {
        // Find the summary grid
        const $summaryGrid = $('.summary-grid');
        if ($summaryGrid.length) {
            // Check where to insert (after postcode or before total)
            let $insertAfter = $('#summary-postcode').closest('.summary-row');
            
            if ($insertAfter.length === 0) {
                // If postcode row not found, insert before total price
                $insertAfter = $('.summary-row.total-price').prev();
            }
            
            if ($insertAfter.length) {
                const bespokeClass = isBespoke ? 'bespoke-delivery' : '';
                const deliveryRow = '<div class="summary-row delivery-row ' + bespokeClass + '">' +
                                    '<span class="summary-label">Delivery:</span>' +
                                    '<span class="summary-value" id="summary-delivery">' + deliveryDisplay + '</span>' +
                                    '</div>';
                
                $insertAfter.after(deliveryRow);
            } else {
                // If no suitable position, append to summary grid
                $summaryGrid.append('<div class="summary-row delivery-row">' +
                                    '<span class="summary-label">Delivery:</span>' +
                                    '<span class="summary-value" id="summary-delivery">' + deliveryDisplay + '</span>' +
                                    '</div>');
            }
        }
    }

    /**
     * NEW: Update submit button based on delivery status
     */
    function updateSubmitButtonWithDelivery(totalPrice) {
        const isBespoke = (window.deliveryData && window.deliveryData.bespoke) || $('#delivery_bespoke').val() === '1';
        
        if (isBespoke) {
            $('#submit-btn').text('CONTACT SALES - £' + totalPrice)
                        .removeClass('add-to-cart-btn checkout-btn')
                        .addClass('bespoke-btn')
                        .prop('disabled', true)
                        .attr('title', 'Bespoke delivery required - please call our sales team');
        } else {
            $('#submit-btn').text('ADD TO CART - £' + totalPrice)
                        .removeClass('bespoke-btn checkout-btn')
                        .addClass('add-to-cart-btn')
                        .prop('disabled', false)
                        .removeAttr('title');
        }
    }

    // ==================== GO TO NEXT STEP ====================
    function goNextStep() {
        // Block going next if current step is invalid
        if (!validateCurrentStep()) {
            return;
        }

        if (currentStep < totalSteps - 1) {
            let nextIndex = currentStep + 1;

            // Step 8 (Trickle Vents) → next step is Cill
            if (currentStep === 7) {
                nextIndex = 8; // HTML step 9: Cill
            }
            // Step 9 (Cill) → next step is Postcode
            else if (currentStep === 8) {
                nextIndex = 9; // HTML step 10: Postcode
            }
            // Step 10 (Postcode) → next step is Access Issues
            else if (currentStep === 9) {
                nextIndex = 10; // HTML step 11: Access Issues
            }
            // Step 11 (Access Issues) → next step is Customer Information
            else if (currentStep === 10) {
                nextIndex = 11; // HTML step 12: Customer Information
            }
            // Step 12 (Customer Information) → next step is Summary
            else if (currentStep === 11) {
                nextIndex = 12; // HTML step 13: Summary
            }
            // All other steps → normal next
            
            // ===== IMPORTANT: showStep() কল করতে হবে =====
            showStep(nextIndex);
        } else {
            // Last step → submit form
            submitBuilderForm();
        }
    }

    // ==================== GO TO PREVIOUS STEP ====================
    function goPrevStep() {
        if (currentStep > 0) {
            let prevIndex = currentStep - 1;

            // Step 8 (Trickle Vents) → next step is Cill
            if (currentStep === 7) {
                prevIndex = 6; // HTML step 7: Glass
            }
            // Step 9 (Cill) → go back to Trickle Vents
            else if (currentStep === 8) {
                prevIndex = 7; // HTML step 8: Trickle Vents
            }
            // Step 10 (Postcode) → go back to Cill
            else if (currentStep === 9) {
                prevIndex = 8; // HTML step 9: Cill
            }
            // Step 11 (Access Issues) → go back to Postcode
            else if (currentStep === 10) {
                prevIndex = 9; // HTML step 10: Postcode
            }
            // Step 12 (Customer Information) → go back to Access Issues
            else if (currentStep === 11) {
                prevIndex = 10; // HTML step 11: Access Issues
            }
            // ===== FIXED: Step 13 (Summary) → go back to Customer Information =====
            else if (currentStep === 12) { // Step 13
                prevIndex = 11; // HTML step 12: Customer Information
            }
            // All other steps → normal previous
            
            // ===== IMPORTANT: showStep() কল করতে হবে =====
            showStep(prevIndex);
            
            if (isDev()) {
                console.log('Going to previous step:', prevIndex);
            }
        }
    }

    /**
     * Submit builder form via AJAX
     */
    function submitBuilderForm() {
        // Check if all required fields are filled
        if (!validateStep(0)) {
            showStep(0);
            return;
        }
        
        // ===== NEW: Check for bespoke delivery =====
        const isBespoke = (window.deliveryData && window.deliveryData.bespoke) || $('#delivery_bespoke').val() === '1';
        if (isBespoke) {
            alert('Bespoke delivery required. Please call our sales team to complete your order.');
            return;
        }
        // ===========================================
        
        // First, make sure Step 14 data is populated
        if (typeof window.populateStep14 === 'function') {
            window.populateStep14();
        }
        
        // Get form data including all hidden fields
        const formData = $('#door-builder-form').serialize();
        
        // Show loading state
        const originalText = submitBtn.html();
        submitBtn.addClass('loading');
        submitBtn.prop('disabled', true);
        
        if (editMode) {
            submitBtn.html('<span class="loading-spinner"></span> Updating Cart...');
        } else {
            submitBtn.html('<span class="loading-spinner"></span> Adding to Cart...');
        }
        
        // ===== FIXED: Add mode and cart key correctly =====
        let dataToSend = formData + '&builder_checkout=0';
        
        // Log for debugging
        if (isDev()) {
            console.log('Edit Mode:', editMode);
            console.log('Edit Cart Key:', editCartKey);
            console.log('Window Edit Cart Key:', window.editCartKey);
        }
        
        if (editMode) {
            // Get cart key from multiple sources
            const cartKey = editCartKey || window.editCartKey || $('#cart_item_key_field').val() || '';
            
            if (cartKey) {
                dataToSend += '&edit_mode=1&cart_item_key=' + encodeURIComponent(cartKey);
                
                if (isDev()) {
                    console.log('Cart Key found:', cartKey);
                    console.log('Data being sent:', dataToSend);
                }
            } else {
                console.error('No cart key found for edit mode!');
                alert('Error: Cart item key not found. Please try again.');
                submitBtn.removeClass('loading');
                submitBtn.html(originalText);
                submitBtn.prop('disabled', false);
                return;
            }
        }
        
        // AJAX request
        $.ajax({
            url: door_builder_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'process_door_builder',
                form_data: dataToSend,
                security: door_builder_vars.nonce
            },
            success: function(response) {
                if (response.success) {
                    window.location.href = door_builder_vars.cart_url;
                } else {
                    alert('Error: ' + (response.data.message || 'Unknown error'));
                    submitBtn.removeClass('loading');
                    submitBtn.html(originalText);
                    submitBtn.prop('disabled', false);
                }
            },
            error: function(xhr, status, error) {
                if (isDev()) {
                    console.log('AJAX Error:', xhr.responseText);
                }
                alert('Network error. Please try again.');
                submitBtn.removeClass('loading');
                submitBtn.html(originalText);
                submitBtn.prop('disabled', false);
            }
        });
    }

    // ==================== EVENT HANDLERS ====================

    /**
     * Customer Information Form Validation
     * Real-time validation for Step 13 fields
     */
    $(document).on('input', '#first_name, #last_name, #mobile_number, #email_address', function() {
        const fieldId = $(this).attr('id');
        
        // Format mobile number (digits only)
        if (fieldId === 'mobile_number') {
            let val = $(this).val().replace(/\D/g, '');
            $(this).val(val);
        }
        
        // Only validate if we are on Step 13
        if (currentStep === 12) { // HTML step 13 = index 12
            validateCurrentStep();
        }
    });

    // Email validation on blur
    $(document).on('blur', '#email_address', function() {
        if (currentStep === 12) {
            const email = $(this).val().trim();
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if (email && !emailRegex.test(email)) {
                $(this).addClass('error');
            } else {
                $(this).removeClass('error');
            }
            validateCurrentStep();
        }
    });

    // Mobile validation on blur
    $(document).on('blur', '#mobile_number', function() {
        if (currentStep === 12) {
            const mobile = $(this).val().trim();
            const mobileRegex = /^[0-9]{10,11}$/;
            
            if (mobile && !mobileRegex.test(mobile)) {
                $(this).addClass('error');
            } else {
                $(this).removeClass('error');
            }
            validateCurrentStep();
        }
    });

    // Recalculate price and validate when dimensions change
    $(document).on('input', '#width, #height', function() {
        const $input = $(this);
        const value = $input.val();
        const min = parseInt($input.attr('min')) || 1600; // Updated default
        const max = parseInt($input.attr('max'));
        const isWidth = $input.attr('id') === 'width';
        const $error = isWidth ? $('#width-error') : $('#height-error');
        
        // Reset error
        $error.hide();
        updateInputErrorState($input.attr('id'), false);
        
        // Validate input
        if (value) {
            const numValue = parseInt(value);
            if (isNaN(numValue)) {
                $error.text((isWidth ? 'Width' : 'Height') + ' must be a valid number.').show();
                updateInputErrorState($input.attr('id'), true);
            } else if (numValue < min || numValue > max) {
                $error.text((isWidth ? 'Width' : 'Height') + ' must be between ' + min + ' and ' + max + ' mm.').show();
                updateInputErrorState($input.attr('id'), true);
            }
        }
        
        updatePrice();
        validateCurrentStep();
        
        // Update summary if on last step
        if (currentStep === totalSteps - 1) {
            updateSummary();
        }
    });

    // Recalculate price and validate on blur
    $(document).on('blur', '#width, #height', function() {
        const $input = $(this);
        const value = $input.val();
        const min = parseInt($input.attr('min')) || 600;
        const max = parseInt($input.attr('max'));
        const isWidth = $input.attr('id') === 'width';
        const $error = isWidth ? $('#width-error') : $('#height-error');
        
        // Only validate if there's a value
        if (value) {
            const numValue = parseInt(value);
            if (isNaN(numValue)) {
                $error.text((isWidth ? 'Width' : 'Height') + ' must be a valid number.').show();
                updateInputErrorState($input.attr('id'), true);
            } else if (numValue < min || numValue > max) {
                $error.text((isWidth ? 'Width' : 'Height') + ' must be between ' + min + ' and ' + max + ' mm.').show();
                updateInputErrorState($input.attr('id'), true);
            } else {
                $error.hide();
                updateInputErrorState($input.attr('id'), false);
            }
        }
        
        updatePrice();
        validateCurrentStep();
        
        // Update summary if on last step
        if (currentStep === totalSteps - 1) {
            updateSummary();
        }
    });

    // Validate Step 2 when panel selection changes
    $(document).on('change', 'input[name="panel_layout"]', function() {
        validateCurrentStep();
        updatePrice();
        
        // Update summary if on last step
        if (currentStep === totalSteps - 1) {
            updateSummary();
            updateNavigation();
        }
    });

    // Validate Step 3 when opening direction changes
    $(document).on('change', 'input[name="open_direction"]', function() {
        validateCurrentStep();
        updatePrice();
        
        // Update summary if on last step
        if (currentStep === totalSteps - 1) {
            updateSummary();
            updateNavigation();
        }
    });

    // Validate Step 4 when outside colour selection changes
    $(document).on('change', 'input[name="door_colour"]', function() {
        validateCurrentStep();
        updatePrice();
        
        // Update summary if on last step
        if (currentStep === totalSteps - 1) {
            updateSummary();
            updateNavigation();
        }
    });

    // Validate Step 5 when inside colour selection changes
    $(document).on('change', 'input[name="inside_colour"]', function() {
        validateCurrentStep();
        updatePrice();
        
        // Update summary if on last step
        if (currentStep === totalSteps - 1) {
            updateSummary();
            updateNavigation();
        }
    });

    $(document).on('change', '#custom_colour_select', function() {
        // If we're on Step 4, validate the step
        if (currentStep === 3) { // Step 4 is index 3
            validateCurrentStep();
        }
    });

    $(document).on('change', '#custom_inside_colour_select', function() {
        // If we're on Step 5, validate the step
        if (currentStep === 4) { // Step 5 is index 4
            validateCurrentStep();
        }
    });

    // Validate Step 7 when glass selection changes
    $(document).on('change', 'input[name="glass_upgrade"]', function() {
        validateCurrentStep();
        updatePrice();
        
        // Update summary if on last step
        if (currentStep === totalSteps - 1) {
            updateSummary();
            updateNavigation();
        }
    });

    // Validate Step 8 when trickle vents selection changes
    $(document).on('change', 'input[name="trickle_vents"]', function() {
        validateCurrentStep();
        updatePrice();
        
        // Update summary if on last step
        if (currentStep === totalSteps - 1) {
            updateSummary();
            updateNavigation();
        }
    });

    // Validate additions when changed
    $(document).on('change', 'input[name="addition"]', function() {
        updatePrice();
        
        // Update summary if on last step
        if (currentStep === totalSteps - 1) {
            updateSummary();
            updateNavigation();
        }
    });

    /**
     * Handle threshold selection changes
     * Validate step, update price, and control Next button state
     */
    $(document).on('change', 'input[name="threshold"]', function() {
        validateCurrentStep();
        updatePrice();
        
        // Update summary if on last step
        if (currentStep === totalSteps - 1) {
            updateSummary();
            updateNavigation();
        }
        
        // Update navigation to enable/disable Next button on Threshold step
        if (currentStep === 9) { // Step 10 (Threshold) - index 9
            const thresholdSelected = $('input[name="threshold"]:checked').length > 0;
            if (thresholdSelected) {
                nextBtn.removeClass('inactive').prop('disabled', false);
                if (nextFooterBtn.length) {
                    nextFooterBtn.removeClass('inactive').prop('disabled', false);
                }
            } else {
                nextBtn.addClass('inactive').prop('disabled', true);
                if (nextFooterBtn.length) {
                    nextFooterBtn.addClass('inactive').prop('disabled', true);
                }
            }
        }
    });

    // Validate cill when changed
    $(document).on('change', 'input[name="cill"]', function() {
        validateCurrentStep();
        updatePrice();
        
        // Update summary if on last step
        if (currentStep === totalSteps - 1) {
            updateSummary();
            updateNavigation();
        }
    });

    /**
     * Real-time postcode validation
     * Handles typing, delete, paste and autofill
     */
    $(document).on('input keyup paste', '#postcode', function () {

        let postcode = $(this).val()
            .toUpperCase()
            .replace(/\s+/g, '')
            .trim();

        // Update input value
        $(this).val(postcode);

        if (isDev()) {
            console.log('Postcode changed:', postcode, '| Current Step:', currentStep);
        }

        /**
         * Re-run main step validation
         * This controls Next button safely
         */
        if (typeof validateCurrentStep === 'function') {
            validateCurrentStep();
        }

        /**
         * Keep price system working
         */
        if (typeof updatePrice === 'function') {
            updatePrice();
        }

        /**
         * Keep summary + checkout logic working
         */
        if (typeof totalSteps !== 'undefined' && currentStep === totalSteps - 1) {
            if (typeof updateSummary === 'function') {
                updateSummary();
            }

            if (typeof updateNavigation === 'function') {
                updateNavigation();
            }
        }
    });

    // Validate access issues when changed
    $(document).on('change', 'input[name="access_issues"]', function() {
        validateCurrentStep();
        
        // Update summary if on last step
        if (currentStep === totalSteps - 1) {
            updateSummary();
            updateNavigation();
        }
    });

    // Validate access description when changed
    $(document).on('input', '#access_description', function() {
        validateCurrentStep();
        
        // Update summary if on last step
        if (currentStep === totalSteps - 1) {
            updateSummary();
            updateNavigation();
        }
    });

    // Navigation button event listeners
    $(document).on('click', '.next-step', goNextStep);
    $(document).on('click', '.prev-step', goPrevStep);
    
    if(nextFooterBtn.length) {
        nextFooterBtn.on('click', goNextStep);
    }
    
    // Recalculate price when any price option changes (including threshold radios)
    $(document).on('change', '.price-option', function() {
        updatePrice();
        validateCurrentStep();
        
        // Update summary if on last step
        if (currentStep === totalSteps - 1) {
            updateSummary();
            updateNavigation();
        }
    });

    // Update event listener for all form changes
    $(document).on('change input',
        '#width, #height, ' +
        'input[name="panel_layout"], input[name="open_direction"], ' +
        'input[name="door_colour"], input[name="inside_colour"], ' +
        'input[name="handle_colour"], input[name="glass_upgrade"], ' +
        'input[name="trickle_vents"], input[name="cill"]',
        function() {
            validateCurrentStep();
            updatePrice();

            if (currentStep === totalSteps - 1) {
                updateSummary();
                updateNavigation();
            }
        }
    );

    // Initialize the wizard
    initWizard();

    // ================== PANEL OPTIONS BASED ON WIDTH & HEIGHT ==================
    /**
     * Updates panel visibility and display prices based on width and height
     * Note: This only updates the UI display, actual price is not added
     * Actual price comes from Step 1 base price calculation
     */
    function updatePanelOptions() {
        const width  = parseInt($('#width').val());
        const height = parseInt($('#height').val());
        const $allPanels = $('.panel-option-card');

        $allPanels.hide();
        if (isNaN(width) || isNaN(height)) {
            // ===== EDIT MODE: Ensure selected panel is visible =====
            if (window.editMode) {
                const selectedPanel = $('input[name="panel_layout"]:checked').val();
                if (selectedPanel) {
                    const $selectedCard = $(`input[name="panel_layout"][value="${selectedPanel}"]`).closest('.panel-option-card');
                    $selectedCard.show();
                    // Fix: Preserve VAT text when updating price
                    const $priceSpan = $selectedCard.find('.panel-details .option-price');
                    const hasVat = $priceSpan.find('.price-vat').length > 0;
                    $priceSpan.html('+ £' + displayPrice + (hasVat ? ' <span class="price-vat">(inc. VAT)</span>' : ''));
                }
            }
            return;
        }

        let activeClass = '';
        let panelCount = 0;
        let basePrice = 0;

        // ===== WIDTH LOGIC WITH NEW RANGES =====
        // Determine which panel class should be visible based on width
        
        // 2 PANE: 1600–2000 mm
        if (width >= 1600 && width <= 2000) {
            activeClass = 'panel-2';
            panelCount = 2;
            basePrice = 1390;
        }
        // 3 PANE: 1800–3190 mm (with sub-ranges)
        else if (width >= 1800 && width <= 3190) {
            activeClass = 'panel-3';
            panelCount = 3;
            
            if (width >= 1800 && width <= 2200) {
                basePrice = 1520; // 1800–2200 mm
            } else if (width >= 2201 && width <= 2700) {
                basePrice = 1650; // 2201–2700 mm
            } else if (width >= 2701 && width <= 3000) {
                basePrice = 1790; // 2701–3000 mm
            } else if (width >= 3001 && width <= 3190) {
                basePrice = 1820; // 3001–3190 mm
            }
        }
        // 4 PANE: 3200–4000 mm (with sub-ranges)
        else if (width >= 3200 && width <= 4000) {
            activeClass = 'panel-4';
            panelCount = 4;
            
            if (width >= 3200 && width <= 3600) {
                basePrice = 2100; // 3200–3600 mm
            } else if (width >= 3601 && width <= 4000) {
                basePrice = 2290; // 3601–4000 mm
            }
        }
        // 5 PANE: 3700–5000 mm (with sub-ranges)
        else if (width >= 3700 && width <= 5000) {
            activeClass = 'panel-5';
            panelCount = 5;
            
            if (width >= 3700 && width <= 4200) {
                basePrice = 2920; // 3700–4200 mm
            } else if (width >= 4201 && width <= 4500) {
                basePrice = 3010; // 4201–4500 mm
            } else if (width >= 4501 && width <= 5000) {
                basePrice = 3120; // 4501–5000 mm
            }
        }
        // 6 PANE: 5000–5800 mm (with sub-ranges)
        else if (width >= 5000 && width <= 5800) {
            activeClass = 'panel-6';
            panelCount = 6;
            
            if (width >= 5000 && width <= 5300) {
                basePrice = 3750; // 5000–5300 mm
            } else if (width >= 5301 && width <= 5800) {
                basePrice = 3990; // 5301–5800 mm
            }
        }

        // ===== HEIGHT EXTRA CALCULATION =====
        // Height rules:
        // 1950–2100 mm = Included
        // 2101–2300 mm = +£90 per pane
        // 2301–2450 mm = +£120 per pane
        
        let heightExtra = 0;
        
        if (!isNaN(height) && panelCount > 0) {
            // Check if height is within valid range (1950-2450)
            if (height >= 1950 && height <= 2100) {
                heightExtra = 0; // Included
                if (isDev()) console.log('Height in included range: 1950-2100mm, extra: £0');
            }
            else if (height >= 2101 && height <= 2300) {
                heightExtra = 90 * panelCount; // +£90 per pane
                if (isDev()) console.log('Height in 2101-2300mm range, extra: £' + (90 * panelCount));
            }
            else if (height >= 2301 && height <= 2450) {
                heightExtra = 120 * panelCount; // +£120 per pane
                if (isDev()) console.log('Height in 2301-2450mm range, extra: £' + (120 * panelCount));
            }
            else {
                // Height outside valid range (but still show panels with 0 extra)
                heightExtra = 0;
                if (isDev()) console.log('Height outside valid range, extra: £0');
            }
        }

        // Display price (for UI only)
        const displayPrice = basePrice + heightExtra;

        if (isDev()) {
            console.log('Panel update - Width:', width, 'Height:', height, 'Active:', activeClass, 
                    'Base Price:', basePrice, 'Height Extra:', heightExtra, 'Display Price:', displayPrice);
        }

        // ===== IMPORTANT: Show panels based on width =====
        if (activeClass) {
            const $activePanels = $('.' + activeClass);
            $activePanels.show();
            
            // Update display prices for visual feedback - FIXED: Preserve VAT text
            $activePanels.each(function() {
                // Get the price span and check if it has VAT text
                const $priceSpan = $(this).find('.panel-details .option-price');
                const $vatSpan = $priceSpan.find('.price-vat');
                const hasVat = $vatSpan.length > 0;
                const vatHtml = hasVat ? ' <span class="price-vat">(inc. VAT)</span>' : '';
                
                // Update the visible price in the UI while preserving VAT text
                $priceSpan.html('+ £' + displayPrice + vatHtml);
                
                // IMPORTANT: Set data-price to 0 to prevent double charging
                // Base price is already added in Step 1
                $(this).find('.price-option').attr('data-price', 0);
                
                // Store display price in separate attribute (optional)
                $(this).attr('data-display-price', displayPrice);
            });
        }

        // ===== EDIT MODE: Ensure selected panel is visible =====
        if (window.editMode) {
            const selectedPanel = $('input[name="panel_layout"]:checked').val();
            if (selectedPanel) {
                // Make sure the selected panel's card is visible
                const $selectedCard = $(`input[name="panel_layout"][value="${selectedPanel}"]`).closest('.panel-option-card');
                $selectedCard.show();
                
                // Also ensure its price is updated with VAT text preserved
                const $priceSpan = $selectedCard.find('.panel-details .option-price');
                const $vatSpan = $priceSpan.find('.price-vat');
                const hasVat = $vatSpan.length > 0;
                const vatHtml = hasVat ? ' <span class="price-vat">(inc. VAT)</span>' : '';
                $priceSpan.html('+ £' + displayPrice + vatHtml);
                
                if (isDev()) console.log('Edit mode: ensuring selected panel is visible:', selectedPanel);
            }
        }

        // In edit mode, only unselect if the selected panel is truly not available
        if (!window.editMode) {
            $('input[name="panel_layout"]:checked').not(':visible').prop('checked', false);
        } else {
            const selectedPanel = $('input[name="panel_layout"]:checked').val();
            if (selectedPanel) {
                const $selectedCard = $(`input[name="panel_layout"][value="${selectedPanel}"]`).closest('.panel-option-card');
                if ($selectedCard.is(':hidden')) {
                    $('input[name="panel_layout"]:checked').prop('checked', false);
                }
            }
        }

        // Update total price (but panel price won't be added due to data-price="0")
        updatePrice();
        
        // Trigger pane count update for other steps (like glass)
        if (typeof window.getPaneCount === 'function') {
            window.getPaneCount();
        }
        
        // Trigger Step 7 price update if needed
        if (typeof window.updatePerPanePrices === 'function') {
            window.updatePerPanePrices();
        }
    }

    /* ===== Trigger when size changes ===== */
    $(document).on('input blur', '#width, #height', function () {
        updatePanelOptions();
    });

    /**
     * Validate Postcode Step
     * Returns false if postcode field is empty
     */
    function validatePostcodeStep() {

        // Stop if step system not ready
        if (typeof currentStep === 'undefined') {
            return true;
        }

        // Run validation only on Postcode step (Step index 11)
        if (currentStep !== 11) {
            return true;
        }

        const postcode = $('#postcode').val().trim();

        // Fail validation if empty
        if (postcode.length === 0) {
            if (isDev()) {
                console.log('Postcode validation failed');
            }
            return false;
        }

        if (isDev()) {
            console.log('Postcode validation passed');
        }
        return true;
    }

    // Add these styles to the page
    function addDeliveryStyles() {
        const style = `
            <style>
                /* Delivery Summary Styles */
                .delivery-summary-details {
                    display: flex;
                    flex-direction: column;
                    gap: 5px;
                    padding: 8px 12px;
                    border-radius: 6px;
                    font-size: 14px;
                }
                
                .delivery-summary-details.free-delivery {
                    background: #e8f5e8;
                }
                
                .delivery-summary-details.paid-delivery {
                    background: #f8f8f8;
                }
                
                .delivery-zone-badge {
                    font-weight: 600;
                    color: #1a1a1a;
                }
                
                .delivery-distance-info {
                    color: #666;
                    font-size: 13px;
                }
                
                .delivery-cost-info {
                    font-weight: 700;
                    color: #1a1a1a;
                    font-size: 16px;
                }
                
                .free-delivery .delivery-cost-info {
                    color: #2e7d32;
                }
                
                /* Bespoke Button */
                .bespoke-btn {
                    background: #ff9800 !important;
                    color: white !important;
                    cursor: not-allowed !important;
                    opacity: 0.8;
                }
                
                .bespoke-btn:hover {
                    background: #f57c00 !important;
                }
                
                /* Summary Row with Bespoke Delivery */
                #summary-delivery-row.bespoke-delivery .summary-value {
                    color: #d32f2f;
                    font-weight: 600;
                }
                
                /* Loading Spinner */
                .loading-spinner {
                    display: inline-block;
                    width: 16px;
                    height: 16px;
                    border: 2px solid rgba(255,255,255,0.3);
                    border-radius: 50%;
                    border-top-color: #fff;
                    animation: spin 0.8s linear infinite;
                    margin-right: 8px;
                }
                
                @keyframes spin {
                    to { transform: rotate(360deg); }
                }
                
                /* Step Indicator for Delivery */
                .delivery-status {
                    font-size: 12px;
                    padding: 4px 8px;
                    border-radius: 4px;
                    margin-left: 10px;
                }
                
                .delivery-status.free {
                    background: #e8f5e8;
                    color: #2e7d32;
                }
                
                .delivery-status.paid {
                    background: #fff3e0;
                    color: #f57c00;
                }
                
                .delivery-status.bespoke {
                    background: #ffebee;
                    color: #d32f2f;
                }
            </style>
        `;
        
        $('head').append(style);
    }

    // Call this function on init
    addDeliveryStyles();

    /* ===== Run on load ===== */
    updatePanelOptions();


    






// ========================================
// SLIDING DRAWER FUNCTIONS
// ========================================

/**
 * Step definitions - Delivery step removed
 * Now 12 steps total (1-12)
 */
const stepDefinitions = [
    {
        number: 1,
        name: 'Size',
        getValue: function() {
            const width = $('#width').val();
            const height = $('#height').val();
            return (width && height) ? width + ' x ' + height + 'mm' : '—';
        },
        getPrice: function() {
            return parseFloat($('#base_price_value').val()) || 0;
        }
    },
    {
        number: 2,
        name: 'Panels',
        getValue: function() {
            const panelValue = $('input[name="panel_layout"]:checked').val();
            if (!panelValue) return '—';
            
            let panelText = $('input[name="panel_layout"]:checked')
                .closest('.panel-option-card, label')
                .find('.option-name').text().trim();
            
            if (!panelText) {
                const panelMap = {
                    '2_left': '2 Panels Left', '2_right': '2 Panels Right',
                    '1_2': '1 + 2 Panels', '2_1': '2 + 1 Panels',
                    '3_left': '3 Panels Left', '3_right': '3 Panels Right',
                    '1_3': '1 + 3 Panels', '3_1': '3 + 1 Panels',
                    '2_2': '2 + 2 Panels',
                    '4_left': '4 Panels Left', '4_right': '4 Panels Right',
                    '1_4': '1 + 4 Panels', '4_1': '4 + 1 Panels',
                    '2_3': '2 + 3 Panels', '3_2': '3 + 2 Panels',
                    '5_left': '5 Panels Left', '5_right': '5 Panels Right',
                    '1_5': '1 + 5 Panels', '2_4': '2 + 4 Panels',
                    '3_3': '3 + 3 Panels', '4_2': '4 + 2 Panels', '5_1': '5 + 1 Panels',
                    '6_left': '6 Panels Left', '6_right': '6 Panels Right',
                    'french': 'French Doors'
                };
                panelText = panelMap[panelValue] || panelValue;
            }
            return panelText;
        },
        getPrice: function() { return 0; }
    },
    {
        number: 3,
        name: 'Opening',
        getValue: function() {
            const val = $('input[name="open_direction"]:checked').val();
            return val ? (val === 'inwards' ? 'Inwards' : 'Outwards') : '—';
        },
        getPrice: function() { return 0; }
    },
    {
    number: 4,
        name: 'Outside Colour',
        getValue: function() {
            const val = $('input[name="door_colour"]:checked').val();
            if (!val) return '—';
            
            // Check if it's a selected RAL code
            if (val && val !== 'custom_ral' && val !== 'anthracite_grey' && val !== 'black' && val !== 'white') {
                return val; // This is a RAL code
            }
            
            if (val === 'custom_ral') {
                const selectedRal = $('#custom_colour_select').val();
                return selectedRal || 'Custom RAL';
            }
            
            const colourMap = {
                'anthracite_grey': 'Anthracite Grey',
                'black': 'Black',
                'white': 'White'
            };
            return colourMap[val] || val;
        },
        getPrice: function() {
            const val = $('input[name="door_colour"]:checked').val();
            const insideColour = $('input[name="inside_colour"]:checked').val();
            const paneCount = window.getPaneCount ? window.getPaneCount() : 1;
            
            // Check for free dual colour
            const isFreeDual = (val === 'anthracite_grey' && insideColour === 'white');
            
            // If free dual, outside colour price is 0
            if (isFreeDual) return 0;
            
            // If a specific RAL is selected
            if (val && val !== 'custom_ral' && val !== 'anthracite_grey' && val !== 'black' && val !== 'white') {
                const selectedOption = $('#custom_colour_select option[value="' + val + '"]');
                const price = parseFloat(selectedOption.data('price')) || 195;
                return price * paneCount;
            }
            
            // If custom_ral is selected but no specific RAL chosen
            if (val === 'custom_ral') {
                return 195 * paneCount;
            }
            
            return 0; // Standard colours
        }
    },
    {
        number: 5,
        name: 'Inside Colour',
        getValue: function() {
            const val = $('input[name="inside_colour"]:checked').val();
            if (!val) return '—';
            
            // Check if it's a selected RAL code
            if (val && val !== 'custom_ral' && val !== 'anthracite_grey' && val !== 'black' && val !== 'white') {
                return val; // This is a RAL code
            }
            
            if (val === 'custom_ral') {
                const selectedRal = $('#custom_inside_colour_select').val();
                return selectedRal || 'Custom RAL';
            }
            
            const colourMap = {
                'anthracite_grey': 'Anthracite Grey',
                'black': 'Black',
                'white': 'White'
            };
            return colourMap[val] || val;
        },
        getPrice: function() {
            const val = $('input[name="inside_colour"]:checked').val();
            const outsideColour = $('input[name="door_colour"]:checked').val();
            const paneCount = window.getPaneCount ? window.getPaneCount() : 1;
            
            // Check for free dual colour
            const isFreeDual = (outsideColour === 'anthracite_grey' && val === 'white');
            
            // If free dual, inside colour price is 0
            if (isFreeDual) return 0;
            
            // Check if this is a standard dual colour (different standard colours) - CHARGEABLE
            const standardColours = ['anthracite_grey', 'black', 'white'];
            const isOutsideStandard = standardColours.includes(outsideColour);
            const isInsideStandard = standardColours.includes(val);
            
            if (isOutsideStandard && isInsideStandard && outsideColour !== val && !isFreeDual) {
                // Standard dual colours are chargeable
                return 195 * paneCount;
            }
            
            // If a specific RAL is selected
            if (val && val !== 'custom_ral' && val !== 'anthracite_grey' && val !== 'black' && val !== 'white') {
                const selectedOption = $('#custom_inside_colour_select option[value="' + val + '"]');
                const price = parseFloat(selectedOption.data('price')) || 195;
                return price * paneCount;
            }
            
            // If custom_ral is selected but no specific RAL chosen
            if (val === 'custom_ral') {
                return 195 * paneCount;
            }
            
            return 0; // Standard colours
        }
    },
    {
        number: 6,
        name: 'Handle',
        getValue: function() {
            const val = $('input[name="handle_colour"]:checked').val();
            if (!val) return '—';
            
            const handleMap = {
                'white': 'White',
                'chrome': 'Chrome',
                'black': 'Black',
                'black_white': 'Black & White'
            };
            return handleMap[val] || val;
        },
        getPrice: function() { return 0; }
    },
    {
    number: 7,
        name: 'Glass',
        getValue: function() {
            const val = $('input[name="glass_upgrade"]:checked').val();
            if (!val) return '—';
            
            // Return display text instead of value
            if (val === 'no_thanks') {
                return 'No Thanks - Standard Glass';
            } else if (val === 'self_cleaning') {
                return 'Self-cleaning glass';
            } else if (val === 'integral_blinds') {
                return 'Integral blinds';
            } else if (val === 'obscure_glass') {
                return 'Obscure glass';
            } else if (val === 'saint_gobain_12') {
                return 'Saint-Gobain Planitherm 1.2';
            }
            
            // Fallback to getting text from DOM
            let text = $('input[name="glass_upgrade"]:checked')
                .closest('.glass-option-card')
                .find('.option-name').text().trim();
            
            if (!text) {
                const glassMap = {
                    'self_cleaning': 'Self-cleaning',
                    'integral_blinds': 'Integral Blinds',
                    'obscure_glass': 'Obscure',
                    'saint_gobain_12': 'Saint-Gobain 1.2'
                };
                text = glassMap[val] || val;
            }
            
            return text;
        },
        getPrice: function() {
            const val = $('input[name="glass_upgrade"]:checked');
            if (!val.length) return 0;
            
            // No Thanks has price 0
            if (val.val() === 'no_thanks') return 0;
            
            const basePrice = parseFloat(val.data('price')) || 0;
            const paneCount = getPaneCount();
            return basePrice * paneCount;
        }
    },
    {
        number: 8,
        name: 'Trickle Vents',
        getValue: function() {
            const val = $('input[name="trickle_vents"]:checked').val();
            return val === 'yes_trickle' ? 'Yes' : (val === 'no_trickle' ? 'No' : '—');
        },
        getPrice: function() {
            const val = $('input[name="trickle_vents"]:checked').val();
            return val === 'yes_trickle' ? 85 : 0;
        }
    },
    {
        number: 9,
        name: 'Cill',
        getValue: function() {
            const val = $('input[name="cill"]:checked').val();
            if (!val) return '—';
            
            const cillMap = {
                'none': 'No Cill',
                '150mm-aluminium-cill': 'Aluminium Cill',
                '150mm-upvc-cill': 'uPVC Cill'
            };
            return cillMap[val] || val;
        },
        getPrice: function() { return 0; }
    },
    {
        number: 10,
        name: 'Postcode',
        getValue: function() {
            const postcode = $('#postcode').val().trim().replace(/\s+/g, '');
            return postcode || '—';
        },
        getPrice: function() {
            return 0; // Postcode has no price
        }
    },
    {
        number: 11,
        name: 'Access',
        getValue: function() {
            const val = $('input[name="access_issues"]:checked').val();
            if (!val) return '—';
            
            if (val === 'yes_access') {
                const desc = $('#access_description').val();
                return desc ? 'Yes: ' + desc : 'Yes';
            }
            return 'No';
        },
        getPrice: function() { return 0; }
    },
    {
        number: 12,
        name: 'Customer Information',
        getValue: function() {
            const firstName = $('#first_name').val().trim();
            const lastName = $('#last_name').val().trim();
            
            if (firstName || lastName) {
                return (firstName + ' ' + lastName).trim();
            }
            return '—';
        },
        getPrice: function() { return 0; }
    }
];

/**
 * Get pane count from selected panel
 */
function getPaneCount() {
    const selectedPanel = $('input[name="panel_layout"]:checked').val();
    if (!selectedPanel) return 1;
    
    let paneCount = 1;
    
    if (selectedPanel === 'french') {
        paneCount = 2;
    } else if (selectedPanel.includes('_')) {
        const parts = selectedPanel.split('_');
        if (parts.length === 2 && !isNaN(parseInt(parts[0])) && !isNaN(parseInt(parts[1]))) {
            paneCount = parseInt(parts[0]) + parseInt(parts[1]);
        } else {
            const match = selectedPanel.match(/^(\d+)/);
            if (match) paneCount = parseInt(match[1]);
        }
    } else {
        const match = selectedPanel.match(/^(\d+)/);
        if (match) paneCount = parseInt(match[1]);
    }
    
    return Math.max(1, paneCount);
}

/**
 * Build drawer steps HTML
 */
function buildDrawerSteps() {
    let html = '';
    
    stepDefinitions.forEach(step => {
        const value = step.getValue();
        const price = step.getPrice();
        const priceDisplay = price > 0 ? '£' + price.toFixed(2) : '£0';
        const completedClass = (value !== '—') ? 'completed' : '';
        
        html += `
            <div class="drawer-step-item ${completedClass}" data-step="${step.number}">
                <div class="step-label">
                    <span class="step-number">${step.number}</span>
                    <span class="step-name">${step.name}</span>
                </div>
                <div class="step-value" title="${value}">${value}</div>
                <div class="step-price">${priceDisplay}</div>
            </div>
        `;
    });
    
    $('#drawerStepsList').html(html);
}

/**
 * Update drawer with latest prices
 */
function updateDrawer() {
    let totalPrice = 0;
    
    stepDefinitions.forEach(step => {
        const value = step.getValue();
        const price = step.getPrice();
        
        // Determine if this step should show VAT
        let priceDisplay = '';
        if (price > 0) {
            // All priced items include VAT
            priceDisplay = '£' + price.toFixed(2) + ' <span class="price-vat">(inc. VAT)</span>';
        } else {
            priceDisplay = '£0';
        }
        
        // Update step item
        const $stepItem = $(`.drawer-step-item[data-step="${step.number}"]`);
        if ($stepItem.length) {
            $stepItem.find('.step-value').text(value).attr('title', value);
            $stepItem.find('.step-price').html(priceDisplay);
            
            // Update completed class
            if (value !== '—') {
                $stepItem.addClass('completed');
            } else {
                $stepItem.removeClass('completed');
            }
        }
        
        totalPrice += price;
    });
    
    // Update total display with VAT
    const totalDisplay = '£' + totalPrice.toFixed(2) + ' <span class="price-vat">(inc. VAT)</span>';
    $('#drawer-total-price').html(totalDisplay);
    $('#drawer-footer-total').html(totalDisplay);
    $('#final_price_input').val(totalPrice.toFixed(2));
    
    // Trigger any other updates
    $(document).trigger('priceUpdated');
    
    if (window.isDev && window.isDev()) {
        console.log('Drawer updated - Total:', totalPrice.toFixed(2));
    }
}

/**
 * Update drawer buttons based on delivery
 */
function updateDrawerButtons() {
    const isBespoke = (window.deliveryData && window.deliveryData.bespoke) || $('#delivery_bespoke').val() === '1';
    
    if (isBespoke) {
        $('#drawerAddToCart, #drawerCheckout').addClass('disabled').prop('disabled', true);
        $('#drawerAddToCart').text('CONTACT SALES');
    } else {
        $('#drawerAddToCart, #drawerCheckout').removeClass('disabled').prop('disabled', false);
        $('#drawerAddToCart').text('ADD TO CART');
    }
}

/**
 * Toggle drawer open/close
 */
function toggleDrawer(open) {
    const $drawerContent = $('#drawerContent');
    
    if (open) {
        $drawerContent.addClass('open');
        $('.toggle-arrow').text('▶');
    } else {
        $drawerContent.removeClass('open');
        $('.toggle-arrow').text('◀');
    }
}

/**
 * Initialize drawer
 */
function initDrawer() {
    // Build initial steps
    buildDrawerSteps();
    
    // Initial update
    updateDrawer();
    
    // Toggle button click
    $('#drawerToggle').on('click', function() {
        toggleDrawer(true);
    });
    
    // Close button click
    $('#drawerClose').on('click', function() {
        toggleDrawer(false);
    });
    
    // Listen to all form changes
    $(document).on('change input', 
        '#width, #height, ' +
        'input[name="panel_layout"], input[name="open_direction"], ' +
        'input[name="door_colour"], input[name="inside_colour"], ' +
        'input[name="handle_colour"], input[name="glass_upgrade"], ' +
        'input[name="trickle_vents"], input[name="cill"], ' +
        '#postcode, input[name="access_issues"], #access_description, ' +
        '#custom_colour_select, #custom_inside_colour_select',
        function() {
            updateDrawer();
        }
    );
    
    // Listen to delivery data changes
    $(document).on('deliveryDataUpdated', function() {
        updateDrawer();
    });
    
    // Listen to step changes
    $(document).on('stepChanged', function(e, stepIndex) {
        $('.drawer-step-item').removeClass('active-step');
        $(`.drawer-step-item[data-step="${stepIndex + 1}"]`).addClass('active-step');
    });
    
    // Show edit mode if active
    if (window.editMode) {
        $('#drawerEditMode').show().text('Editing cart item: ' + (window.editCartKey || ''));
        
        // Force drawer update after edit mode data is loaded
        setTimeout(function() {
            updateDrawer();
        }, 800);
    }
}

// Initialize on document ready
$(document).ready(function() {
    if ($('.drawer-container').length) {
        initDrawer();
        console.log('Sliding Drawer Initialized');
    }
});

});