<?php
/**
 * Template part for Horizontal Astragal Bars Count Step in Door Builder
 * Step 10: Number of Horizontal Astragal Bars Selection
 * 
 * @package Astra Child
 */

// Get images directory
$images_dir = get_stylesheet_directory_uri() . '/assets/images/';
?>

<!-- Step 10: Horizontal Astragal Bars Count -->
<div class="wizard-step" data-step="10">
    <div class="step-container horizontal-bars-container">

        <div class="step-title horizontal-bars-title">
            <h2>Choose the number of horizontal Astragal bars you'd like to add.</h2>
        </div>
        
        <div class="horizontal-bars-wrapper">
            <div class="horizontal-bars-options">
                
                <!-- 2 Bars Option -->
                <div class="horizontal-bar-card" data-price="112">
                    <input type="radio" name="horizontal_bars_count" id="bars_2" value="2_bars" class="price-option" data-price="112">
                    <label for="bars_2">
                        <div class="horizontal-bar-image">
                            <img src="<?php echo esc_url($images_dir . '2_Bars_Astragal.png'); ?>" 
                                 alt="2 Horizontal Astragal Bars per Panel" 
                                 loading="lazy"
                                 onerror="this.src='<?php echo esc_url($images_dir . '2_Horizontal_Astragal_Bars.png'); ?>'">
                        </div>
                        <div class="horizontal-bar-details">
                            <div class="horizontal-bar-text-content">
                                <div class="horizontal-bar-name-line">
                                    <span class="horizontal-bar-radio-indicator"></span>
                                    <span class="option-name">2 Bars per Panel</span>
                                    <span class="horizontal-bar-price">+£112 per panel</span>
                                </div>
                            </div>
                        </div>
                    </label>
                </div>
                
                <!-- 3 Bars Option -->
                <div class="horizontal-bar-card" data-price="168">
                    <input type="radio" name="horizontal_bars_count" id="bars_3" value="3_bars" class="price-option" data-price="168">
                    <label for="bars_3">
                        <div class="horizontal-bar-image">
                            <img src="<?php echo esc_url($images_dir . '3_Horizontal_Astragal_Bars.png'); ?>" 
                                 alt="3 Horizontal Astragal Bars per Panel" 
                                 loading="lazy"
                                 onerror="this.src='<?php echo esc_url($images_dir . 'placeholder.webp'); ?>'">
                        </div>
                        <div class="horizontal-bar-details">
                            <div class="horizontal-bar-text-content">
                                <div class="horizontal-bar-name-line">
                                    <span class="horizontal-bar-radio-indicator"></span>
                                    <span class="option-name">3 Bars per Panel</span>
                                    <span class="horizontal-bar-price">+£168 per panel</span>
                                </div>
                            </div>
                        </div>
                    </label>
                </div>
                
                <!-- 4 Bars Option -->
                <div class="horizontal-bar-card" data-price="224">
                    <input type="radio" name="horizontal_bars_count" id="bars_4" value="4_bars" class="price-option" data-price="224">
                    <label for="bars_4">
                        <div class="horizontal-bar-image">
                            <img src="<?php echo esc_url($images_dir . '4_Horizontal_Astragal_Bars.png'); ?>" 
                                 alt="4 Horizontal Astragal Bars per Panel" 
                                 loading="lazy"
                                 onerror="this.src='<?php echo esc_url($images_dir . 'placeholder.webp'); ?>'">
                        </div>
                        <div class="horizontal-bar-details">
                            <div class="horizontal-bar-text-content">
                                <div class="horizontal-bar-name-line">
                                    <span class="horizontal-bar-radio-indicator"></span>
                                    <span class="option-name">4 Bars per Panel</span>
                                    <span class="horizontal-bar-price">+£224 per panel</span>
                                </div>
                            </div>
                        </div>
                    </label>
                </div>
                
                <!-- 5 Bars Option -->
                <div class="horizontal-bar-card" data-price="280">
                    <input type="radio" name="horizontal_bars_count" id="bars_5" value="5_bars" class="price-option" data-price="280">
                    <label for="bars_5">
                        <div class="horizontal-bar-image">
                            <img src="<?php echo esc_url($images_dir . '5_Bars_Astragal.png'); ?>" 
                                 alt="5 Horizontal Astragal Bars per Panel" 
                                 loading="lazy"
                                 onerror="this.src='<?php echo esc_url($images_dir . '5_Horizontal_Astragal_Bars.png'); ?>'">
                        </div>
                        <div class="horizontal-bar-details">
                            <div class="horizontal-bar-text-content">
                                <div class="horizontal-bar-name-line">
                                    <span class="horizontal-bar-radio-indicator"></span>
                                    <span class="option-name">5 Bars per Panel</span>
                                    <span class="horizontal-bar-price">+£280 per panel</span>
                                </div>
                            </div>
                        </div>
                    </label>
                </div>
                
            </div>
        </div>

    </div>
</div>

<style>
/* ================================
   Horizontal Astragal Bars Count Styles
   Step 10 - Unique Design with Price Display
   ================================ */

.horizontal-bars-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 20px;
}

/* Title styling */
.horizontal-bars-title {
    text-align: left;
    margin-bottom: 30px;
}

.horizontal-bars-title h2 {
    font-size: 28px;
    color: #222;
    font-weight: 600;
    margin: 0;
    line-height: 1.3;
}

/* Options grid - 4 cards in a row */
.horizontal-bars-options {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
    margin-top: 30px;
    max-width: 1400px;
    margin-left: auto;
    margin-right: auto;
}

/* Individual card styling */
.horizontal-bar-card {
    border: 1px solid #e0e0e0;
    overflow: hidden;
    transition: all 0.25s ease;
    cursor: pointer;
    height: 100%;
    background: #fff;
}

.horizontal-bar-card:hover {
    border-color: #9c7b4b;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

/* Hide radio input */
.horizontal-bar-card input[type="radio"] {
    position: absolute;
    opacity: 0;
    width: 0;
    height: 0;
}

.horizontal-bar-card label {
    display: flex;
    flex-direction: column;
    height: 100%;
    cursor: pointer;
    background: transparent;
}

.horizontal-bar-card input:checked + label {
    border: 2px solid #9c7b4b;
    margin: -1px;
}

/* Image container */
.horizontal-bar-image {
    height: 280px !important;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f5f5f5;
    padding: 20px;
}

.horizontal-bar-image img {
    max-width: 100%;
    max-height: 100%;
    width: auto;
    height: auto;
    object-fit: contain;
}

/* Details container */
.horizontal-bar-details {
    padding: 15px;
    border-top: 1px solid #f0f0f0;
    background: #fafafa;
    min-height: 50px;
}

/* Text content container */
.horizontal-bar-text-content {
    display: flex;
    flex-direction: column;
    width: 100%;
}

/* Name line with radio indicator, text and price */
.horizontal-bar-name-line {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    gap: 8px;
}

/* Radio indicator */
.horizontal-bar-radio-indicator {
    display: inline-block;
    width: 14px;
    height: 14px;
    border: 1.5px solid #222;
    border-radius: 50%;
    transition: all 0.2s ease;
    box-sizing: border-box;
    flex-shrink: 0;
}

/* Selected state for radio indicator */
.horizontal-bar-card input:checked + label .horizontal-bar-radio-indicator {
    background: #222;
    box-shadow: inset 0 0 0 3px #fafafa;
    border-color: #222;
}

/* Hover effect for radio indicator */
.horizontal-bar-card:hover .horizontal-bar-radio-indicator {
    border-color: #9c7b4b;
}

/* Selected card hover state */
.horizontal-bar-card input:checked + label:hover .horizontal-bar-radio-indicator {
    border-color: #222;
    background: #222;
    box-shadow: inset 0 0 0 3px #fafafa;
}

/* Option name styling */
.option-name {
    font-weight: 500;
    color: #333;
    display: inline-block;
    text-align: left;
    line-height: 1.3;
    font-size: 13px !important;
    flex: 1;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

/* Price styling - Right aligned in same line */
.horizontal-bar-price {
    font-size: 14px;
    font-weight: 600;
    color: #9c7b4b;
    text-align: right;
    white-space: nowrap;
    flex-shrink: 0;
    margin-left: auto;
}

/* Step title styling */
.step-title h2 {
    font-size: 28px;
    margin-bottom: 10px;
    color: #222;
}

/* ================================
   Responsive Design
   ================================ */

@media (max-width: 1200px) {
    .horizontal-bars-options {
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
        padding: 0 20px;
    }
}

@media (max-width: 768px) {
    .horizontal-bars-title h2 {
        font-size: 22px;
        padding: 0 15px;
    }
    
    .horizontal-bars-options {
        grid-template-columns: 1fr;
        gap: 15px;
        padding: 0 15px;
    }
    
    .horizontal-bar-image {
        height: 180px !important;
        padding: 15px;
    }
    
    .horizontal-bar-details {
        padding: 12px;
        min-height: 45px;
    }
    
    .horizontal-bar-radio-indicator {
        width: 12px;
        height: 12px;
        border-width: 1.2px;
    }
    
    .horizontal-bar-card input:checked + label .horizontal-bar-radio-indicator {
        box-shadow: inset 0 0 0 2px #fafafa;
    }
    
    .horizontal-bar-name-line {
        gap: 5px;
    }
    
    .option-name {
        font-size: 12px !important;
    }
    
    .horizontal-bar-price {
        font-size: 12px;
    }
}

@media (min-width: 769px) and (max-width: 1024px) {
    .horizontal-bars-options {
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
        padding: 0 20px;
    }
    
    .horizontal-bar-image {
        height: 200px !important;
    }
    
    .horizontal-bar-radio-indicator {
        width: 13px;
        height: 13px;
    }
    
    .option-name {
        font-size: 12px !important;
    }
    
    .horizontal-bar-price {
        font-size: 12px;
    }
}

@media (min-width: 1025px) and (max-width: 1399px) {
    .horizontal-bars-options {
        grid-template-columns: repeat(4, 1fr);
        gap: 15px;
        padding: 0 15px;
    }
    
    .horizontal-bar-image {
        height: 220px !important;
    }
    
    .horizontal-bar-radio-indicator {
        width: 14px;
        height: 14px;
    }
    
    .option-name {
        font-size: 12px !important;
    }
    
    .horizontal-bar-price {
        font-size: 13px;
    }
}

@media (min-width: 1400px) {
    .horizontal-bars-options {
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
        max-width: 1400px;
    }
    
    .horizontal-bar-image {
        height: 250px !important;
    }
    
    .horizontal-bar-radio-indicator {
        width: 15px;
        height: 15px;
        border-width: 2px;
    }
    
    .horizontal-bar-card input:checked + label .horizontal-bar-radio-indicator {
        box-shadow: inset 0 0 0 3.5px #fafafa;
    }
    
    .option-name {
        font-size: 13px !important;
    }
    
    .horizontal-bar-price {
        font-size: 14px;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Add selected state styling when radio is checked
    $('.horizontal-bar-card input[type="radio"]').on('change', function() {
        // Remove selected styling from all cards
        $('.horizontal-bar-card').removeClass('selected').css({
            'border-color': '#e0e0e0',
            'background': '#fff'
        });
        
        // Add selected styling to the checked card
        $(this).closest('.horizontal-bar-card').addClass('selected').css({
            'border-color': '#9c7b4b',
            'background': '#fff'
        });
        
        // Trigger price update
        if (typeof updatePrice === 'function') {
            updatePrice();
        }
    });
    
    // Set initial selected state (if any)
    $('.horizontal-bar-card input[type="radio"]:checked').each(function() {
        $(this).closest('.horizontal-bar-card').addClass('selected').css({
            'border-color': '#9c7b4b',
            'background': '#fff'
        });
    });
    
    // Handle card click for better UX
    $('.horizontal-bar-card').on('click', function(e) {
        // Don't trigger if clicking on radio directly
        if ($(e.target).is('input[type="radio"]')) {
            return;
        }
        
        // Find the radio inside this card and check it
        const $radio = $(this).find('input[type="radio"]');
        $radio.prop('checked', true).trigger('change');
    });
});
</script>