<?php
/**
 * Enqueue parent and child theme styles
 */
add_action( 'wp_enqueue_scripts', 'astra_child_style' );
function astra_child_style() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array('parent-style') );
}

/**
 * Include delivery calculator class
 */
require_once get_stylesheet_directory() . '/delivery-calculator.php';

/**
 * Enqueue Door Builder assets only on builder page
 */
add_action( 'wp_enqueue_scripts', function() {
    if ( is_page( 'bifold-door-builder' ) ) {
        // Disable theme styles on builder page
        wp_dequeue_style( 'parent-style' );
        wp_dequeue_style( 'child-style' );
        wp_dequeue_style( 'astra-theme-css' );
        
        // === IMPORTANT: Dequeue Elementor scripts to avoid conflicts ===
        wp_dequeue_script( 'elementor-frontend' );
        wp_dequeue_script( 'elementor-pro-frontend' );
        wp_dequeue_script( 'elementor' );
        
        // Load builder CSS and JS
        wp_enqueue_style( 'door-builder-css', get_stylesheet_directory_uri() . '/assets/css/wizard.css' );
        wp_enqueue_script( 'door-builder-js', get_stylesheet_directory_uri() . '/assets/js/wizard.js', ['jquery'], null, true );
        
        // Add inline CSS to hide theme elements
        add_action( 'wp_head', 'hide_theme_elements' );
        
        // Add logo CSS
        add_action( 'wp_head', 'add_builder_logo' );
        
        // Localize script for AJAX
        wp_localize_script( 'door-builder-js', 'door_builder_vars', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'cart_url' => wc_get_cart_url(),
            'checkout_url' => wc_get_checkout_url(),
            'nonce' => wp_create_nonce( 'door_builder_ajax' ),
        ] );
    }
});

/**
 * Hide theme header and footer on builder page
 */
function hide_theme_elements() {
    if ( is_page( 'bifold-door-builder' ) ) {
        ?>
        <style>
            /* Hide all theme elements */
            header, 
            footer, 
            .site-header, 
            .site-footer, 
            #masthead, 
            #colophon,
            .ast-header,
            .ast-footer,
            nav,
            .main-header,
            .main-footer {
                display: none !important;
            }
            
            /* Hide WordPress admin bar on builder */
            #wpadminbar {
                display: none !important;
            }
        </style>
        <?php
    }
}

/**
 * Add logo to builder header
 */
function add_builder_logo() {
    if ( is_page( 'bifold-door-builder' ) ) {
        ?>
        <style>
            /* .builder-logo {
                position: absolute;
                top: 30px;
                left: 40px;
                height: 40px;
                z-index: 10;
            } */
            
            /* .builder-logo img {
                height: 100%;
                width: auto;
            } */
            
            @media (max-width: 768px) {
                /* .builder-logo {
                    top: 20px;
                    left: 20px;
                    height: 30px;
                } */
            }
        </style>
        <?php
    }
}

/**
 * Remove default WooCommerce Add to Cart button
 */
add_action( 'init', function() {
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
});

/**
 * Add "Design your door" button on variable product pages - NO VARIATION ID
 */
add_action( 'woocommerce_single_product_summary', function() {
    global $product;

    if ( $product && $product->is_type( 'variable' ) ) {
        ?>
        <style>
            .design-your-door-btn {
                display: inline-block !important;
                background: #cbbfa9 !important;
                color: white !important;
                padding: 15px 30px !important;
                font-size: 14px !important;
                font-weight: 600 !important;
                text-transform: uppercase !important;
                letter-spacing: 2px !important;
                border: none !important;
                border-radius: 4px !important;
                cursor: pointer !important;
                text-decoration: none !important;
                margin-top: 20px !important;
                transition: background 0.3s !important;
                box-shadow: 0 4px 6px rgba(0,0,0,0.1) !important;
            }
            
            .design-your-door-btn:hover {
                background: #b9ad95 !important;
                transform: translateY(-2px) !important;
                box-shadow: 0 6px 12px rgba(0,0,0,0.15) !important;
            }
            
            /* Hide default add to cart button and variation dropdown */
            .single_variation_wrap .woocommerce-variation-add-to-cart,
            table.variations,
            .variations_form .variations,
            .single-product form.variations_form {
                display: none !important;
            }
        </style>
        
        <a class="button design-your-door-btn" href="#" id="design-your-door-btn">
            Design your door
        </a>

        <script>
        jQuery(function($){
            $('#design-your-door-btn').on('click', function(e){
                e.preventDefault();

                let url = '<?php echo site_url('/bifold-door-builder/'); ?>?product_id=<?php echo $product->get_id(); ?>';
                window.location.href = url;
            });
        });
        </script>
        <?php
    }
}, 35 );

/**
 * Handle builder form submit - UPDATED with colour pricing logic
 */
add_action( 'template_redirect', function() {
    // Check if it's a builder submission - variation_id is now optional
    if ( isset( $_POST['product_id'] ) ) {
        
        // Verify nonce for security
        if ( ! isset( $_POST['builder_nonce'] ) || ! wp_verify_nonce( $_POST['builder_nonce'], 'door_builder_action' ) ) {
            wc_add_notice( 'Security check failed. Please try again.', 'error' );
            wp_safe_redirect( wc_get_cart_url() );
            exit;
        }
        
        $product_id   = absint( $_POST['product_id'] );
        $variation_id = isset( $_POST['variation_id'] ) ? absint( $_POST['variation_id'] ) : 0;
        $final_price  = isset($_POST['final_price']) ? floatval( $_POST['final_price'] ) : 0;
        
        // Check which action is being performed
        $is_checkout = isset( $_POST['builder_checkout'] ) && $_POST['builder_checkout'] == '1';

        // Collect all form data from POST
        $wizard_data = array();
        
        // Get all data from POST (including Step 13 hidden fields)
        $wizard_data['width'] = isset($_POST['width']) ? intval($_POST['width']) : 
                               (isset($_POST['summary_size']) ? intval(explode(' x ', $_POST['summary_size'])[0]) : 0);
        
        $wizard_data['height'] = isset($_POST['height']) ? intval($_POST['height']) : 
                                (isset($_POST['summary_size']) && strpos($_POST['summary_size'], ' x ') ? 
                                 intval(explode(' x ', $_POST['summary_size'])[1]) : 0);
        
        $wizard_data['panels'] = isset($_POST['panel_layout']) ? sanitize_text_field($_POST['panel_layout']) : 
                                (isset($_POST['summary_panels']) ? sanitize_text_field($_POST['summary_panels']) : '');
        
        $wizard_data['opening'] = isset($_POST['open_direction']) ? 
                                  ($_POST['open_direction'] === 'inwards' ? 'Inwards' : 'Outwards') : 
                                  (isset($_POST['summary_opening']) ? sanitize_text_field($_POST['summary_opening']) : '');
        
        // ===== OUTSIDE COLOUR with price logic =====
        $outside_colour = isset($_POST['door_colour']) ? $_POST['door_colour'] : '';
        $inside_colour = isset($_POST['inside_colour']) ? $_POST['inside_colour'] : '';
        $custom_outside = isset($_POST['custom_colour_select']) ? $_POST['custom_colour_select'] : '';
        $custom_inside = isset($_POST['custom_inside_colour_select']) ? $_POST['custom_inside_colour_select'] : '';
        
        if ( isset($_POST['door_colour']) ) {
            if ( $_POST['door_colour'] === 'custom_ral' && isset($_POST['custom_colour_select']) && !empty($_POST['custom_colour_select']) ) {
                $wizard_data['outside_colour'] = sanitize_text_field($_POST['custom_colour_select']);
                $wizard_data['outside_colour_price'] = 195;
                $wizard_data['outside_ral'] = str_replace('RAL ', '', $_POST['custom_colour_select']);
            } else {
                $colour_map = array(
                    'anthracite_grey' => 'Anthracite Grey',
                    'black' => 'Black',
                    'white' => 'White'
                );
                $wizard_data['outside_colour'] = isset( $colour_map[$_POST['door_colour']] ) ? $colour_map[$_POST['door_colour']] : $_POST['door_colour'];
                
                $ral_map = array(
                    'anthracite_grey' => '7016',
                    'black' => '9005',
                    'white' => '9016'
                );
                $wizard_data['outside_ral'] = isset( $ral_map[$_POST['door_colour']] ) ? $ral_map[$_POST['door_colour']] : $_POST['door_colour'];
                $wizard_data['outside_colour_price'] = 0;
            }
        } else {
            $wizard_data['outside_colour'] = isset($_POST['summary_outside_colour']) ? sanitize_text_field($_POST['summary_outside_colour']) : '';
        }
        
        // ===== INSIDE COLOUR with price logic =====
        if ( isset($_POST['inside_colour']) ) {
            // Define standard colours
            $standard_colours = array('anthracite_grey', 'black', 'white');
            
            // Check for free dual colour combination

            $is_free_dual = (
                $outside_colour === 'anthracite_grey' && 
                $_POST['inside_colour'] === 'white' && 
                empty($custom_outside) && 
                !isset($_POST['custom_inside_colour_select'])
            );

            $is_same_standard = (
                $outside_colour === $_POST['inside_colour'] && 
                in_array($_POST['inside_colour'], $standard_colours) &&
                empty($custom_outside) && 
                !isset($_POST['custom_inside_colour_select'])
            );

            $is_standard_dual = (
                in_array($outside_colour, $standard_colours) &&
                in_array($_POST['inside_colour'], $standard_colours) &&
                $outside_colour !== $_POST['inside_colour'] &&
                !$is_free_dual && 
                empty($custom_outside) && 
                !isset($_POST['custom_inside_colour_select'])
            );
            
            if ( $_POST['inside_colour'] === 'custom_ral' && isset($_POST['custom_inside_colour_select']) && !empty($_POST['custom_inside_colour_select']) ) {
                $wizard_data['inside_colour'] = sanitize_text_field($_POST['custom_inside_colour_select']);
                
                if ( $is_free_dual ) {
                    $wizard_data['inside_colour_price'] = 0;
                } else {
                    $wizard_data['inside_colour_price'] = 195;
                }
                
                $wizard_data['inside_ral'] = str_replace('RAL ', '', $_POST['custom_inside_colour_select']);
            } else {
                $colour_map = array(
                    'anthracite_grey' => 'Anthracite Grey',
                    'black' => 'Black',
                    'white' => 'White'
                );
                $wizard_data['inside_colour'] = isset( $colour_map[$_POST['inside_colour']] ) ? $colour_map[$_POST['inside_colour']] : $_POST['inside_colour'];
                
                $ral_map = array(
                    'anthracite_grey' => '7016',
                    'black' => '9005',
                    'white' => '9016'
                );
                $wizard_data['inside_ral'] = isset( $ral_map[$_POST['inside_colour']] ) ? $ral_map[$_POST['inside_colour']] : $_POST['inside_colour'];
                
                if ( $is_free_dual || $is_same_standard ) {
                    $wizard_data['inside_colour_price'] = 0;
                } elseif ( $is_standard_dual ) {
                    $wizard_data['inside_colour_price'] = 195;
                } else {
                    $wizard_data['inside_colour_price'] = 0;
                }
            }
        } else {
            $wizard_data['inside_colour'] = isset($_POST['summary_inside_colour']) ? sanitize_text_field($_POST['summary_inside_colour']) : '';
        }
        
        $wizard_data['handle'] = isset($_POST['summary_handle_colour']) ? sanitize_text_field($_POST['summary_handle_colour']) : '';
        
        // Glass field with No Thanks support
        if (isset($_POST['summary_glass'])) {
            $glass_value = sanitize_text_field($_POST['summary_glass']);
            if ($glass_value === 'No Thanks - Standard Glass') {
                $wizard_data['glass'] = 'no_thanks';
            } else {
                $wizard_data['glass'] = $glass_value;
            }
        } else {
            $wizard_data['glass'] = '';
        }
        
        $wizard_data['vents'] = isset($_POST['trickle_vents']) ? 
                               ($_POST['trickle_vents'] === 'yes_trickle' ? 'With Vents' : 'No Vents') : 
                               (isset($_POST['summary_trickle_vents']) ? 
                                ($_POST['summary_trickle_vents'] === 'Yes, Add Trickle Vent' ? 'With Vents' : 'No Vents') : 'No Vents');
        
        $wizard_data['threshold'] = isset($_POST['summary_threshold']) ? sanitize_text_field($_POST['summary_threshold']) : '';
        $wizard_data['cill'] = isset($_POST['summary_cill']) ? sanitize_text_field($_POST['summary_cill']) : '';
        
        // Delivery data
        $wizard_data['delivery_price'] = isset($_POST['delivery_price']) ? floatval($_POST['delivery_price']) : 0;
        $wizard_data['delivery_zone'] = isset($_POST['delivery_zone']) ? sanitize_text_field($_POST['delivery_zone']) : '';
        $wizard_data['delivery_distance'] = isset($_POST['delivery_distance']) ? floatval($_POST['delivery_distance']) : 0;
        $wizard_data['delivery_bespoke'] = isset($_POST['delivery_bespoke']) ? sanitize_text_field($_POST['delivery_bespoke']) : '0';
        $wizard_data['postcode'] = isset($_POST['postcode']) ? sanitize_text_field($_POST['postcode']) : 
                                  (isset($_POST['summary_postcode']) ? sanitize_text_field($_POST['summary_postcode']) : '');
        
        $wizard_data['access'] = isset($_POST['summary_access']) ? sanitize_text_field($_POST['summary_access']) : '';
        
        // Add customer info if available
        if (isset($_POST['first_name'])) {
            $wizard_data['first_name'] = sanitize_text_field($_POST['first_name']);
        }
        if (isset($_POST['last_name'])) {
            $wizard_data['last_name'] = sanitize_text_field($_POST['last_name']);
        }
        if (isset($_POST['email_address'])) {
            $wizard_data['email'] = sanitize_email($_POST['email_address']);
        }
        if (isset($_POST['mobile_number'])) {
            $wizard_data['phone'] = sanitize_text_field($_POST['mobile_number']);
        }
        
        // Add unique identifier to prevent merging
        $wizard_data['unique_id'] = uniqid('door_', true);
        $wizard_data['timestamp'] = time();
        
        // Create cart item data with unique key
        $unique_hash = md5( serialize( $wizard_data ) . time() . rand(1000, 9999) );
        
        $cart_item_data = [
            'wizard_data'  => $wizard_data,
            'custom_price' => $final_price,
            'unique_key'   => $unique_hash
        ];

        // If variation_id is 0, try to get the first available variation
        if ($variation_id === 0) {
            $product = wc_get_product($product_id);
            if ($product && $product->is_type('variable')) {
                $available_variations = $product->get_available_variations();
                if (!empty($available_variations)) {
                    $variation_id = $available_variations[0]['variation_id'];
                }
            }
        }

        // Add to cart
        $added = WC()->cart->add_to_cart( 
            $product_id,    // Product ID
            1,             // Quantity
            $variation_id,  // Variation ID (now optional)
            [],            // Variation attributes
            $cart_item_data // Custom data
        );

        if ( $added ) {
            $cart_count = WC()->cart->get_cart_contents_count();
            
            if ( $is_checkout ) {
                wc_add_notice( 'Custom door added. Proceeding to checkout.', 'success' );
                wp_safe_redirect( wc_get_checkout_url() );
            } else {
                wc_add_notice( sprintf( 'Custom door added to cart successfully! Cart now has %d items.', $cart_count ), 'success' );
                wp_safe_redirect( wc_get_cart_url() );
            }
        } else {
            wc_add_notice( 'Failed to add product to cart. Please try again.', 'error' );
            wp_safe_redirect( wc_get_cart_url() );
        }
        exit;
    }
});

/**
 * AJAX handler for builder form submission - UPDATED with colour pricing logic
 */
add_action( 'wp_ajax_process_door_builder', 'process_door_builder_ajax' );
add_action( 'wp_ajax_nopriv_process_door_builder', 'process_door_builder_ajax' );
function process_door_builder_ajax() {
    
    // Verify AJAX nonce
    if ( ! check_ajax_referer( 'door_builder_ajax', 'security', false ) ) {
        wp_send_json_error([ 'message' => 'Security check failed (AJAX nonce).' ]);
    }
    
    // Parse the form data
    parse_str($_POST['form_data'], $form_data);
    
    // Verify form nonce
    if ( ! isset( $form_data['builder_nonce'] ) || ! wp_verify_nonce( $form_data['builder_nonce'], 'door_builder_action' ) ) {
        wp_send_json_error([ 'message' => 'Security check failed (Invalid nonce).' ]);
    }
    
    $product_id   = absint( $form_data['product_id'] );
    $variation_id = isset( $form_data['variation_id'] ) ? absint( $form_data['variation_id'] ) : 0;
    $final_price  = isset($form_data['final_price']) ? floatval( $form_data['final_price'] ) : 0;
    
    // Check if this is edit mode
    $edit_mode = isset( $form_data['edit_mode'] ) && $form_data['edit_mode'] == '1';
    $cart_item_key = isset( $form_data['cart_item_key'] ) ? sanitize_text_field( $form_data['cart_item_key'] ) : '';

    // Collect form data
    $wizard_data = array();
    
    // Size data
    if ( isset( $form_data['width'] ) ) {
        $wizard_data['width'] = intval( $form_data['width'] );
        $wizard_data['height'] = intval( $form_data['height'] );
    }
    
    // Panel data
    if ( isset( $form_data['panel_layout'] ) ) {
        $panel_value = $form_data['panel_layout'];
        $panel_map = array(
            '2_left' => '2 Panels Left',
            '2_right' => '2 Panels Right',
            '1_2' => '1 + 2 Panels',
            '2_1' => '2 + 1 Panels',
            '3_left' => '3 Panels Left',
            '3_right' => '3 Panels Right',
            '1_3' => '1 + 3 Panels',
            '3_1' => '3 + 1 Panels',
            '2_2' => '2 + 2 Panels',
            '4_left' => '4 Panels Left',
            '4_right' => '4 Panels Right',
            '1_4' => '1 + 4 Panels',
            '4_1' => '4 + 1 Panels',
            '2_3' => '2 + 3 Panels',
            '3_2' => '3 + 2 Panels',
            '5_left' => '5 Panels Left',
            '5_right' => '5 Panels Right',
            '1_5' => '1 + 5 Panels',
            '2_4' => '2 + 4 Panels',
            '3_3' => '3 + 3 Panels',
            '4_2' => '4 + 2 Panels',
            '5_1' => '5 + 1 Panels',
            '6_left' => '6 Panels Left',
            '6_right' => '6 Panels Right',
            'french' => 'French Doors'
        );
        $wizard_data['panels'] = isset( $panel_map[$panel_value] ) ? $panel_map[$panel_value] : $panel_value;
    }
    
    // Opening Direction
    if ( isset( $form_data['open_direction'] ) ) {
        $wizard_data['opening'] = $form_data['open_direction'] === 'inwards' ? 'Inwards' : 'Outwards';
    }
    
    // ===== OUTSIDE COLOUR with price logic =====
    if ( isset( $form_data['door_colour'] ) ) {
        $colour = $form_data['door_colour'];
        
        if ( $colour === 'custom_ral' && isset( $form_data['custom_colour_select'] ) && !empty($form_data['custom_colour_select']) ) {
            $wizard_data['outside_colour'] = $form_data['custom_colour_select'];
            $wizard_data['outside_colour_price'] = 195; // Custom RAL price
            $wizard_data['outside_ral'] = str_replace('RAL ', '', $form_data['custom_colour_select']);
        } else {
            $colour_map = array(
                'anthracite_grey' => 'Anthracite Grey',
                'black' => 'Black',
                'white' => 'White'
            );
            $wizard_data['outside_colour'] = isset( $colour_map[$colour] ) ? $colour_map[$colour] : $colour;
            
            $ral_map = array(
                'anthracite_grey' => '7016',
                'black' => '9005',
                'white' => '9016'
            );
            $wizard_data['outside_ral'] = isset( $ral_map[$colour] ) ? $ral_map[$colour] : $colour;
            $wizard_data['outside_colour_price'] = 0; // Standard colour price (will be calculated based on combination)
        }
    }
    
    // ===== INSIDE COLOUR with price logic =====
    if ( isset( $form_data['inside_colour'] ) ) {
        $colour = $form_data['inside_colour'];
        $outside_colour = isset( $form_data['door_colour'] ) ? $form_data['door_colour'] : '';
        $custom_outside = isset( $form_data['custom_colour_select'] ) ? $form_data['custom_colour_select'] : '';
        
        // Define standard colours
        $standard_colours = array('anthracite_grey', 'black', 'white');
        
        // Check for free dual colour combination: Anthracite Grey outside / White inside
        $is_free_dual = (
            $outside_colour === 'anthracite_grey' && 
            $colour === 'white' && 
            empty($custom_outside) && 
            !isset($form_data['custom_inside_colour_select'])
        );
        
        // Check for same standard colour both sides (also free)
        $is_same_standard = (
            $outside_colour === $colour && 
            in_array($colour, $standard_colours) &&
            empty($custom_outside) && 
            !isset($form_data['custom_inside_colour_select'])
        );
        
        // Check for standard dual colour (different standard colours) - CHARGEABLE
        $is_standard_dual = (
            in_array($outside_colour, $standard_colours) &&
            in_array($colour, $standard_colours) &&
            $outside_colour !== $colour &&
            !$is_free_dual && 
            empty($custom_outside) && 
            !isset($form_data['custom_inside_colour_select'])
        );
        
        if ( $colour === 'custom_ral' && isset( $form_data['custom_inside_colour_select'] ) && !empty($form_data['custom_inside_colour_select']) ) {
            $wizard_data['inside_colour'] = $form_data['custom_inside_colour_select'];
            
            // Price logic: free only if it's the specific free dual, otherwise charge
            if ( $is_free_dual ) {
                $wizard_data['inside_colour_price'] = 0;
            } else {
                $wizard_data['inside_colour_price'] = 195;
            }
            
            $wizard_data['inside_ral'] = str_replace('RAL ', '', $form_data['custom_inside_colour_select']);
        } else {
            $colour_map = array(
                'anthracite_grey' => 'Anthracite Grey',
                'black' => 'Black',
                'white' => 'White'
            );
            $wizard_data['inside_colour'] = isset( $colour_map[$colour] ) ? $colour_map[$colour] : $colour;
            
            $ral_map = array(
                'anthracite_grey' => '7016',
                'black' => '9005',
                'white' => '9016'
            );
            $wizard_data['inside_ral'] = isset( $ral_map[$colour] ) ? $ral_map[$colour] : $colour;
            
            // Price logic for standard colours
            if ( $is_free_dual || $is_same_standard ) {
                $wizard_data['inside_colour_price'] = 0; // Free
            } elseif ( $is_standard_dual ) {
                $wizard_data['inside_colour_price'] = 195; // Standard dual colours are chargeable
            } else {
                $wizard_data['inside_colour_price'] = 0; // Default
            }
        }
    }
    
    // Handle Colour
    if ( isset( $form_data['handle_colour'] ) ) {
        $handle = $form_data['handle_colour'];
        $handle_map = array(
            'white' => 'White',
            'chrome' => 'Chrome',
            'black' => 'Black',
            'black_white' => 'Black and White'
        );
        $wizard_data['handle'] = isset( $handle_map[$handle] ) ? $handle_map[$handle] : $handle;
    }
    
    // Glass with No Thanks support
    if ( isset( $form_data['glass_upgrade'] ) ) {
        $glass = $form_data['glass_upgrade'];
        
        if ($glass === 'no_thanks') {
            $wizard_data['glass'] = 'no_thanks';
        } else {
            $glass_map = array(
                'self_cleaning' => 'Self-cleaning glass',
                'integral_blinds' => 'Integral blinds',
                'obscure_glass' => 'Obscure glass',
                'saint_gobain_12' => 'Saint-Gobain Planitherm 1.2'
            );
            $wizard_data['glass'] = isset( $glass_map[$glass] ) ? $glass_map[$glass] : $glass;
        }
    }
    
    // Trickle Vents
    if ( isset( $form_data['trickle_vents'] ) ) {
        $wizard_data['vents'] = $form_data['trickle_vents'] === 'yes_trickle' ? 'With Vents' : 'No Vents';
    }
    
    // Cill
    if ( isset( $form_data['cill'] ) ) {
        $wizard_data['cill'] = $form_data['cill'] === 'none' ? 'No Cill' : $form_data['cill'];
    }
    
    // Postcode and Delivery Data
    if ( isset( $form_data['postcode'] ) ) {
        $wizard_data['postcode'] = sanitize_text_field( $form_data['postcode'] );
    }
    
    if ( isset( $form_data['delivery_price'] ) ) {
        $wizard_data['delivery_price'] = floatval( $form_data['delivery_price'] );
    }
    
    if ( isset( $form_data['delivery_zone'] ) ) {
        $wizard_data['delivery_zone'] = sanitize_text_field( $form_data['delivery_zone'] );
    }
    
    if ( isset( $form_data['delivery_distance'] ) ) {
        $wizard_data['delivery_distance'] = floatval( $form_data['delivery_distance'] );
    }
    
    if ( isset( $form_data['delivery_bespoke'] ) ) {
        $wizard_data['delivery_bespoke'] = sanitize_text_field( $form_data['delivery_bespoke'] );
    }
    
    // Access Issues
    if ( isset( $form_data['access_issues'] ) ) {
        if ( $form_data['access_issues'] === 'yes_access' ) {
            $access_desc = isset( $form_data['access_description'] ) && !empty( $form_data['access_description'] ) 
                ? sanitize_text_field( $form_data['access_description'] ) 
                : 'Yes';
            $wizard_data['access'] = $access_desc;
        } else {
            $wizard_data['access'] = 'No';
        }
    }
    
    // Customer Information
    if ( isset( $form_data['first_name'] ) ) {
        $wizard_data['first_name'] = sanitize_text_field( $form_data['first_name'] );
    }
    if ( isset( $form_data['last_name'] ) ) {
        $wizard_data['last_name'] = sanitize_text_field( $form_data['last_name'] );
    }
    if ( isset( $form_data['email_address'] ) ) {
        $wizard_data['email'] = sanitize_email( $form_data['email_address'] );
    }
    if ( isset( $form_data['mobile_number'] ) ) {
        $wizard_data['phone'] = sanitize_text_field( $form_data['mobile_number'] );
    }
    
    $wizard_data['unique_id'] = uniqid('door_', true);
    $wizard_data['timestamp'] = time();
    
    $unique_hash = md5( serialize( $wizard_data ) . time() . rand(1000, 9999) );
    
    $cart_item_data = [
        'wizard_data'  => $wizard_data,
        'custom_price' => $final_price,
        'unique_key'   => $unique_hash
    ];

    // If variation_id is 0, try to get the first available variation
    if ($variation_id === 0) {
        $product = wc_get_product($product_id);
        if ($product && $product->is_type('variable')) {
            $available_variations = $product->get_available_variations();
            if (!empty($available_variations)) {
                $variation_id = $available_variations[0]['variation_id'];
            }
        }
    }

    // ===== EDIT MODE HANDLING =====
    if ( $edit_mode && !empty( $cart_item_key ) ) {
        $cart = WC()->cart->get_cart();
        
        if ( isset( $cart[$cart_item_key] ) ) {
            $cart_item = $cart[$cart_item_key];
            
            // Remove old item
            WC()->cart->remove_cart_item($cart_item_key);
            
            // Add updated item with same quantity and variation
            WC()->cart->add_to_cart(
                $cart_item['product_id'],
                $cart_item['quantity'],
                $cart_item['variation_id'],
                $cart_item['variation'],
                $cart_item_data
            );
            
            wp_send_json_success([
                'message' => 'Cart updated successfully!',
                'cart_url' => wc_get_cart_url(),
                'is_checkout' => false
            ]);
        } else {
            wp_send_json_error([ 'message' => 'Cart item not found.' ]);
        }
    } 
    // ===== NORMAL ADD TO CART =====
    else {
        $added = WC()->cart->add_to_cart( $product_id, 1, $variation_id, [], $cart_item_data );

        if ( $added ) {
            wp_send_json_success([
                'message' => 'Added to cart successfully!',
                'cart_url' => wc_get_cart_url(),
                'is_checkout' => false
            ]);
        } else {
            wp_send_json_error([ 'message' => 'Failed to add product to cart.' ]);
        }
    }
}

/**
 * Apply custom price in cart
 */
add_action( 'woocommerce_before_calculate_totals', 'apply_custom_price_to_cart', 9999, 1 );
function apply_custom_price_to_cart( $cart ) {
    if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
        return;
    }

    if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 ) {
        return;
    }

    foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
        if ( isset( $cart_item['custom_price'] ) && $cart_item['custom_price'] > 0 ) {
            $cart_item['data']->set_price( $cart_item['custom_price'] );
        }
    }
}

/**
 * Add delivery charge to cart based on postcode
 */
add_action('woocommerce_before_calculate_totals', 'add_delivery_charge_to_cart', 20, 1);
function add_delivery_charge_to_cart($cart) {
    if (is_admin() && !defined('DOING_AJAX')) {
        return;
    }
    
    // Prevent multiple runs
    if (did_action('woocommerce_before_calculate_totals') >= 2) {
        return;
    }
    
    // Check if there's a door builder product in cart with postcode
    $has_door_builder = false;
    $delivery_data = null;
    $delivery_price = 0;
    $delivery_zone = '';
    $delivery_distance = 0;
    $is_bespoke = false;
    
    foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
        if (isset($cart_item['wizard_data']['postcode']) && !empty($cart_item['wizard_data']['postcode'])) {
            $has_door_builder = true;
            
            // Get delivery data from wizard_data if available
            if (isset($cart_item['wizard_data']['delivery_price'])) {
                $delivery_price = floatval($cart_item['wizard_data']['delivery_price']);
                $delivery_zone = isset($cart_item['wizard_data']['delivery_zone']) ? $cart_item['wizard_data']['delivery_zone'] : '';
                $delivery_distance = isset($cart_item['wizard_data']['delivery_distance']) ? floatval($cart_item['wizard_data']['delivery_distance']) : 0;
                $is_bespoke = isset($cart_item['wizard_data']['delivery_bespoke']) && $cart_item['wizard_data']['delivery_bespoke'] === '1';
            } else {
                // Calculate if not available
                $postcode = $cart_item['wizard_data']['postcode'];
                $calculator = new Door_Delivery_Calculator();
                $delivery_data = $calculator->calculate_delivery($postcode);
                $delivery_price = $delivery_data['price'];
                $delivery_zone = $delivery_data['zone'];
                $delivery_distance = $delivery_data['distance'];
                $is_bespoke = $delivery_data['bespoke'];
            }
            break;
        }
    }
    
    if (!$has_door_builder) {
        return;
    }
    
    // Store delivery data in session for checkout blocking
    WC()->session->set('door_delivery_data', [
        'price' => $delivery_price,
        'zone' => $delivery_zone,
        'distance' => $delivery_distance,
        'bespoke' => $is_bespoke
    ]);
    
    // Add delivery fee as a separate fee (only once)
    if (!$is_bespoke && $delivery_price > 0) {
        // Check if fee already exists to prevent duplicates
        $fee_exists = false;
        foreach ($cart->get_fees() as $fee) {
            if (strpos($fee->name, 'Delivery') !== false) {
                $fee_exists = true;
                break;
            }
        }
        
        if (!$fee_exists) {
            $cart->add_fee(
                __('Delivery', 'woocommerce') . ' (' . $delivery_zone . ' - ' . round($delivery_distance, 1) . ' miles)',
                $delivery_price,
                true // Taxable
            );
        }
    }
}

/**
 * Block checkout for bespoke delivery zones
 */
add_action('woocommerce_checkout_process', 'block_checkout_for_bespoke_delivery');
function block_checkout_for_bespoke_delivery() {
    $delivery_data = WC()->session->get('door_delivery_data');
    
    if ($delivery_data && isset($delivery_data['bespoke']) && $delivery_data['bespoke']) {
        wc_add_notice(
            sprintf(
                'Bespoke delivery required for %s. Please call our sales team on 01234 567890 to complete your order.',
                $delivery_data['zone']
            ),
            'error'
        );
    }
}

/**
 * Save wizard data to order items - UPDATED for colour pricing
 */
add_action( 'woocommerce_checkout_create_order_line_item', function( $item, $cart_item_key, $values ) {
    if ( ! empty( $values['wizard_data'] ) ) {
        foreach ( $values['wizard_data'] as $key => $value ) {
            // Special handling for glass to ensure display text is saved
            if ($key === 'glass') {
                if ($value === 'no_thanks') {
                    $item->add_meta_data( 'builder_glass', 'No Thanks - Standard Glass', true );
                } else {
                    $item->add_meta_data( 'builder_glass', $value, true );
                }
            } 
            // Save colour prices for reference
            elseif ($key === 'outside_colour_price' || $key === 'inside_colour_price') {
                $item->add_meta_data( 'builder_' . $key, $value, true );
            }
            else {
                $item->add_meta_data( 'builder_' . $key, $value, true );
            }
        }
    }
    
    // Save custom price
    if ( isset( $values['custom_price'] ) ) {
        $item->add_meta_data( '_custom_price', $values['custom_price'], true );
        $item->add_meta_data( '_line_total', $values['custom_price'] );
        $item->add_meta_data( '_line_subtotal', $values['custom_price'] );
    }
}, 10, 3 );

/**
 * Display proper glass text in cart and checkout
 */
add_filter('woocommerce_get_item_data', 'display_glass_text_in_cart', 10, 2);
function display_glass_text_in_cart($item_data, $cart_item) {
    if (isset($cart_item['wizard_data']['glass'])) {
        $glass_value = $cart_item['wizard_data']['glass'];
        
        // Convert value to display text
        $display_text = $glass_value;
        
        if ($glass_value === 'no_thanks') {
            $display_text = 'No Thanks - Standard Glass';
        } elseif ($glass_value === 'self_cleaning') {
            $display_text = 'Self-cleaning glass';
        } elseif ($glass_value === 'integral_blinds') {
            $display_text = 'Integral blinds';
        } elseif ($glass_value === 'obscure_glass') {
            $display_text = 'Obscure glass';
        } elseif ($glass_value === 'saint_gobain_12') {
            $display_text = 'Saint-Gobain Planitherm 1.2';
        }
        
        $item_data[] = array(
            'name' => 'Glass',
            'value' => $display_text
        );
    }
    
    return $item_data;
}

/**
 * Display proper glass text in order details
 */
/* add_action('woocommerce_order_item_meta_end', 'display_glass_text_in_order', 10, 4);
function display_glass_text_in_order($item_id, $item, $order, $plain_text) {
    $glass_value = $item->get_meta('builder_glass');
    
    if ($glass_value) {
        $display_text = $glass_value;
        
        // If it's stored as no_thanks, convert to display text
        if ($glass_value === 'no_thanks') {
            $display_text = 'No Thanks - Standard Glass';
        }
        
        if ($plain_text) {
            echo "Glass: " . $display_text . "\n";
        } else {
            echo '<div><strong>Glass:</strong> ' . $display_text . '</div>';
        }
    }
} */

/**
 * Security: Validate builder page access - UPDATED for optional variation_id
 */
add_action( 'template_redirect', function() {
    if ( is_page( 'bifold-door-builder' ) ) {
        // Check if product_id exists (variation_id is now optional)
        if ( ! isset( $_GET['product_id'] ) ) {
            wp_die( 'Invalid access. Please select a product first.' );
        }
        
        // Verify product exists
        $product_id = absint( $_GET['product_id'] );
        $product = wc_get_product( $product_id );
        
        if ( ! $product ) {
            wp_die( 'Invalid product selection.' );
        }
        
        // variation_id optional - no validation needed
    }
} );

/**
 * Create Bifold Door Builder page on theme activation
 */
register_activation_hook( __FILE__, 'create_bifold_door_builder_page' );
function create_bifold_door_builder_page() {
    $page_exists = get_page_by_path( 'bifold-door-builder' );
    
    if ( ! $page_exists ) {
        $page_data = array(
            'post_title'    => 'Bifold Door Builder',
            'post_name'     => 'bifold-door-builder',
            'post_content'  => '<!-- This page uses custom template -->',
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'post_author'   => 1,
            'page_template' => 'page-bifold-door-builder.php'
        );
        
        wp_insert_post( $page_data );
    }
}

/**
 * Add nonce field for security
 */
add_action( 'wp_head', function() {
    if ( is_page( 'bifold-door-builder' ) ) {
        wp_nonce_field( 'door_builder_action', 'builder_nonce' );
    }
} );

/**
 * Hide Astra scroll to top arrow on builder page
 */
add_action( 'wp_head', 'hide_astra_scroll_top' );
function hide_astra_scroll_top() {
    if ( is_page( 'bifold-door-builder' ) ) {
        ?>
        <style>
            /* Hide Astra scroll to top arrow */
            #ast-scroll-top {
                display: none !important;
                visibility: hidden !important;
                opacity: 0 !important;
                pointer-events: none !important;
            }
            
            .ast-scroll-top-icon {
                display: none !important;
            }
        </style>
        <?php
    }
}

/**
 * Completely disable Astra scroll to top feature
 */
add_filter( 'astra_get_option_scroll-to-top', '__return_false' );
remove_action( 'astra_footer_after', 'astra_scroll_to_top', 1 );


add_action('woocommerce_before_shop_loop_item_title', function(){
    echo '<a href="' . get_the_permalink() . '">';
}, 1);

add_action('woocommerce_after_shop_loop_item', function(){
    echo '</a>';
}, 100);

/**
 * Prevent WooCommerce from merging cart items with same product/variation
 */
add_filter( 'woocommerce_add_cart_item_data', 'custom_door_builder_cart_item_data', 10, 3 );
function custom_door_builder_cart_item_data( $cart_item_data, $product_id, $variation_id ) {
    
    // Check if this is an AJAX request with form_data
    if ( isset( $_POST['form_data'] ) ) {
        parse_str( $_POST['form_data'], $form_data );
    } else {
        $form_data = $_POST;
    }
    
    // Collect all form data
    $wizard_data = array();
    
    // === STEP 1: Size ===
    if ( isset( $form_data['width'] ) && isset( $form_data['height'] ) ) {
        $wizard_data['width'] = intval( $form_data['width'] );
        $wizard_data['height'] = intval( $form_data['height'] );
    }
    
    // === STEP 2: Panels ===
    if ( isset( $form_data['panel_layout'] ) ) {
        $panel_value = $form_data['panel_layout'];
        $panel_map = array(
            '2_left' => '2 Panels Left',
            '2_right' => '2 Panels Right',
            '1_2' => '1 + 2 Panels',
            '2_1' => '2 + 1 Panels',
            '3_left' => '3 Panels Left',
            '3_right' => '3 Panels Right',
            '1_3' => '1 + 3 Panels',
            '3_1' => '3 + 1 Panels',
            '2_2' => '2 + 2 Panels',
            '4_left' => '4 Panels Left',
            '4_right' => '4 Panels Right',
            '1_4' => '1 + 4 Panels',
            '4_1' => '4 + 1 Panels',
            '2_3' => '2 + 3 Panels',
            '3_2' => '3 + 2 Panels',
            '5_left' => '5 Panels Left',
            '5_right' => '5 Panels Right',
            '1_5' => '1 + 5 Panels',
            '2_4' => '2 + 4 Panels',
            '3_3' => '3 + 3 Panels',
            '4_2' => '4 + 2 Panels',
            '5_1' => '5 + 1 Panels',
            '6_left' => '6 Panels Left',
            '6_right' => '6 Panels Right',
            'french' => 'French Doors'
        );
        $wizard_data['panels'] = isset( $panel_map[$panel_value] ) ? $panel_map[$panel_value] : $panel_value;
    }
    
    // === STEP 3: Opening Direction ===
    if ( isset( $form_data['open_direction'] ) ) {
        $wizard_data['opening'] = $form_data['open_direction'] === 'inwards' ? 'Inwards' : 'Outwards';
    }
    
    // === STEP 4: Outside Colour with price logic ===
    if ( isset( $form_data['door_colour'] ) ) {
        $colour = $form_data['door_colour'];
        
        if ( $colour === 'custom_ral' && isset( $form_data['custom_colour_select'] ) && !empty($form_data['custom_colour_select']) ) {
            $wizard_data['outside_colour'] = $form_data['custom_colour_select'];
            $wizard_data['outside_colour_price'] = 195;
            $wizard_data['outside_ral'] = str_replace('RAL ', '', $form_data['custom_colour_select']);
        } else {
            $colour_map = array(
                'anthracite_grey' => 'Anthracite Grey',
                'black' => 'Black',
                'white' => 'White'
            );
            $wizard_data['outside_colour'] = isset( $colour_map[$colour] ) ? $colour_map[$colour] : $colour;
            
            $ral_map = array(
                'anthracite_grey' => '7016',
                'black' => '9005',
                'white' => '9016'
            );
            $wizard_data['outside_ral'] = isset( $ral_map[$colour] ) ? $ral_map[$colour] : $colour;
            $wizard_data['outside_colour_price'] = 0;
        }
    }
    
    // === STEP 5: Inside Colour with price logic ===
    if ( isset( $form_data['inside_colour'] ) ) {
        $colour = $form_data['inside_colour'];
        $outside_colour = isset( $form_data['door_colour'] ) ? $form_data['door_colour'] : '';
        $custom_outside = isset( $form_data['custom_colour_select'] ) ? $form_data['custom_colour_select'] : '';
        
        // Define standard colours
        $standard_colours = array('anthracite_grey', 'black', 'white');
        
        // Check for free dual colour combination
        $is_free_dual = (
            $outside_colour === 'anthracite_grey' && 
            $colour === 'white' && 
            empty($custom_outside) && 
            !isset($form_data['custom_inside_colour_select'])
        );
        
        // Check for same standard colour both sides (also free)
        $is_same_standard = (
            $outside_colour === $colour && 
            in_array($colour, $standard_colours) &&
            empty($custom_outside) && 
            !isset($form_data['custom_inside_colour_select'])
        );
        
        // Check for standard dual colour (different standard colours) - CHARGEABLE
        $is_standard_dual = (
            in_array($outside_colour, $standard_colours) &&
            in_array($colour, $standard_colours) &&
            $outside_colour !== $colour &&
            !$is_free_dual && 
            empty($custom_outside) && 
            !isset($form_data['custom_inside_colour_select'])
        );
        
        if ( $colour === 'custom_ral' && isset( $form_data['custom_inside_colour_select'] ) && !empty($form_data['custom_inside_colour_select']) ) {
            $wizard_data['inside_colour'] = $form_data['custom_inside_colour_select'];
            
            if ( $is_free_dual ) {
                $wizard_data['inside_colour_price'] = 0;
            } else {
                $wizard_data['inside_colour_price'] = 195;
            }
            
            $wizard_data['inside_ral'] = str_replace('RAL ', '', $form_data['custom_inside_colour_select']);
        } else {
            $colour_map = array(
                'anthracite_grey' => 'Anthracite Grey',
                'black' => 'Black',
                'white' => 'White'
            );
            $wizard_data['inside_colour'] = isset( $colour_map[$colour] ) ? $colour_map[$colour] : $colour;
            
            $ral_map = array(
                'anthracite_grey' => '7016',
                'black' => '9005',
                'white' => '9016'
            );
            $wizard_data['inside_ral'] = isset( $ral_map[$colour] ) ? $ral_map[$colour] : $colour;
            
            if ( $is_free_dual || $is_same_standard ) {
                $wizard_data['inside_colour_price'] = 0;
            } elseif ( $is_standard_dual ) {
                $wizard_data['inside_colour_price'] = 195;
            } else {
                $wizard_data['inside_colour_price'] = 0;
            }
        }
    }
    
    // === STEP 6: Handle Colour ===
    if ( isset( $form_data['handle_colour'] ) ) {
        $handle = $form_data['handle_colour'];
        $handle_map = array(
            'white' => 'White',
            'chrome' => 'Chrome',
            'black' => 'Black',
            'black_white' => 'Black and White'
        );
        $wizard_data['handle'] = isset( $handle_map[$handle] ) ? $handle_map[$handle] : $handle;
    }
    
    // === STEP 7: Glass - with No Thanks support ===
    if ( isset( $form_data['glass_upgrade'] ) ) {
        $glass = $form_data['glass_upgrade'];
        
        if ($glass === 'no_thanks') {
            $wizard_data['glass'] = 'no_thanks';
        } else {
            $glass_map = array(
                'self_cleaning' => 'Self-cleaning glass',
                'integral_blinds' => 'Integral blinds',
                'obscure_glass' => 'Obscure glass',
                'saint_gobain_12' => 'Saint-Gobain Planitherm 1.2'
            );
            $wizard_data['glass'] = isset( $glass_map[$glass] ) ? $glass_map[$glass] : $glass;
        }
    }
    
    // === STEP 8: Trickle Vents ===
    if ( isset( $form_data['trickle_vents'] ) ) {
        $wizard_data['vents'] = $form_data['trickle_vents'] === 'yes_trickle' ? 'With Vents' : 'No Vents';
    }
    
    // === STEP 9: Cill - STORE AS DISPLAY TEXT ===
    if ( isset( $form_data['cill'] ) ) {
        $cill_value = $form_data['cill'];
        
        if ($cill_value === 'none') {
            $wizard_data['cill'] = 'No Cill';
        } elseif ($cill_value === '150mm-aluminium-cill') {
            $wizard_data['cill'] = '150mm Aluminium Cill';
        } elseif ($cill_value === '150mm-upvc-cill') {
            $wizard_data['cill'] = '150mm uPVC Cill';
        } else {
            $wizard_data['cill'] = $cill_value;
        }
    }
    
    // === STEP 10: Postcode and Delivery ===
    if ( isset( $form_data['postcode'] ) ) {
        $wizard_data['postcode'] = sanitize_text_field( $form_data['postcode'] );
    }
    
    if ( isset( $form_data['delivery_price'] ) ) {
        $wizard_data['delivery_price'] = floatval( $form_data['delivery_price'] );
    }
    
    if ( isset( $form_data['delivery_zone'] ) ) {
        $wizard_data['delivery_zone'] = sanitize_text_field( $form_data['delivery_zone'] );
    }
    
    if ( isset( $form_data['delivery_distance'] ) ) {
        $wizard_data['delivery_distance'] = floatval( $form_data['delivery_distance'] );
    }
    
    if ( isset( $form_data['delivery_bespoke'] ) ) {
        $wizard_data['delivery_bespoke'] = sanitize_text_field( $form_data['delivery_bespoke'] );
    }
    
    // === STEP 11: Access Issues ===
    if ( isset( $form_data['access_issues'] ) ) {
        if ( $form_data['access_issues'] === 'yes_access' ) {
            $access_desc = isset( $form_data['access_description'] ) && !empty( $form_data['access_description'] ) 
                ? sanitize_text_field( $form_data['access_description'] ) 
                : 'Yes';
            $wizard_data['access'] = $access_desc;
        } else {
            $wizard_data['access'] = 'No';
        }
    }
    
    // === STEP 12: Customer Information ===
    if ( isset( $form_data['first_name'] ) ) {
        $wizard_data['first_name'] = sanitize_text_field( $form_data['first_name'] );
    }
    if ( isset( $form_data['last_name'] ) ) {
        $wizard_data['last_name'] = sanitize_text_field( $form_data['last_name'] );
    }
    if ( isset( $form_data['email_address'] ) ) {
        $wizard_data['email'] = sanitize_email( $form_data['email_address'] );
    }
    if ( isset( $form_data['mobile_number'] ) ) {
        $wizard_data['phone'] = sanitize_text_field( $form_data['mobile_number'] );
    }
    
    // Create a unique hash based on ALL selections
    $unique_hash = md5( serialize( $wizard_data ) . time() . rand(1000, 9999) );
    
    // Add data to cart item
    $cart_item_data['wizard_data'] = $wizard_data;
    $cart_item_data['unique_key'] = $unique_hash;
    
    return $cart_item_data;
}

/**
 * Display builder data after cart item name with EDIT button
 * Hook: woocommerce_after_cart_item_name
 */
add_action('woocommerce_after_cart_item_name', 'display_builder_data_with_edit_button', 10, 2);
function display_builder_data_with_edit_button($cart_item, $cart_item_key) {
    
    // Check if this is a builder product with wizard data
    if (!isset($cart_item['wizard_data']) || empty($cart_item['wizard_data'])) {
        return;
    }
    
    $wizard = $cart_item['wizard_data'];
    $base_url = home_url('/bifold-door-builder/');
    
    // Create edit URL
    $edit_url = add_query_arg(array(
        'edit_cart_item' => $cart_item_key,
        'product_id' => $cart_item['product_id'],
        'variation_id' => $cart_item['variation_id']
    ), $base_url);
    
    // Start output
    echo '<div class="door-builder-cart-data">';
    echo '<div class="cart-data-header">';
    echo '<h4>Your Custom Door Configuration</h4>';
    echo '<a href="' . esc_url($edit_url) . '" class="edit-config-btn">Edit Configuration</a>';
    echo '</div>';
    
    echo '<div class="config-details-grid">';
    
    // Manufacturing Size
    if (!empty($wizard['width']) && !empty($wizard['height'])) {
        echo '<div class="detail-item">';
        echo '<span class="detail-label">Size: </span>';
        echo '<span class="detail-value">' . esc_html($wizard['width'] . ' x ' . $wizard['height'] . ' mm') . '</span>';
        echo '</div>';
    }
    
    // Panels
    if (!empty($wizard['panels'])) {
        echo '<div class="detail-item">';
        echo '<span class="detail-label">Panels: </span>';
        echo '<span class="detail-value">' . esc_html($wizard['panels']) . '</span>';
        echo '</div>';
    }
    
    // Opening Direction
    if (!empty($wizard['opening'])) {
        echo '<div class="detail-item">';
        echo '<span class="detail-label">Opening: </span>';
        echo '<span class="detail-value">' . esc_html($wizard['opening']) . '</span>';
        echo '</div>';
    }
    
    // Outside Colour
    if (!empty($wizard['outside_colour'])) {
        $outside = $wizard['outside_colour'];
        if (!empty($wizard['outside_ral'])) {
            $outside .= ' (' . $wizard['outside_ral'] . ')';
        }
        echo '<div class="detail-item">';
        echo '<span class="detail-label">Outside: </span>';
        echo '<span class="detail-value">' . esc_html($outside) . '</span>';
        echo '</div>';
    }
    
    // Inside Colour
    if (!empty($wizard['inside_colour'])) {
        $inside = $wizard['inside_colour'];
        if (!empty($wizard['inside_ral'])) {
            $inside .= ' (' . $wizard['inside_ral'] . ')';
        }
        echo '<div class="detail-item">';
        echo '<span class="detail-label">Inside: </span>';
        echo '<span class="detail-value">' . esc_html($inside) . '</span>';
        echo '</div>';
    }
    
    // Handle Colour
    if (!empty($wizard['handle'])) {
        echo '<div class="detail-item">';
        echo '<span class="detail-label">Handle: </span>';
        echo '<span class="detail-value">' . esc_html($wizard['handle']) . '</span>';
        echo '</div>';
    }
    
    // Glass - UPDATED with No Thanks display
    if (!empty($wizard['glass'])) {
        $glass_display = $wizard['glass'];
        if ($glass_display === 'no_thanks') {
            $glass_display = 'No Thanks - Standard Glass';
        }
        echo '<div class="detail-item">';
        echo '<span class="detail-label">Glass: </span>';
        echo '<span class="detail-value">' . esc_html($glass_display) . '</span>';
        echo '</div>';
    }
    
    // Trickle Vents
    if (isset($wizard['vents'])) {
        echo '<div class="detail-item">';
        echo '<span class="detail-label">Vents: </span>';
        echo '<span class="detail-value">' . esc_html($wizard['vents']) . '</span>';
        echo '</div>';
    }
    
    // Cill
    if (!empty($wizard['cill'])) {
        echo '<div class="detail-item">';
        echo '<span class="detail-label">Cill: </span>';
        echo '<span class="detail-value">' . esc_html($wizard['cill']) . '</span>';
        echo '</div>';
    }
    
    // Postcode
    if (!empty($wizard['postcode'])) {
        echo '<div class="detail-item">';
        echo '<span class="detail-label">Postcode: </span>';
        echo '<span class="detail-value">' . esc_html($wizard['postcode']) . '</span>';
        echo '</div>';
    }
    
    // Access Issues
    if (!empty($wizard['access'])) {
        echo '<div class="detail-item">';
        echo '<span class="detail-label">Access: </span>';
        echo '<span class="detail-value">' . esc_html($wizard['access']) . '</span>';
        echo '</div>';
    }
    
    echo '</div>'; // Close config-details-grid
    echo '</div>'; // Close door-builder-cart-data
}

/**
 * Add custom CSS for cart page
 */
add_action('wp_head', function() {
    if (is_cart()) {
        ?>
        <style>
            .door-builder-cart-data {
                background: #ffffff;
                border: 1px solid #e8e8e8;
                border-radius: 8px;
                padding: 20px;
                margin: 15px 0;
                box-shadow: 0 2px 8px rgba(0,0,0,0.03);
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            }
            
            .cart-data-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 20px;
                padding-bottom: 12px;
                border-bottom: 2px solid #cbbfa9;
            }
            
            .cart-data-header h4 {
                margin: 0;
                color: #1a1a1a;
                font-size: 16px;
                font-weight: 600;
                letter-spacing: 0.3px;
            }
            
            .edit-config-btn {
                background: #cbbfa9;
                color: white;
                padding: 6px 16px;
                border-radius: 4px;
                text-decoration: none;
                font-size: 12px;
                font-weight: 500;
                letter-spacing: 0.3px;
                transition: all 0.2s ease;
                border: none;
                cursor: pointer;
                text-transform: uppercase;
            }
            
            .edit-config-btn:hover {
                background: #b9ad95;
                color: white;
                text-decoration: none;
                transform: translateY(-1px);
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            
            .config-details-grid {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
                gap: 12px;
            }
            
            .detail-item {
                display: flex;
                align-items: baseline;
                padding: 8px 12px;
                background: #f8f8f8;
                border-radius: 4px;
                font-size: 13px;
            }
            
            .detail-label {
                color: #666;
                font-weight: 500;
                min-width: 70px;
                text-transform: uppercase;
                font-size: 11px;
                letter-spacing: 0.3px;
            }
            
            .detail-value {
                color: #333;
                font-weight: 400;
                margin-left: 8px;
                word-break: break-word;
            }
            
            @media (max-width: 768px) {
                .door-builder-cart-data {
                    padding: 15px;
                }
                
                .cart-data-header {
                    flex-direction: column;
                    gap: 10px;
                    align-items: flex-start;
                }
                
                .config-details-grid {
                    grid-template-columns: 1fr;
                }
                
                .detail-item {
                    flex-wrap: wrap;
                }
                
                .detail-label {
                    min-width: 100%;
                    margin-bottom: 4px;
                }
                
                .detail-value {
                    margin-left: 0;
                }
            }
            
            /* Hide any duplicate delivery info in cart */
            .delivery-info {
                display: none !important;
            }
        </style>
        <?php
    }
});

/**
 * Handle cart item update
 */
add_action('template_redirect', 'handle_cart_item_update');
function handle_cart_item_update() {
    if (isset($_POST['edit_mode']) && $_POST['edit_mode'] == '1' && isset($_POST['cart_item_key'])) {
        
        $cart_item_key = sanitize_text_field($_POST['cart_item_key']);
        $cart = WC()->cart->get_cart();
        
        if (isset($cart[$cart_item_key])) {
            
            // Get current cart item
            $cart_item = $cart[$cart_item_key];
            
            // Parse form data
            parse_str($_POST['form_data'], $form_data);
            
            // Build new wizard data
            $wizard_data = array();
            
            // Get all data from form_data
            $wizard_data['width'] = isset($form_data['width']) ? intval($form_data['width']) : 0;
            $wizard_data['height'] = isset($form_data['height']) ? intval($form_data['height']) : 0;
            $wizard_data['panels'] = isset($form_data['panel_layout']) ? $form_data['panel_layout'] : '';
            $wizard_data['opening'] = isset($form_data['open_direction']) ? ($form_data['open_direction'] === 'inwards' ? 'Inwards' : 'Outwards') : '';
            $wizard_data['outside_colour'] = isset($form_data['door_colour']) ? $form_data['door_colour'] : '';
            $wizard_data['inside_colour'] = isset($form_data['inside_colour']) ? $form_data['inside_colour'] : '';
            $wizard_data['handle'] = isset($form_data['handle_colour']) ? $form_data['handle_colour'] : '';
            
            // ===== FIXED: Glass field with No Thanks support =====
            if (isset($form_data['glass_upgrade'])) {
                $glass = $form_data['glass_upgrade'];
                if ($glass === 'no_thanks') {
                    $wizard_data['glass'] = 'no_thanks';
                } else {
                    $wizard_data['glass'] = $glass;
                }
            }
            
            $wizard_data['vents'] = isset($form_data['trickle_vents']) ? ($form_data['trickle_vents'] === 'yes_trickle' ? 'With Vents' : 'No Vents') : '';
            $wizard_data['cill'] = isset($form_data['cill']) ? $form_data['cill'] : '';
            
            // ===== NEW: Postcode and Delivery =====
            $wizard_data['postcode'] = isset($form_data['postcode']) ? $form_data['postcode'] : '';
            $wizard_data['delivery_price'] = isset($form_data['delivery_price']) ? floatval($form_data['delivery_price']) : 0;
            $wizard_data['delivery_zone'] = isset($form_data['delivery_zone']) ? $form_data['delivery_zone'] : '';
            $wizard_data['delivery_distance'] = isset($form_data['delivery_distance']) ? floatval($form_data['delivery_distance']) : 0;
            $wizard_data['delivery_bespoke'] = isset($form_data['delivery_bespoke']) ? $form_data['delivery_bespoke'] : '0';
            
            $wizard_data['access'] = isset($form_data['access_issues']) ? ($form_data['access_issues'] === 'yes_access' ? 'Yes' : 'No') : '';
            $wizard_data['first_name'] = isset($form_data['first_name']) ? $form_data['first_name'] : '';
            $wizard_data['last_name'] = isset($form_data['last_name']) ? $form_data['last_name'] : '';
            $wizard_data['email'] = isset($form_data['email_address']) ? $form_data['email_address'] : '';
            $wizard_data['phone'] = isset($form_data['mobile_number']) ? $form_data['mobile_number'] : '';
            
            $wizard_data['unique_id'] = uniqid('door_', true);
            $wizard_data['timestamp'] = time();
            
            // Remove old item
            WC()->cart->remove_cart_item($cart_item_key);
            
            // Add updated item
            WC()->cart->add_to_cart(
                $cart_item['product_id'],
                $cart_item['quantity'],
                $cart_item['variation_id'],
                $cart_item['variation'],
                array(
                    'wizard_data' => $wizard_data,
                    'custom_price' => $form_data['final_price'],
                    'unique_key' => md5(serialize($wizard_data) . time())
                )
            );
            
            wp_redirect(wc_get_cart_url());
            exit;
        }
    }
}

/**
 * Display builder data in checkout page under product name
 * Each detail on a new line with proper spacing
 * Hook: woocommerce_checkout_cart_item_quantity
 */
add_filter('woocommerce_checkout_cart_item_quantity', 'display_builder_data_checkout', 10, 3);
function display_builder_data_checkout($quantity_html, $cart_item, $cart_item_key) {
    
    // Check if this is a builder product with wizard data
    if (!isset($cart_item['wizard_data']) || empty($cart_item['wizard_data'])) {
        return $quantity_html;
    }
    
    $wizard = $cart_item['wizard_data'];
    
    // Start output
    $details_html = '<div class="checkout-door-details">';
    
    // Manufacturing Size
    if (!empty($wizard['width']) && !empty($wizard['height'])) {
        $details_html .= '<div class="detail-row">';
        $details_html .= '<span class="detail-label-co">Manufacturing Size: </span>';
        $details_html .= '<span class="detail-value-co">' . esc_html($wizard['width'] . ' x ' . $wizard['height'] . ' mm') . '</span>';
        $details_html .= '</div>';
    }
    
    // Panels
    if (!empty($wizard['panels'])) {
        $details_html .= '<div class="detail-row">';
        $details_html .= '<span class="detail-label-co">Panels: </span>';
        $details_html .= '<span class="detail-value-co">' . esc_html($wizard['panels']) . '</span>';
        $details_html .= '</div>';
    }
    
    // Opening Direction
    if (!empty($wizard['opening'])) {
        $details_html .= '<div class="detail-row">';
        $details_html .= '<span class="detail-label-co">Opening Direction: </span>';
        $details_html .= '<span class="detail-value-co">' . esc_html($wizard['opening']) . '</span>';
        $details_html .= '</div>';
    }
    
    // Outside Colour
    if (!empty($wizard['outside_colour'])) {
        $outside = $wizard['outside_colour'];
        if (!empty($wizard['outside_ral'])) {
            $outside .= ' (' . $wizard['outside_ral'] . ')';
        }
        $details_html .= '<div class="detail-row">';
        $details_html .= '<span class="detail-label-co">Outside Colour: </span>';
        $details_html .= '<span class="detail-value-co">' . esc_html($outside) . '</span>';
        $details_html .= '</div>';
    }
    
    // Inside Colour
    if (!empty($wizard['inside_colour'])) {
        $inside = $wizard['inside_colour'];
        if (!empty($wizard['inside_ral'])) {
            $inside .= ' (' . $wizard['inside_ral'] . ')';
        }
        $details_html .= '<div class="detail-row">';
        $details_html .= '<span class="detail-label-co">Inside Colour: </span>';
        $details_html .= '<span class="detail-value-co">' . esc_html($inside) . '</span>';
        $details_html .= '</div>';
    }
    
    // Handle Colour
    if (!empty($wizard['handle'])) {
        $details_html .= '<div class="detail-row">';
        $details_html .= '<span class="detail-label-co">Handle Colour: </span>';
        $details_html .= '<span class="detail-value-co">' . esc_html($wizard['handle']) . '</span>';
        $details_html .= '</div>';
    }
    
    // Glass - UPDATED with No Thanks support
    if (!empty($wizard['glass'])) {
        $glass_display = $wizard['glass'];
        if ($glass_display === 'no_thanks') {
            $glass_display = 'No Thanks - Standard Glass';
        }
        $details_html .= '<div class="detail-row">';
        $details_html .= '<span class="detail-label-co">Glass: </span>';
        $details_html .= '<span class="detail-value-co">' . esc_html($glass_display) . '</span>';
        $details_html .= '</div>';
    }
    
    // Trickle Vents
    if (isset($wizard['vents'])) {
        $details_html .= '<div class="detail-row">';
        $details_html .= '<span class="detail-label-co">Trickle Vents: </span>';
        $details_html .= '<span class="detail-value-co">' . esc_html($wizard['vents']) . '</span>';
        $details_html .= '</div>';
    }
    
    // Cill
    if (!empty($wizard['cill'])) {
        $details_html .= '<div class="detail-row">';
        $details_html .= '<span class="detail-label-co">Cill: </span>';
        $details_html .= '<span class="detail-value-co">' . esc_html($wizard['cill']) . '</span>';
        $details_html .= '</div>';
    }
    
    // Postcode
    if (!empty($wizard['postcode'])) {
        $details_html .= '<div class="detail-row">';
        $details_html .= '<span class="detail-label-co">Postcode: </span>';
        $details_html .= '<span class="detail-value-co">' . esc_html($wizard['postcode']) . '</span>';
        $details_html .= '</div>';
    }
    
    // Delivery Info (if available)
    if (isset($wizard['delivery_price']) && isset($wizard['delivery_zone'])) {
        if (isset($wizard['delivery_bespoke']) && $wizard['delivery_bespoke'] === '1') {
            $details_html .= '<div class="detail-row bespoke-delivery">';
            $details_html .= '<span class="detail-label-co">Delivery: </span>';
            $details_html .= '<span class="detail-value-co">Bespoke (call for quote)</span>';
            $details_html .= '</div>';
        } else {
            $price_text = $wizard['delivery_price'] > 0 ? '£' . number_format($wizard['delivery_price'], 2) : 'FREE';
            $details_html .= '<div class="detail-row">';
            $details_html .= '<span class="detail-label-co">Delivery: </span>';
            $details_html .= '<span class="detail-value-co">' . $price_text . ' (' . $wizard['delivery_zone'] . ', ' . round($wizard['delivery_distance'], 1) . ' miles)</span>';
            $details_html .= '</div>';
        }
    }
    
    // Access Issues
    if (!empty($wizard['access'])) {
        $details_html .= '<div class="detail-row">';
        $details_html .= '<span class="detail-label-co">Access Issues: </span>';
        $details_html .= '<span class="detail-value-co">' . esc_html($wizard['access']) . '</span>';
        $details_html .= '</div>';
    }
    
    $details_html .= '</div>';
    
    return $quantity_html . $details_html;
}

/**
 * Enhanced checkout table styling with proper quantity alignment
 */
add_action('wp_head', function() {
    if (is_checkout()) {
        ?>
        <style>
            .detail-label-co {
                font-weight: 600;
                font-size: 12px;
                color: #555;
                min-width: 140px;
                display: inline-block;
                text-transform: uppercase;
                letter-spacing: 0.3px;
            }
            
            .detail-value-co {
                font-weight: 400;
                font-size: 12px;
                color: #333;
            }
            
            .detail-row.bespoke-delivery .detail-value-co {
                color: #d32f2f;
                font-weight: 600;
            }
            
            @media (max-width: 768px) {
                .checkout-door-details .detail-row {
                    flex-direction: column;
                    margin: 8px 0;
                    padding: 5px 0;
                    border-bottom: 1px dotted #eee;
                }
                
                .detail-label-co {
                    min-width: 100%;
                    width: 100%;
                    margin-bottom: 3px;
                    font-size: 11px;
                }
                
                .detail-value-co {
                    width: 100%;
                    padding-left: 8px;
                    font-size: 11px;
                    border-left: 2px solid #cbbfa9;
                }
            }
            
            .woocommerce-checkout-review-order-table td.product-name {
                vertical-align: top;
                padding-bottom: 15px;
            }
            
            .checkout-door-details {
                margin: 10px 0 15px 0;
                padding: 12px 15px;
                background: #f9f9f9;
                border-left: 4px solid #cbbfa9;
                border-radius: 4px;
                width: 100%;
                box-sizing: border-box;
                clear: both;
            }
            
            .woocommerce-checkout-review-order-table td.product-total {
                vertical-align: top;
                padding-top: 15px;
            }

            form #order_review:not(.elementor-widget-woocommerce-checkout-page #order_review) {
                padding: 0 .5em !important;
            }
        </style>
        <?php
    }
});

/**
 * Display builder data in order details (thank you page and admin)
 * Each detail on a new line - CSS removed
 */
add_action('woocommerce_order_item_meta_end', 'display_builder_data_order_details', 10, 4);
function display_builder_data_order_details($item_id, $item, $order, $plain_text) {
    
    $wizard_data = array();
    
    // Try to get data from item meta
    $meta_data = $item->get_meta_data();
    
    foreach ($meta_data as $meta) {
        if (strpos($meta->key, 'builder_') === 0) {
            $key = str_replace('builder_', '', $meta->key);
            $wizard_data[$key] = $meta->value;
        } elseif (in_array($meta->key, ['width', 'height', 'panels', 'opening', 'outside_colour', 'inside_colour', 'handle', 'glass', 'vents', 'cill', 'postcode', 'access', 'delivery_price', 'delivery_zone', 'delivery_distance', 'delivery_bespoke'])) {
            $wizard_data[$meta->key] = $meta->value;
        }
    }
    
    if (empty($wizard_data)) {
        return;
    }
    
    echo '<div class="order-door-details">';
    echo '<strong class="order-door-title">Door Configuration:</strong>';
    
    // Manufacturing Size
    if (!empty($wizard_data['width']) && !empty($wizard_data['height'])) {
        echo '<div class="order-door-row">';
        echo '<span class="order-door-label">Manufacturing Size:</span>';
        echo '<span class="order-door-value">' . esc_html($wizard_data['width'] . ' x ' . $wizard_data['height'] . ' mm') . '</span>';
        echo '</div>';
    }
    
    // Panels
    if (!empty($wizard_data['panels'])) {
        echo '<div class="order-door-row">';
        echo '<span class="order-door-label">Panels:</span>';
        echo '<span class="order-door-value">' . esc_html($wizard_data['panels']) . '</span>';
        echo '</div>';
    }
    
    // Opening Direction
    if (!empty($wizard_data['opening'])) {
        echo '<div class="order-door-row">';
        echo '<span class="order-door-label">Opening Direction:</span>';
        echo '<span class="order-door-value">' . esc_html($wizard_data['opening']) . '</span>';
        echo '</div>';
    }
    
    // Outside Colour
    if (!empty($wizard_data['outside_colour'])) {
        $outside = $wizard_data['outside_colour'];
        if (!empty($wizard_data['outside_ral'])) {
            $outside .= ' (' . $wizard_data['outside_ral'] . ')';
        }
        echo '<div class="order-door-row">';
        echo '<span class="order-door-label">Outside Colour:</span>';
        echo '<span class="order-door-value">' . esc_html($outside) . '</span>';
        echo '</div>';
    }
    
    // Inside Colour
    if (!empty($wizard_data['inside_colour'])) {
        $inside = $wizard_data['inside_colour'];
        if (!empty($wizard_data['inside_ral'])) {
            $inside .= ' (' . $wizard_data['inside_ral'] . ')';
        }
        echo '<div class="order-door-row">';
        echo '<span class="order-door-label">Inside Colour:</span>';
        echo '<span class="order-door-value">' . esc_html($inside) . '</span>';
        echo '</div>';
    }
    
    // Handle Colour
    if (!empty($wizard_data['handle'])) {
        echo '<div class="order-door-row">';
        echo '<span class="order-door-label">Handle Colour:</span>';
        echo '<span class="order-door-value">' . esc_html($wizard_data['handle']) . '</span>';
        echo '</div>';
    }
    
    // Glass - UPDATED with No Thanks support
    if (!empty($wizard_data['glass'])) {
        $glass_display = $wizard_data['glass'];
        if ($glass_display === 'no_thanks') {
            $glass_display = 'No Thanks - Standard Glass';
        }
        echo '<div class="order-door-row">';
        echo '<span class="order-door-label">Glass:</span>';
        echo '<span class="order-door-value">' . esc_html($glass_display) . '</span>';
        echo '</div>';
    }
    
    // Trickle Vents
    if (isset($wizard_data['vents'])) {
        echo '<div class="order-door-row">';
        echo '<span class="order-door-label">Trickle Vents:</span>';
        echo '<span class="order-door-value">' . esc_html($wizard_data['vents']) . '</span>';
        echo '</div>';
    }
    
    // Cill
    if (!empty($wizard_data['cill'])) {
        echo '<div class="order-door-row">';
        echo '<span class="order-door-label">Cill:</span>';
        echo '<span class="order-door-value">' . esc_html($wizard_data['cill']) . '</span>';
        echo '</div>';
    }
    
    // Postcode
    if (!empty($wizard_data['postcode'])) {
        echo '<div class="order-door-row">';
        echo '<span class="order-door-label">Postcode:</span>';
        echo '<span class="order-door-value">' . esc_html($wizard_data['postcode']) . '</span>';
        echo '</div>';
    }
    
    // Delivery Info
    if (isset($wizard_data['delivery_price'])) {
        if (isset($wizard_data['delivery_bespoke']) && $wizard_data['delivery_bespoke'] === '1') {
            echo '<div class="order-door-row bespoke-delivery">';
            echo '<span class="order-door-label">Delivery:</span>';
            echo '<span class="order-door-value">Bespoke (call for quote)</span>';
            echo '</div>';
        } else {
            $price_text = $wizard_data['delivery_price'] > 0 ? '£' . number_format($wizard_data['delivery_price'], 2) : 'FREE';
            $zone_text = isset($wizard_data['delivery_zone']) ? $wizard_data['delivery_zone'] : '';
            $distance_text = isset($wizard_data['delivery_distance']) ? round($wizard_data['delivery_distance'], 1) . ' miles' : '';
            
            echo '<div class="order-door-row">';
            echo '<span class="order-door-label">Delivery:</span>';
            echo '<span class="order-door-value">' . $price_text . ' (' . $zone_text . ', ' . $distance_text . ')</span>';
            echo '</div>';
        }
    }
    
    // Access Issues
    if (!empty($wizard_data['access'])) {
        echo '<div class="order-door-row">';
        echo '<span class="order-door-label">Access Issues:</span>';
        echo '<span class="order-door-value">' . esc_html($wizard_data['access']) . '</span>';
        echo '</div>';
    }
    
    echo '</div>';
}

/**
 * Custom CSS for order details page
 */
add_action('wp_head', function() {
    if (is_order_received_page() || is_view_order_page() || is_account_page()) {
        ?>
        <style>
            /* Order Door Details Styling */
            .order-door-details {
                margin: 15px 0 10px 0;
                padding: 15px 18px;
                background: #ffffff;
                border: 1px solid #e5e5e5;
                border-left: 4px solid #cbbfa9;
                border-radius: 6px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.03);
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            }
            
            .order-door-title {
                display: block;
                margin-bottom: 12px;
                color: #1a1a1a;
                font-size: 15px;
                font-weight: 600;
                letter-spacing: 0.3px;
                padding-bottom: 8px;
                border-bottom: 2px solid #cbbfa9;
                text-transform: uppercase;
            }
            
            .order-door-row {
                display: flex;
                align-items: baseline;
                padding: 8px 0;
                border-bottom: 1px solid #f0f0f0;
                transition: background-color 0.2s ease;
            }
            
            .order-door-row:hover {
                background-color: #fafafa;
            }
            
            .order-door-row:last-child {
                border-bottom: none;
            }
            
            .order-door-label {
                flex: 0 0 150px;
                color: #555;
                font-weight: 500;
                font-size: 13px;
                text-transform: uppercase;
                letter-spacing: 0.3px;
            }
            
            .order-door-value {
                flex: 1;
                color: #222;
                font-size: 14px;
                font-weight: 400;
                word-break: break-word;
            }
            
            .order-door-row.bespoke-delivery .order-door-value {
                color: #d32f2f;
                font-weight: 600;
            }
            
            @media (max-width: 768px) {
                .order-door-details {
                    padding: 12px 15px;
                }
                
                .order-door-row {
                    flex-direction: column;
                    padding: 10px 0;
                }
                
                .order-door-label {
                    flex: none;
                    width: 100%;
                    margin-bottom: 4px;
                    font-size: 12px;
                }
                
                .order-door-value {
                    width: 100%;
                    font-size: 13px;
                    padding-left: 8px;
                }
            }
            
            @media (prefers-color-scheme: dark) {
                .order-door-details {
                    background: #2d2d2d;
                    border-color: #404040;
                }
                
                .order-door-title {
                    color: #ffffff;
                }
                
                .order-door-row {
                    border-bottom-color: #404040;
                }
                
                .order-door-row:hover {
                    background-color: #363636;
                }
                
                .order-door-label {
                    color: #b0b0b0;
                }
                
                .order-door-value {
                    color: #e0e0e0;
                }
            }
        </style>
        <?php
    }
});

/**
 * AJAX endpoint for real-time delivery calculation
 */
add_action('wp_ajax_check_delivery', 'ajax_check_delivery');
add_action('wp_ajax_nopriv_check_delivery', 'ajax_check_delivery');
function ajax_check_delivery() {
    $postcode = sanitize_text_field($_POST['postcode']);
    
    if (empty($postcode)) {
        wp_send_json_error(['message' => 'Postcode required']);
    }
    
    $calculator = new Door_Delivery_Calculator();
    $result = $calculator->calculate_delivery($postcode);
    
    wp_send_json_success($result);
}

/**
 * Test function - Add this temporarily to debug
 */
add_action('init', function() {
    if (isset($_GET['test_delivery'])) {
        $calculator = new Door_Delivery_Calculator();
        $result = $calculator->calculate_delivery('DY2 8UB');
        echo '<pre>';
        print_r($result);
        echo '</pre>';
        exit;
    }
});

/**
 * Update wizard.js to handle postcode validation and delivery preview
 * This adds a delivery preview to Step 10
 */
add_action('wp_footer', function() {
    if (!is_page('bifold-door-builder')) {
        return;
    }
    ?>
    <script>
    jQuery(function($) {
        // Make sure we don't duplicate the preview container
        if ($('#delivery-preview-container').length === 0) {
            $('.postcode-input-wrapper').append('<div id="delivery-preview-container" class="delivery-preview" style="display: none;"></div>');
        }
        
        // Override postcode validation to include delivery check
        window.validatePostcodeStep = function() {
            const postcode = $('#postcode').val().trim();
            const $deliveryPreview = $('#delivery-preview-container');
            const $nextBtn = $('.next-step');
            const $nextFooterBtn = $('.next-footer-btn');
            
            if (postcode.length === 0) {
                $deliveryPreview.hide();
                $nextBtn.addClass('inactive').prop('disabled', true);
                if ($nextFooterBtn.length) $nextFooterBtn.addClass('inactive').prop('disabled', true);
                return false;
            }
            
            // Show loading
            $deliveryPreview.html('<div class="loading">Checking delivery...</div>').show();
            
            // Make AJAX call
            $.ajax({
                url: door_builder_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'check_delivery',
                    postcode: postcode,
                    security: door_builder_vars.nonce
                },
                success: function(response) {
                    if (response.success) {
                        const data = response.data;
                        
                        // Store delivery data globally
                        window.deliveryData = data;
                        
                        // Update hidden fields
                        $('#delivery_price').val(data.price);
                        $('#delivery_zone').val(data.zone);
                        $('#delivery_distance').val(data.distance);
                        $('#delivery_bespoke').val(data.bespoke ? '1' : '0');
                        
                        if (data.bespoke) {
                            $deliveryPreview.html(
                                '<div class="bespoke-warning">' +
                                '<strong>Bespoke Delivery Required</strong><br>' +
                                'Please call our sales team for a quote.' +
                                '</div>'
                            ).show();
                            $nextBtn.addClass('inactive').prop('disabled', true);
                            if ($nextFooterBtn.length) $nextFooterBtn.addClass('inactive').prop('disabled', true);
                        } else {
                            const priceText = data.price === 0 ? 'FREE' : '£' + data.price;
                            $deliveryPreview.html(
                                '<div style="border-left: 3px solid #4caf50; padding-left: 10px;">' +
                                '<strong>Delivery:</strong> ' + data.zone + ' - ' + data.distance.toFixed(1) + ' miles - ' + priceText +
                                '</div>'
                            ).show();
                            
                            $nextBtn.removeClass('inactive').prop('disabled', false);
                            if ($nextFooterBtn.length) $nextFooterBtn.removeClass('inactive').prop('disabled', false);
                        }
                    } else {
                        $deliveryPreview.html(
                            '<div class="error">Error checking postcode. Please try again.</div>'
                        ).show();
                    }
                },
                error: function() {
                    $deliveryPreview.html(
                        '<div class="error">Network error. Please try again.</div>'
                    ).show();
                }
            });
            
            return true;
        };
        
        // Trigger on postcode change with debounce
        let debounceTimer;
        $('#postcode').on('input', function() {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(function() {
                validatePostcodeStep();
            }, 800);
        });
    });
    </script>
    <style>
    .delivery-preview {
        font-size: 14px;
        border: 1px solid #e0e0e0;
        background: #ffffff !important;
        margin-top: 15px;
        padding: 10px;
        border-radius: 4px;
    }
    
    .delivery-preview .loading {
        color: #666;
        font-style: italic;
    }
    
    .bespoke-warning {
        padding: 8px;
        background: #fff3e0;
        border-radius: 4px;
        font-size: 13px;
        color: #d32f2f;
    }
    </style>
    <?php
});

/**
 * Show Technical Specification Image below short description
 */
add_action('woocommerce_single_product_summary', 'show_technical_specification_image', 25);

function show_technical_specification_image() {

    if (!is_product()) {
        return;
    }

    $image = get_field('technical_specification_image');

    if ($image) {
        echo '<div class="technical-specification-image">';
        echo '<img src="' . esc_url($image) . '" alt="Bi-fold door technical specification">';
        echo '</div>';
    }
}


/**
 * Custom CSS for Technical Specification Image
 */
add_action('wp_head', function() {
    if (is_product()) {
        ?>
        <style>

        .technical-specification-image{
            margin-top:25px;
            margin-bottom:25px;
        }

        .technical-specification-image img{
            width:100%;
            height:auto;
            display:block;
            border-radius:6px;
        }

        </style>
        <?php
    }
});

/**
 * Filter to show custom image in cart based on selected panel from Step 2
 */
add_filter( 'woocommerce_cart_item_thumbnail', 'custom_cart_item_thumbnail_based_on_panel', 10, 3 );

function custom_cart_item_thumbnail_based_on_panel( $thumbnail, $cart_item, $cart_item_key ) {
    
    // Check if this is our custom builder product
    if ( isset( $cart_item['wizard_data'] ) && isset( $cart_item['wizard_data']['panels'] ) ) {
        
        $panels = $cart_item['wizard_data']['panels'];
        $image_url = '';
        
        // Map panel display text to image filename
        $panel_image_map = array(
            '2 Panels Left' => '2_Panel_Left_500x.webp',
            '2 Panels Right' => '2_Panel_Right_500x.webp',
            '3 Panels Left' => '3_Panel_Left_500x.webp',
            '3 Panels Right' => '3_Panel_Right_500x.webp',
            '1 + 3 Panels' => '1_3_Panel_500x.webp',
            '3 + 1 Panels' => '3_1_Panel_500x.webp',
            '4 Panels Left' => '4_Panel_Left_500x.webp',
            '4 Panels Right' => '4_Panel_Right_500x.webp',
            '5 Panels Left' => '5_Panel_Left_500x.webp',
            '5 Panels Right' => '5_Panel_Right_500x.webp',
            '1 + 5 Panels' => '1_5_Panel_500x.avif',
            '2 + 4 Panels' => '2_4_Panel_500x.avif',
            '3 + 3 Panels' => '3_3_Panel_500x.avif',
            '4 + 2 Panels' => '4_2_Panel_500x.avif',
            '5 + 1 Panels' => '5_1_Panel_500x.avif',
            '6 Panels Left' => '6_Panel_Left_500x.avif',
            '6 Panels Right' => '6_Panel_Right_500x.avif',
            'French Doors' => 'French_Doors_500x.webp',
        );
        
        // Standard panel values (if stored as values instead of display text)
        $standard_panels = array(
            '2_left', '2_right', '3_left', '3_right', '1_3', '3_1', 
            '4_left', '4_right', '5_left', '5_right', '1_5', '2_4', 
            '3_3', '4_2', '5_1', '6_left', '6_right', 'french'
        );
        
        // If it's a direct value (e.g., '2_left')
        if ( in_array( $panels, $standard_panels ) ) {
            $panel_value = $panels;
            $panel_value = str_replace( '_', '-', $panel_value );
            
            if ( $panel_value === 'french' ) {
                $image_file = 'French_Doors_500x.webp';
            } elseif ( strpos( $panel_value, '-' ) !== false ) {
                $parts = explode( '-', $panel_value );
                if ( count( $parts ) == 2 ) {
                    $image_file = $parts[0] . '_' . $parts[1] . '_Panel_500x';
                    // Check file extension
                    if ( in_array( $panel_value, array( '1-5', '2-4', '3-3', '4-2', '5-1', '6-left', '6-right' ) ) ) {
                        $image_file .= '.avif';
                    } else {
                        $image_file .= '.webp';
                    }
                } else {
                    $image_file = $parts[0] . '_Panel_' . ucfirst( $parts[1] ) . '_500x.webp';
                }
            } else {
                $image_file = $panel_value . '_Panel_500x.webp';
            }
        }
        // If it's display text (e.g., '2 Panels Left')
        else {
            $image_file = isset( $panel_image_map[$panels] ) ? $panel_image_map[$panels] : '';
        }
        
        // If image file found, generate the image HTML
        if ( !empty( $image_file ) ) {
            $image_url = get_stylesheet_directory_uri() . '/assets/images/' . $image_file;
            
            // Create custom image HTML
            $thumbnail = '<img src="' . esc_url( $image_url ) . '" 
                               alt="' . esc_attr( $panels ) . '" 
                               class="woocommerce-placeholder wp-post-image" 
                               width="300" 
                               height="300" 
                               style="object-fit: contain; background: #f5f5f5; padding: 10px;" />';
        }
    }
    
    return $thumbnail;
}

/**
 * Add custom CSS to cart page
 */
add_action( 'wp_head', function() {
    if ( is_cart() ) {
        ?>
        <style>
            /* Cart page image styling */

            table.shop_table .product-thumbnail img, .woocommerce-page table.shop_table .product-thumbnail img {
                width: auto;
                max-width: 110px !important;
            }

            .woocommerce-cart-form__contents td.product-thumbnail img {
                width: 130px !important;
                height: auto !important;
                object-fit: contain !important;
                background: #f5f5f5 !important;
                border: 1px solid #e0e0e0 !important;
                border-radius: 4px !important;
                padding: 5px !important;
            }
            
            /* Tablet view */
            @media (max-width: 768px) {
                .woocommerce-cart-form__contents td.product-thumbnail img {
                    width: 60px !important;
                    height: 60px !important;
                }
            }
        </style>
        <?php
    }
});

/**
 * Filter to show custom image in checkout page
 */
add_filter( 'woocommerce_checkout_cart_item_thumbnail', 'custom_checkout_item_thumbnail_based_on_panel', 10, 3 );

function custom_checkout_item_thumbnail_based_on_panel( $thumbnail, $cart_item, $cart_item_key ) {
    
    // Check if this is our custom builder product
    if ( isset( $cart_item['wizard_data'] ) && isset( $cart_item['wizard_data']['panels'] ) ) {
        
        $panels = $cart_item['wizard_data']['panels'];
        $image_url = '';
        
        // Map panel display text to image filename
        $panel_image_map = array(
            '2 Panels Left' => '2_Panel_Left_500x.webp',
            '2 Panels Right' => '2_Panel_Right_500x.webp',
            '3 Panels Left' => '3_Panel_Left_500x.webp',
            '3 Panels Right' => '3_Panel_Right_500x.webp',
            '1 + 3 Panels' => '1_3_Panel_500x.webp',
            '3 + 1 Panels' => '3_1_Panel_500x.webp',
            '4 Panels Left' => '4_Panel_Left_500x.webp',
            '4 Panels Right' => '4_Panel_Right_500x.webp',
            '5 Panels Left' => '5_Panel_Left_500x.webp',
            '5 Panels Right' => '5_Panel_Right_500x.webp',
            '1 + 5 Panels' => '1_5_Panel_500x.avif',
            '2 + 4 Panels' => '2_4_Panel_500x.avif',
            '3 + 3 Panels' => '3_3_Panel_500x.avif',
            '4 + 2 Panels' => '4_2_Panel_500x.avif',
            '5 + 1 Panels' => '5_1_Panel_500x.avif',
            '6 Panels Left' => '6_Panel_Left_500x.avif',
            '6 Panels Right' => '6_Panel_Right_500x.avif',
            'French Doors' => 'French_Doors_500x.webp',
        );
        
        // Standard panel values (if stored as values instead of display text)
        $standard_panels = array(
            '2_left', '2_right', '3_left', '3_right', '1_3', '3_1', 
            '4_left', '4_right', '5_left', '5_right', '1_5', '2_4', 
            '3_3', '4_2', '5_1', '6_left', '6_right', 'french'
        );
        
        // Determine image file based on panel value
        if ( in_array( $panels, $standard_panels ) ) {
            $panel_value = $panels;
            $panel_value = str_replace( '_', '-', $panel_value );
            
            if ( $panel_value === 'french' ) {
                $image_file = 'French_Doors_500x.webp';
            } elseif ( strpos( $panel_value, '-' ) !== false ) {
                $parts = explode( '-', $panel_value );
                if ( count( $parts ) == 2 ) {
                    $image_file = $parts[0] . '_' . $parts[1] . '_Panel_500x';
                    if ( in_array( $panel_value, array( '1-5', '2-4', '3-3', '4-2', '5-1', '6-left', '6-right' ) ) ) {
                        $image_file .= '.avif';
                    } else {
                        $image_file .= '.webp';
                    }
                } else {
                    $image_file = $parts[0] . '_Panel_' . ucfirst( $parts[1] ) . '_500x.webp';
                }
            } else {
                $image_file = $panel_value . '_Panel_500x.webp';
            }
        } else {
            $image_file = isset( $panel_image_map[$panels] ) ? $panel_image_map[$panels] : '';
        }
        
        if ( !empty( $image_file ) ) {
            $image_url = get_stylesheet_directory_uri() . '/assets/images/' . $image_file;
            $thumbnail = '<img src="' . esc_url( $image_url ) . '" 
                               alt="' . esc_attr( $panels ) . '" 
                               width="50" 
                               height="50" 
                               style="object-fit: contain; background: #f5f5f5; padding: 3px; border-radius: 4px;" />';
        }
    }
    
    return $thumbnail;
}

/**
 * Display custom image in order details
 */
add_action( 'woocommerce_order_item_meta_end', 'display_custom_image_in_order_details', 10, 4 );

function display_custom_image_in_order_details( $item_id, $item, $order, $plain_text ) {
    
    // Get panel data from order item meta
    $panels = $item->get_meta( 'builder_panels' );
    
    if ( !empty( $panels ) && !$plain_text ) {
        
        // Map panel display text to image filename
        $panel_image_map = array(
            '2 Panels Left' => '2_Panel_Left_500x.webp',
            '2 Panels Right' => '2_Panel_Right_500x.webp',
            '3 Panels Left' => '3_Panel_Left_500x.webp',
            '3 Panels Right' => '3_Panel_Right_500x.webp',
            '1 + 3 Panels' => '1_3_Panel_500x.webp',
            '3 + 1 Panels' => '3_1_Panel_500x.webp',
            '4 Panels Left' => '4_Panel_Left_500x.webp',
            '4 Panels Right' => '4_Panel_Right_500x.webp',
            '5 Panels Left' => '5_Panel_Left_500x.webp',
            '5 Panels Right' => '5_Panel_Right_500x.webp',
            '1 + 5 Panels' => '1_5_Panel_500x.avif',
            '2 + 4 Panels' => '2_4_Panel_500x.avif',
            '3 + 3 Panels' => '3_3_Panel_500x.avif',
            '4 + 2 Panels' => '4_2_Panel_500x.avif',
            '5 + 1 Panels' => '5_1_Panel_500x.avif',
            '6 Panels Left' => '6_Panel_Left_500x.avif',
            '6 Panels Right' => '6_Panel_Right_500x.avif',
            'French Doors' => 'French_Doors_500x.webp',
        );
        
        $image_file = isset( $panel_image_map[$panels] ) ? $panel_image_map[$panels] : '';
        
        if ( !empty( $image_file ) ) {
            $image_url = get_stylesheet_directory_uri() . '/assets/images/' . $image_file;
            echo '<div style="margin-top: 10px;">';
            echo '<img src="' . esc_url( $image_url ) . '" 
                       alt="' . esc_attr( $panels ) . '" 
                       style="max-width: 100px; height: auto; border: 1px solid #ddd; border-radius: 4px; padding: 5px; background: #f9f9f9;" />';
            echo '</div>';
        }
    }
}