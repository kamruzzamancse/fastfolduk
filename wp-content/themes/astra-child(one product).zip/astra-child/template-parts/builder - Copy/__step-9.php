<?php
/**
 * Template part for Threshold Selection Step in Door Builder
 * Step 9: Threshold Selection
 *
 * @package Astra Child
 */
$images_dir = get_stylesheet_directory_uri() . '/assets/images/';
$placeholder = $images_dir . 'placeholder_threshold.webp';
?>

<!-- Step 9: Threshold Selection -->
<div class="wizard-step" data-step="9">
    <div class="step-container threshold-container">
        <div class="step-title threshold-title">
            <h2>Which threshold do you need?</h2>
            <p class="threshold-description">Please choose below.</p>
        </div>
       
        <div class="threshold-wrapper">
            <div class="threshold-options">
               
                <!-- Standard Threshold -->
                <div class="threshold-card" data-price="0">
                    <input type="radio" name="threshold" id="threshold_standard" value="standard" class="price-option" data-price="0" checked>
                    <label for="threshold_standard">
                        <div class="threshold-image">
                            <img src="<?php echo esc_url($images_dir . 'Standard_threshold.webp'); ?>"
                                 alt="Standard Threshold Diagram - 81mm width, 55mm height"
                                 loading="lazy"
                                 onerror="this.src='<?php echo esc_url($placeholder); ?>'">
                        </div>
                        <div class="threshold-details">
                            <div class="threshold-text-content">
                                <div class="threshold-name-line">
                                    <span class="threshold-radio-indicator"></span>
                                    <span class="option-name">Standard</span>
                                </div>
                            </div>
                        </div>
                    </label>
                </div>
               
                <!-- Low Threshold -->
                <div class="threshold-card" data-price="0">
                    <input type="radio" name="threshold" id="threshold_low" value="low" class="price-option" data-price="0">
                    <label for="threshold_low">
                        <div class="threshold-image">
                            <img src="<?php echo esc_url($images_dir . 'Low_threshold.webp'); ?>"
                                 alt="Low Threshold Diagram - 82mm width, 20mm height"
                                 loading="lazy"
                                 onerror="this.src='<?php echo esc_url($placeholder); ?>'">
                        </div>
                        <div class="threshold-details">
                            <div class="threshold-text-content">
                                <div class="threshold-name-line">
                                    <span class="threshold-radio-indicator"></span>
                                    <span class="option-name">Low</span>
                                </div>
                            </div>
                        </div>
                    </label>
                </div>
               
            </div>
        </div>
    </div>
</div>

<style>
/* ================================
   Threshold Selection Styles
   ================================ */
.threshold-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 20px;
}

.threshold-description {
    font-size: 16px;
    color: #666;
    margin: 0;
    line-height: 1.5;
    max-width: 800px;
}

/* Options grid - 2 cards in a row aligned to left */
.threshold-options {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 30px;
    margin-top: 30px;
    max-width: 900px !important;
    margin-left: 0; /* Changed from auto to 0 */
    margin-right: auto;
    justify-content: start; /* Align items to start (left) */
}

/* Individual card styling */
.threshold-card {
    border: 1px solid #e0e0e0;
    overflow: hidden;
    transition: all 0.25s ease;
    cursor: pointer;
    height: 100%;
    background: #fff;
    max-width: 435px; /* Limit card width for better left alignment */
}

.threshold-card:hover {
    border-color: #9c7b4b;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

/* Hide radio input */
.threshold-card input[type="radio"] {
    position: absolute;
    opacity: 0;
    width: 0;
    height: 0;
}

.threshold-card label {
    display: flex;
    flex-direction: column;
    height: 100%;
    cursor: pointer;
    background: transparent;
}

.threshold-card input:checked + label {
    border: 2px solid #9c7b4b;
    margin: -1px;
}

/* Image container */
.threshold-image {
    height: 280px !important;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f5f5f5;
    padding: 25px;
}

.threshold-image img {
    max-width: 100%;
    max-height: 100%;
    width: auto;
    height: auto;
    object-fit: contain;
}

/* Details container */
.threshold-details {
    padding: 15px;
    border-top: 1px solid #f0f0f0;
    background: #fafafa;
    min-height: 60px;
}

/* Text content container */
.threshold-text-content {
    display: flex;
    flex-direction: column;
    width: 100%;
}

/* Name line with radio indicator */
.threshold-name-line {
    display: flex;
    align-items: center;
    margin-bottom: 0;
    width: 100%;
    gap: 8px;
}

/* Radio indicator */
.threshold-radio-indicator {
    display: inline-block;
    width: 14px;
    height: 14px;
    border: 1.5px solid #222;
    border-radius: 50%;
    transition: all 0.2s ease;
    box-sizing: border-box;
    flex-shrink: 0;
}

/* Selected state for radio indicator */
.threshold-card input:checked + label .threshold-radio-indicator {
    background: #222;
    box-shadow: inset 0 0 0 3px #fafafa;
    border-color: #222;
}

/* Hover effect for radio indicator */
.threshold-card:hover .threshold-radio-indicator {
    border-color: #9c7b4b;
}

/* Selected card hover state */
.threshold-card input:checked + label:hover .threshold-radio-indicator {
    border-color: #222;
    background: #222;
    box-shadow: inset 0 0 0 3px #fafafa;
}

/* Option name styling */
.option-name {
    font-weight: 500;
    color: #333;
    display: inline-block;
    text-align: left;
    line-height: 1.3;
    font-size: 13px !important;
}

/* ================================
   Responsive Design
   ================================ */
@media (max-width: 768px) {
  
    .threshold-description {
        font-size: 14px;
        padding: 0 15px;
    }
   
    .threshold-options {
        grid-template-columns: 1fr; /* Stack vertically on mobile */
        gap: 15px;
        padding: 0 15px;
        max-width: 100%;
        margin-left: 0; /* Keep left aligned on mobile */
    }
   
    .threshold-image {
        height: 180px !important;
        padding: 15px;
    }
   
    .threshold-details {
        padding: 12px;
        min-height: 50px;
    }
   
    .threshold-radio-indicator {
        width: 12px;
        height: 12px;
        border-width: 1.2px;
    }
   
    .threshold-card input:checked + label .threshold-radio-indicator {
        box-shadow: inset 0 0 0 2px #fafafa;
    }
   
    .option-name {
        font-size: 12px !important;
    }
    
    .threshold-card {
        max-width: 100%; /* Full width on mobile */
    }
}

@media (min-width: 769px) and (max-width: 1024px) {
    .threshold-options {
        gap: 20px;
        padding: 0 20px;
        max-width: 100%;
        margin-left: 0; /* Keep left aligned on tablet */
    }
   
    .threshold-image {
        height: 220px !important;
    }
   
    .threshold-radio-indicator {
        width: 13px;
        height: 13px;
    }
   
    .option-name {
        font-size: 12px !important;
    }
    
    .threshold-card {
        max-width: 380px; /* Slightly smaller on tablet */
    }
}

@media (min-width: 1025px) and (max-width: 1399px) {
    .threshold-options {
        gap: 25px;
        max-width: 800px;
        margin-left: 0; /* Keep left aligned */
    }
   
    .threshold-image {
        height: 250px !important;
    }
   
    .threshold-radio-indicator {
        width: 14px;
        height: 14px;
    }
    
    .threshold-card {
        max-width: 385px; /* Adjust for medium screens */
    }
}

@media (min-width: 1400px) {
    .threshold-options {
        gap: 30px;
        max-width: 900px;
        margin-left: 0; /* Keep left aligned */
    }
   
    .threshold-image {
        height: 280px !important;
    }
   
    .threshold-radio-indicator {
        width: 15px;
        height: 15px;
        border-width: 2px;
    }
   
    .threshold-card input:checked + label .threshold-radio-indicator {
        box-shadow: inset 0 0 0 3.5px #fafafa;
    }
    
    .threshold-card {
        max-width: 435px; /* Standard card width */
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Add selected state styling when radio is checked
    $('.threshold-card input[type="radio"]').on('change', function() {
        // Remove selected styling from all cards
        $('.threshold-card').removeClass('selected').css({
            'border-color': '#e0e0e0',
            'background': '#fff'
        });
       
        // Add selected styling to the checked card
        $(this).closest('.threshold-card').addClass('selected').css({
            'border-color': '#9c7b4b',
            'background': '#fff'
        });
       
        // Trigger price update if needed
        if (typeof updatePrice === 'function') {
            updatePrice();
        }
    });
   
    // Set initial selected state (Standard is checked by default)
    $('.threshold-card input[type="radio"]:checked').each(function() {
        $(this).closest('.threshold-card').addClass('selected').css({
            'border-color': '#9c7b4b',
            'background': '#fff'
        });
    });
   
    // Handle card click for better UX
    $('.threshold-card').on('click', function(e) {
        if ($(e.target).is('input[type="radio"]')) {
            return;
        }
       
        const $radio = $(this).find('input[type="radio"]');
        $radio.prop('checked', true).trigger('change');
    });
});
</script>